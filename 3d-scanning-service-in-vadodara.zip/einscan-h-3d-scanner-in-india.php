<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Shining 3D Einscan H Laser scanner in india | price | Specs</title>
   <meta name="description" content="Einscan H 3D scanner key features & specifications, Handheld captures full geometry of objects such as artwork or wood carving with fine details. Get Price Quote">
   <meta name="keywords" content="shining einscan h in india, einscan h 3d scanner, einscan h price.">
   <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow" />
    <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
    <meta name="revisit-after" content="7 days" />
    <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/einscan-H/CVR.png" />
    <meta name="twitter:card" content="Precise3dm" />
    <meta name="twitter:site" content="@precise3d_m" />
    <meta name="twitter:title" content="Precise3dm" />
    <meta name="twitter:description" content="Einscan H 3D scanner key features & specifications, Handheld captures full geometry of objects such as artwork or wood carving with fine details. Get Price Quote" />
    <meta property="og:type" content="3D Scanning" />
    <meta property="og:title" content="Shining 3D Einscan H Laser scanner in india | price | Specs" />
    <meta property="og:url" content="https://www.precise3dm.com/handheld-3d-laser-scanner-india-einscan-h.php" />
    <meta property="og:image" content="https://www.precise3dm.com/assets/images/einscan-H/CVR.png" />
    <meta property="og:description" content="Einscan H 3D scanner key features & specifications, Handheld captures full geometry of objects such as artwork or wood carving with fine details. Get Price Quote" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png"> 
   <!--bootstrap css-->
   <link rel="stylesheet" href="assets/css/bootstrap.css">
   <!-- custom css-->
   <link rel="stylesheet" href="assets/css/styles.css">
   <link rel="stylesheet" href="assets/css/optical-blue-light.css">
   <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
   <link rel="stylesheet" href="assets/css/scanner-styles.css">
   <link rel="canonical" href="https://www.precise3dm.com/einscan-h-3d-scanner-in-india.php" />
   <script src="assets/js/jquery-3.6.0.min.js"></script>
   <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [{
        "@type": "Question",
        "name": "What kind of technology is used in the EINSCAN H scanner?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "EinScan H is based on hybrid structure light German technology that uses LED and invisible infrared light."
        }
      }, {
        "@type": "Question",
        "name": "Which country makes the EINSCAN H scanner?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "This hybrid EINSCAN H scanner is designed in Germany and made in China."
        }
      }, {
        "@type": "Question",
        "name": "What is the range of scanning in the EINSCAN H scanner?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Impressive high-resolution EinScan H captures the full geometry of objects such as artwork or furniture with fine details. The high accuracy of scanned data is up to 1 meter."
        }
      }, {
        "@type": "Question",
        "name": "What are the advantages of the EINSCAN H scanner?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text":"Impressive high-resolution EinScan H captures the full The built-in color camera in the EinScan H scanner supports full-color texture capturing and scan black color objects too. The software is intuitive, user-friendly, and easy to operate. It can also be hand-held and uses turn-table codes too."}
        }]
    }
    </script>
    <script type="text/javascript">
        $('input[type="text"]').on('blur',function(){
                var val = $(this).val();
                $(this).val($.trim(val));
        });
    
        function disablebutton()
        {
            $('#loader').show();
            //$('#submit').attr('disabled',true);
        }
        $(document).ready(function() {
        var owl = $('.owl-carousel');
        owl.owlCarousel({
            loop: true,
            nav: true,
            autoplay: false,
            autoplayTimeout: 3000,
            margin: 40,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                960: {
                    items: 3
                },
                1200: {
                    items: 3
                }
            }
        });
    })
        
    </script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>
</head>

<body>
   <!-- header start -->
   <?php include('includes/header.php'); ?>
   <!-- header end -->

   <!-- section start-->
   <section id="einscan-h-banner" class="pt-4">
      <div class="container">
         <div class="row h-300">
         </div>
      </div>
      <div class="container-fluid heading m-320">
         <div class="row ">
            <div class="col-md-12 text-md-left text-center px-2">
               <div class="container">
                  <div class="row">
                     <div class="col-md-8">
                        <h2 class="title text-white">EINSCAN H</h2>
                        <p class="text-white text-uppercase">Hybrid LED & Infrared Light Source Handheld Color 3D Scanner</p>
                                <!-- Calendly badge widget begin -->
                                <link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
<script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" async></script>
<script type="text/javascript">window.onload = function() { Calendly.initBadgeWidget({ url: 'https://calendly.com/precise3dm?primary_color=fd8c1e', text: 'Book a Demo', color: '#fd8c1e', textColor: '#ffffff', branding: false }); }</script>
<!-- Calendly badge widget end -->
                                <!--<a class="btn pre-btn my-2" href="https://forms.zohopublic.com/virtualoffice20215/form/Bookademoonlineonsite/formperma/v-Zrwhh8zM330ig-4CD_W6rJsqgkKQ7nBEXF2nOr39M" target=_blank>BOOK A DEMO </a>-->
                        <a class="btn pre-btn my-2" href="https://forms.zohopublic.com/virtualoffice20215/form/GetaQuote/formperma/arTza4w3Oh5N9dIOFD8bGnEfcdb3bCEv_qdla54OBwQ" target=_blank>GET A QUOTE NOW</a>
                     </div>
                     <div class="col-md-4">
                        <img src="assets/images/einscan-H/(3).png" class="img-fluid" height="250" width="250" alt="3d-laser-scanner-Einscan-H">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- section end-->

   <!-- Overview section starts-->
   <section id="overview-section" class="pt-4">
      <div class="container overview-container">
         <div class="row">
            <div class="col-md-3" id="overview-heading-text">
               <a class="btn pre-btn my-2" href="#">OVERVIEW </a>
            </div>
         </div>
         <div class="row">
            <div class="col-xs-12">
               <p class="overview">With the strength of technical accumulation on 3D vision technology in more than a decade, SHINING 3D is now introducing its newly developed handheld 3D Scanner, EinScan H. Based on hybrid structure light technology of LED and invisible infrared light, EinScan H is making human face-scanning more comfortable without strong light. With a built-in color camera and large field of view, EinScan H provides high-quality 3D data in full color, ready-to-use in minutes.
               </p>
            </div>
         </div>
         <div class="row" id="overview-btns">

            <div class="col-xs-6 col-md-6 mobile-features">
               <a class="btn pre-btn my-2" href="#machine-spec" ;>KEY FEATURES</a>
            </div>
            <div class="col-xs-6 col-md-5 mobile-specs">
               <a class="btn pre-btn my-2" href="#specifications">SPECIFICATIONS</a>
            </div>

         </div>

   </section>
   <!-- Overview section end-->

   <!-- Key feature section starts-->
   <section id="machine-spec" class="section-padding">
      <div class="container">
         <div class="container">
            <h2 class="text-white text-uppercase kf">KEY FEATURES</h2>
         </div>
         <div id="features">
            <section class="section-padding">
               <div class="container">
                  <div class="row">
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(1)-(A).PNG" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body">
                              <h5 class="card-title">Infrared & Structured Light Hybrid light source</h5>
                              <p class="card-text">Hybrid structure light source technology integrating LED structured light and invisible infrared light into one device and adding advanced smart presetting in different scan modes. Allows 3D Scanning in a wide range of applications which requires portable 3D Scanning technology.
                              </p>

                           </div>
                        </div>
                     </div>
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(2)-(A).PNG" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body">
                              <h5 class="card-title">The era of scanning with Hair Acquisition</h5>
                              <p class="card-text">
                                The invisible infrared light source provides a reliable solution to the problem of acquiring dark-colored objects and enables an easy acquisition of human hair.
                              </p>
                           </div>
                        </div>
                     </div>
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(3)-(A).PNG" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body">
                              <h5 class="card-title">Invisible light 3D Scanning experience
                              </h5>
                              <p class="card-text">
                                 The new face-scanning mode adopts invisible Infrared light enabling a safe and comfortable scanning process.
                              </p>

                           </div>
                        </div>
                     </div>
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(4)-(A).PNG" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body">
                              <h5 class="card-title">Fine Details</h5>
                              <p class="card-text">
                                Impressive high resolution reaches 0.25 mm, EinScan H captures the full geometry of objects such as artwork or furniture with fine details. The high accuracy of scanned data up to 0.05 mm and volumetric accuracy of 0.1mm/m improves the precision of 3D modeling allowing a dense points cloud and/or polygon meshes.

                              </p>

                           </div>
                        </div>
                     </div>
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(5)-(A).PNG" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body dark">
                              <h5 class="card-title">Fast Scanning</h5>
                              <p class="card-text">
                               Scan speed up to 1,200,000 points/second and large scan FOV of 420*440 mm ensures fast 3D Scanning of large-size objects. The optimized alignment algorithm enables efficient alignment despite the small movements of the scanned object or person.
                              </p>

                           </div>
                        </div>
                     </div>
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(6)-(A).jpg.png" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body dark">
                              <h5 class="card-title">Full-color reproduction</h5>
                              <p class="card-text">
                                The built-in color camera supports full-color texture capturing and tracking by texture.
                              </p>

                           </div>
                        </div>
                     </div>
                     <div class="col-12 col-sm-6 col-md-4 zoom-out">
                        <div class="card overflow-hidden">
                           <img class="card-img-top img-fluid" src="assets/images/einscan-H/KF-(7)-(A).png" alt="3d-laser-scanner-Einscan-H">
                           <div class="card-body dark">
                              <h5 class="card-title">Portable & easy operation</h5>
                              <ul class="card-textt">
                                 <li>The software is intuitive and user-friendly. Easy operation for professional users and beginners are alike. Easy to own and easy to use.
</li>
                                 <li>Weight - 703 g</li>
                              </ul>

                           </div>
                        </div>
                     </div>

                  </div>
               </div>

            </section>
         </div>
      </div>
   </section>
   <!-- Key feature section end-->

   <!-- Specifications section starts-->
   <section id="specifications">
      <div class="container">
         <h2 class="text-white text-uppercase kf">SPECIFICATIONS</h2>
      </div>
      <!--section start-->
      <section class="section-padding">
         <div class="container">
            <div class="table-responsive">
               <table class="table table-bordered text-white mb-0">
                  <thead>
                     <tr>
                        <th class="text-uppercase py-md-3 pre-bg-black w-md-50">
                           <h4>Scan Mode</h4>
                        </th>
                        <th class="text-uppercase py-md-3 pre-bg-black w-md-50">
                           <h4>Standard Scan</h4>
                        </th>
                        <th class="text-uppercase py-md-3 pre-bg-black w-md-50">
                           <h4>Body Scan</h4>
                        </th>
                        <th class="text-uppercase py-md-3 pre-bg-black w-md-50">
                           <h4>Face Scan</h4>
                        </th>

                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td>Light Source</td>
                        <td>White Light, visible</td>
                        <td>White Light, visible</td>
                        <td>Infrared light, invisible</td>
                     </tr>
                     <tr>
                        <td>Safety</td>
                        <td>LED light（eye-safe）</td>
                        <td>LED light（eye-safe）</td>
                        <td>CLASS І (eye-safe)</td>
                     </tr>
                     <tr>
                        <td>Scan Accuracy</td>
                        <td>Up to 0.05mm</td>
                        <td>Up to 0.05mm</td>
                        <td>Up to 0.6mm</td>
                     </tr>
                     <tr>
                        <td>Volumetric Accuracy*</td>
                        <td>0.05+0.1mm/m</td>
                        <td>0.05+0.1mm/m</td>
                        <td>/</td>
                     </tr>
                     <tr>
                        <td>Scan & Align Speed</td>
                        <td>1,200,000points/s, 20FPS</td>
                        <td>1,200,000points/s, 20FPS</td>
                        <td>720,000points/s, 20FPS</td>
                     </tr>
                     <tr>
                        <td>Camera Frame Rate</td>
                        <td colspan="3" style="text-align:center;">55FPS</td>
                     </tr>
                     <tr>
                        <td>Align Modes</td>
                        <td>Markers Alignment、Feature Alignment、Hybrid Alignment、Texture Alignment </td>
                        <td>Feature Alignment</td>
                        <td>Feature Alignment</td>
                     </tr>
                     <tr>
                        <td>Working Distance</td>
                        <td colspan="3" style="text-align:center;">470mm</td>
                     </tr>
                     <tr>
                        <td>Depth of Field</td>
                        <td>200-700mm</td>
                        <td>200-700mm</td>
                        <td>200-1500mm</td>
                     </tr>
                     <tr>
                        <td>Maximum FOV</td>
                        <td>420mm*440mm</td>
                        <td>420mm*440mm</td>
                        <td>780mm*900mm</td>
                     </tr>
                     <tr>
                        <td>Point distance</td>
                        <td>0.25mm-3mm</td>
                        <td>0.5mm-3mm</td>
                        <td>0.5mm-3mm</td>
                     </tr>
                     <tr>
                        <td>Built-in Color Camera</td>
                        <td colspan="3" style="text-align:center;">Yes</td>
                     </tr>
                     <tr>
                        <td>Color Scanning</td>
                        <td colspan="3" style="text-align:center;">Support</td>
                     </tr>
                     <tr>
                        <td>Connection Standard</td>
                        <td colspan="3" style="text-align:center;">USB3.0</td>
                     </tr>
                     <tr>
                        <td>Output Formats</td>
                        <td colspan="3" style="text-align:center;">OBJ;STL;ASC;PLY;P3;3MF</td>
                     </tr>
                     <tr>
                        <td>Dimensions</td>
                        <td colspan="3" style="text-align:center;">108mm*110mm*237mm</td>
                     </tr>

                     <tr>
                        <td>Weight</td>
                        <td colspan="3" style="text-align:center;">703g</td>
                     </tr>
                     <tr>
                        <td>Operating Temperature Range</td>
                        <td colspan="3" style="text-align:center;">0-40℃</td>
                     </tr>
                     <tr>
                        <td>Operating Humidity Range</td>
                        <td colspan="3" style="text-align:center;">10-90%</td>
                     </tr>
                     <tr>
                        <td>
                           Certifications
                        </td>
                        <td colspan="3" style="text-align:center;">CE，FCC，ROHS，WEEE，KC </td>
                     </tr>
                     <tr>
                        <td>Recommended Configuration</td>
                        <td colspan="3" style="text-align:center;">OS：Win10，64 bit；Graphics card: NVIDIA GTX/RTX series cards，higher or equal to GTX 1080；Video memory：≥4G；Processor：I7-8700；Memory：≥32GB</td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </section>
      <!--section end-->
   </section>
   <!-- Specifications section ends-->
   <hr class="white-separator">

   <!-- Demo video section start-->
   <section id="demo-video" class="pt-4 demoVid">
      <div class="container">
         <h2 class="text-white text-uppercase kf demV">DEMO VIDEO</h2>
         <div class="row">
            <div class="col-md-8 main-demo-video">
               <iframe width="100%" height="345" src="https://www.youtube.com/embed/E5VhABS2rPY" allow="autoplay" id="einscan_h_vdo">
               </iframe>
            </div>
            <div class="col-md-4">

               <div class="media">
                  <div class="media-left">
                     <img width="170px" height="75" src="assets/images/video_thumbnails/einscan-h-vdo1.png" id="einscan_h_vdo1">
                     </img>
                  </div>
                  <div class="media-body">
                     <h4 class="media-heading"> EINSCAN H </h4>
                     <p>3D Digitizing Solution</p>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </section>
   <!-- Demo video section ends-->

   <!-- Sample Data section start-->
   <section class="sample-data">
      <div class="flex sample-data">
         <div class="container">
            <h2 class="text-white text-uppercase kf demV">SAMPLE DATA</h2>
         </div>
         <div class="container">
                <!--<div class="sample-data-flex">
                    <h1>3D OBJECT VIEWER</h1>
                </div>-->
                <div class="col-md-12    mt-5  ">
                <div class="owl-carousel owl-theme">
                    <div class="item">
                    <div class="sketchfab-embed-wrapper"> <iframe title="Colour 3d scanning - Einscan 2X" height="300px" width="100%" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/9cee8e07ba43472eb54f43b395e2a343/embed"> </iframe> <p style="font-size: 13px; font-weight: normal; margin: 5px; color: #4A4A4A;"> <a href="https://sketchfab.com/3d-models/colour-3d-scanning-einscan-2x-9cee8e07ba43472eb54f43b395e2a343?utm_medium=embed&utm_campaign=share-popup&utm_content=9cee8e07ba43472eb54f43b395e2a343" target="_blank" style="font-weight: bold; color: #1CAAD9;"> Colour 3d scanning - Einscan 2X </a> by <a href="https://sketchfab.com/precise3dmetrlogy?utm_medium=embed&utm_campaign=share-popup&utm_content=9cee8e07ba43472eb54f43b395e2a343" target="_blank" style="font-weight: bold; color: #1CAAD9;"> PRECISE3DM </a> on <a href="https://sketchfab.com?utm_medium=embed&utm_campaign=share-popup&utm_content=9cee8e07ba43472eb54f43b395e2a343" target="_blank" style="font-weight: bold; color: #1CAAD9;">Sketchfab</a></p></div>
                    </div>
                    <div class="item">
                    <div class="sketchfab-embed-wrapper"> <iframe title="MINIATURE DRAGON -TOY" height="300px" width="100%" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/d524c1ea8d2740c383a18469a31c9fa2/embed"> </iframe> <p style="font-size: 13px; font-weight: normal; margin: 5px; color: #4A4A4A;"> <a href="https://sketchfab.com/3d-models/miniature-dragon-toy-d524c1ea8d2740c383a18469a31c9fa2?utm_medium=embed&utm_campaign=share-popup&utm_content=d524c1ea8d2740c383a18469a31c9fa2" target="_blank" style="font-weight: bold; color: #1CAAD9;"> MINIATURE DRAGON -TOY </a> by <a href="https://sketchfab.com/precise3dmetrlogy?utm_medium=embed&utm_campaign=share-popup&utm_content=d524c1ea8d2740c383a18469a31c9fa2" target="_blank" style="font-weight: bold; color: #1CAAD9;"> PRECISE3DM </a> on <a href="https://sketchfab.com?utm_medium=embed&utm_campaign=share-popup&utm_content=d524c1ea8d2740c383a18469a31c9fa2" target="_blank" style="font-weight: bold; color: #1CAAD9;">Sketchfab</a></p></div>
                    </div>
                    <div class="item">
                    <div class="sketchfab-embed-wrapper"> <iframe title="Ancient yazhi3d scan einscan SP Sample" height="300px" width="100%" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/a8ca26b86e76411c872bcd03d8345ca2/embed"> </iframe> <p style="font-size: 13px; font-weight: normal; margin: 5px; color: #4A4A4A;"> <a href="https://sketchfab.com/3d-models/ancient-yazhi3d-scan-einscan-sp-sample-a8ca26b86e76411c872bcd03d8345ca2?utm_medium=embed&utm_campaign=share-popup&utm_content=a8ca26b86e76411c872bcd03d8345ca2" target="_blank" style="font-weight: bold; color: #1CAAD9;"> Ancient yazhi3d scan einscan SP Sample </a> by <a href="https://sketchfab.com/precise3dmetrlogy?utm_medium=embed&utm_campaign=share-popup&utm_content=a8ca26b86e76411c872bcd03d8345ca2" target="_blank" style="font-weight: bold; color: #1CAAD9;"> PRECISE3DM </a> on <a href="https://sketchfab.com?utm_medium=embed&utm_campaign=share-popup&utm_content=a8ca26b86e76411c872bcd03d8345ca2" target="_blank" style="font-weight: bold; color: #1CAAD9;">Sketchfab</a></p></div>
                    </div>
                    <div class="item">
                    <div class="sketchfab-embed-wrapper"> <iframe title="APJAK" height="300px" width="100%" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/6e14e4fd3e88418d8747c90a2cd9c6d0/embed"> </iframe> <p style="font-size: 13px; font-weight: normal; margin: 5px; color: #4A4A4A;"> <a href="https://sketchfab.com/3d-models/apjak-6e14e4fd3e88418d8747c90a2cd9c6d0?utm_medium=embed&utm_campaign=share-popup&utm_content=6e14e4fd3e88418d8747c90a2cd9c6d0" target="_blank" style="font-weight: bold; color: #1CAAD9;"> APJAK </a> by <a href="https://sketchfab.com/precise3dmetrlogy?utm_medium=embed&utm_campaign=share-popup&utm_content=6e14e4fd3e88418d8747c90a2cd9c6d0" target="_blank" style="font-weight: bold; color: #1CAAD9;"> PRECISE3DM </a> on <a href="https://sketchfab.com?utm_medium=embed&utm_campaign=share-popup&utm_content=6e14e4fd3e88418d8747c90a2cd9c6d0" target="_blank" style="font-weight: bold; color: #1CAAD9;">Sketchfab</a></p></div>
                    </div>
                    <div class="item">
                    <div class="sketchfab-embed-wrapper"> <iframe title="Statue 3D scanning by Einscan(not for sale)" height="300px" width="100%" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/62ff9b0f77764a4ba4e8f49b84a074e1/embed"> </iframe> <p style="font-size: 13px; font-weight: normal; margin: 5px; color: #4A4A4A;"> <a href="https://sketchfab.com/3d-models/statue-3d-scanning-by-einscannot-for-sale-62ff9b0f77764a4ba4e8f49b84a074e1?utm_medium=embed&utm_campaign=share-popup&utm_content=62ff9b0f77764a4ba4e8f49b84a074e1" target="_blank" style="font-weight: bold; color: #1CAAD9;"> Statue 3D scanning by Einscan(not for sale) </a> by <a href="https://sketchfab.com/precise3dmetrlogy?utm_medium=embed&utm_campaign=share-popup&utm_content=62ff9b0f77764a4ba4e8f49b84a074e1" target="_blank" style="font-weight: bold; color: #1CAAD9;"> PRECISE3DM </a> on <a href="https://sketchfab.com?utm_medium=embed&utm_campaign=share-popup&utm_content=62ff9b0f77764a4ba4e8f49b84a074e1" target="_blank" style="font-weight: bold; color: #1CAAD9;">Sketchfab</a></p></div>
                    </div>
                    
                </div>
             </div>
            </div>
        </div>
        <style>
                 .owl-nav button{
                     height:40px;
                     width:40px;
                     border-radius:30px !important;
                 }
                 @media only screen and (min-width: 712px) {
                    .owl-theme .owl-nav [class*=owl-] {
                     margin-left:-26px;
                     margin-right:-26px;
                 }


                 }

                 #owlblog .owl-nav button{
                     background-color:#ff8d1e !important;
                 }
             </style>
    </section>
   <!-- Sample Data section ends-->

   <!--FAQs section start-->
   <section id="faq" class="faq section-padding">
      <div class="container">
         <div class="row faqsectionforscroll">
            <h4 class="text-uppercase text-white mt-2 mb-4 mx-lg-0 mx-2">Frequently asked questions</h4>
            <div class="col-md-12 text-left px-lg-0">
               <h5 class="pre-color" >What kind of technology is used in the EINSCAN H scanner?</h5>
               <div class="left-border">
                  <p class="text-white" >EinScan H is based on hybrid structure light German technology that uses LED and invisible infrared light.
                  </p>
               </div>
               <div class="col-md-12 text-left px-lg-0">
               </div>
               <h5 class="pre-color " >Which country makes the EINSCAN H scanner?</h5>
               <div class="left-border">
                  <p class=" text-white" >This hybrid EINSCAN H scanner is designed in Germany and made in China.</p>
               </div>
               <div class="col-md-12 text-left px-lg-0">
               </div>
               <h5 class="pre-color " >What is the range of scanning in the EINSCAN H scanner?</h5>
               <div class="left-border">
                  <p class=" text-white" >Impressive high-resolution EinScan H captures the full geometry of objects such as artwork or furniture with fine details. The high accuracy of scanned data is up to 1 meter.</p>
               </div>
			   <div class="col-md-12 text-left px-lg-0">
               </div>
               <h5 class="pre-color " >What are the advantages of the EINSCAN H scanner?</h5>
               <div class="left-border">
                  <p class=" text-white" >Impressive high-resolution EinScan H captures the full The built-in color camera in the EinScan H scanner supports full-color texture capturing and scan black color objects too.
</p>
				   <p class=" text-white" >The software is intuitive, user-friendly, and easy to operate.</p>
				    <p class=" text-white" >It can also be hand-held and uses turn-table codes too.</p>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--FAQs section ends-->

   <!--Brochure section start-->
   <section class="section-padding" id="brochure-content">
      <div class="container">
         <div class="row ">
            <div class="col-md-12">
               <h3 class="para">Not sure what 3D Scanner will suit your
                  requirements? </h3>
               <h4 class="para">Download Brochure</h4>
               <a class="btn pre-btn my-2" href="assets/images/brouche/EinScan H-Brochure.pdf" target="_blank">Download</a>
            </div>
         </div>
         <div class="row" id="online-demo-btn">
            <div class="col-md-3">
                <h4 class="para">Book Online Demo</h4>
                <a class="btn pre-btn my-2" href="https://forms.zohopublic.com/virtualoffice20215/form/Bookademoonlineonsite/formperma/v-Zrwhh8zM330ig-4CD_W6rJsqgkKQ7nBEXF2nOr39M" target=_blank>Book Demo</a>
            </div>
         </div>
      </div>
   </section>
   <!--Brochure section ends-->

   <hr class="separator">
   <?php include('includes/footer.php'); ?>

   <!-- bootstrap links-->
   <!-- <script type="text/javascript" src="assets/js/bootstrap.js"></script>
   <script type="text/javascript" src="assets/js/slim.min.js"></script>
   <script type="text/javascript" src="assets/js/bootstrap.bundle.js"></script>
   <script type="text/javascript" src="assets/js/tabs.js"></script> -->
   <!-- bootstrap links-->
   <script src="assets/js/counter.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>

</html>