<?php
session_start();
ini_set('upload_max_filesize', '40000M');
ini_set('post_max_size', '40000M');
ini_set('max_input_time', 300000);
ini_set('max_execution_time', '-1');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <title>3d scanning and 3d insepction software in india Geomagic control x </title>
      <meta name="robots" content="index, follow" />
      <meta name="googlebot" content="index, follow" />
      <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
      <meta name="revisit-after" content="7 days" />
      <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/events_images/control-x.png" />
      <meta name="twitter:card" content="Precise3dm" />
      <meta name="twitter:site" content="@precise3d_m" />
      <meta name="twitter:title" content="Precise3dm" />
      <meta name="twitter:description" content="download Trail and buy Geomagic 3d inspection software in India, get a free demo,  quote for geomagic control X software for evaluation for your projects " />
      <meta property="og:type" content="3D Scanning" />
      <meta property="og:title" content="3d scanning and 3d insepction software in india Geomagic control x " />
      <meta property="og:url" content="https://www.precise3dm.com/geomagic-control-x-3d-inspection-software.php" />
      <meta property="og:image" content="https://www.precise3dm.com/assets/images/events_images/control-x.png" />
      <meta property="og:description" content="download Trail and buy Geomagic 3d inspection software in India, get a free demo,  quote for geomagic control X software for evaluation for your projects " />
    <meta name="description" content="download Trail and buy Geomagic 3d inspection software in India, get a free demo,  quote for geomagic control X software for evaluation for your projects ">
    <meta name="keywords" content="3d geomagic control x software in india, 3d inspection software, geomagic control x price">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/optical-blue-light.css">
    <link rel="stylesheet" href="assets/css/scanner-styles.css">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">
    <link rel="canonical" href="https://www.precise3dm.com/geomagic-control-x-3d-inspection-software.php" />
   <script src="assets/js/jquery-3.6.0.min.js"></script>
   <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "I do not have a 3D CAD file, I have only a 2D drawing. Can I still do 3D inspection in Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, you can still perform 3D inspection in Geomagic Control X without CAD ,just align 3D scan to word coordinate system ,take cross sections and construct features and extract whatever dimensions you want to measure.Treat 3D scan as CAD file as you use them in 2D drafting in CAD."
    }
  },{
    "@type": "Question",
    "name": "Can I import my old Geomagic control and Wrap files into Geomagic Control X ?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Can I import my old Geomagic control and Wrap files into Geomagic Control X ?"
    }
  },{
    "@type": "Question",
    "name": "I have a 3D scanner. Can I directly connect my device to Geomagic software ?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "You can download the hardware plugin and install Scan directly into Geomagic Control X with popular metrology devices from FARO, Hexagon, Creaform, Nikon, Solutionix, and more."
    }
  },{
    "@type": "Question",
    "name": "Is Geomagic software a perpetual or a yearly subscription?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Geomagic software Design X, Control X wrap and Geomagic for Solidworks, all are one-time purchase perpetual license applications. It's impossible to rent or yearly subscribe to Geomagic design x software."
    }
  },{
    "@type": "Question",
    "name": "Do I mandatorily update the Geomagic software AMC every year?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "To receive a frequent update on Geomagic software, the user needs to go for AMC renewal every year. However, it is not mandatory to renew every year. Users can keep using the software version and updates launched during the AMC period."
    }
  },{
    "@type": "Question",
    "name": "What is the difference between Geomagic Control X and Design X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "What is the difference between Geomagic Control X and Design X?"
    }
  },{
    "@type": "Question",
    "name": "Can we 3D scan in Geomagic Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, we can scan directly inside software and work on the scan data using LiveInspect settings. It supports all the major 3D scanner and PCMM solutions in the market for scanning and probing operations."
    }
  },{
    "@type": "Question",
    "name": "Which files can be imported in Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Control X supports the import of .stl, .obj, .ply, .asc, .igs, .stp, .catpart, .sldprt, .asm and many more."
    }
  },{
    "@type": "Question",
    "name": "Can we do CAD modelling in Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, you can use the Curves tool from the toolbar and can sketch and create a 3D model according to your requirement in Control X."
    }
  },{
    "@type": "Question",
    "name": "Why is alignment required in Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Both the Scan data and the CAD data are imported in different cordinate system. Alignment is used to get both the objects in world cordinate system and superimpose one over othe"
    }
  },{
    "@type": "Question",
    "name": "Can i able to edit the scan data according to my cad data?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "No, you cannot. Control X shows you the deviation and generates a report according to the data aligned."
    }
  },{
    "@type": "Question",
    "name": "What kind of inspection can I perform on my model?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "3D & 2D comparison , all kinds of dimensions measuring from co ordinates and GD&T's , Trend Analysis, PMI inspection, Airfoil analysis."
    }
  },{
    "@type": "Question",
    "name": "Can I import just the scan data and perform inspection?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes you can do three types of inspection with only scan data.
1. scan to scan comparison.
2. Scan to 2d drawing inspection
3. You can extract dimensions from scan data."
    }
  },{
    "@type": "Question",
    "name": "Can I show SPC Quality tools in the report of Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Can I show SPC Quality tools in the report of Control X?"
    }
  },{
    "@type": "Question",
    "name": "What formats are available while generating the report for Control X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Control X exports the report in PDF, Excel, Powerpoint, .txt and .csv format."
    }
  }]
}
</script>


<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>
</head>

<body>
    <!-- header start -->
    <?php include('includes/header.php'); ?>
    <!-- header end -->

    <!-- section start-->
    <section id="Geomagic-control-x-banner" class="pt-4">
        <div class="container">
            <div class="row h-300">
            </div>
        </div>
        <div class="container-fluid heading m-320">
            <div class="row ">
                <div class="col-md-12 text-md-left text-center px-2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 software-mobile">
                                <img src="./assets/images/Geomagic-control-x/cx.png" alt="3d-insepction-software-cx" class="software-icons">
                                <h2 class="title text-white">Geomagic Control X</h2>

                                <a class="btn pre-btn my-2" href="https://forms.zohopublic.com/virtualoffice20215/form/Bookademoonlineonsite/formperma/v-Zrwhh8zM330ig-4CD_W6rJsqgkKQ7nBEXF2nOr39M" target=_blank>Fix Up an online demo</a>
                                <a class="btn pre-btn my-2 geomagic-design-top-button" href="#geoform">
                                    <img src="assets/images/download-icon.png" alt="3d-insepction-software" class="download-icon-png-cdx">
                                    DOwnload TRIAL now
                                </a>
                                <p class="text-white text-uppercase">Comprehensive 3D metrology Software </p>
                                <p class="software-header-list">
                                <p class="no-margin-bottom"><embed src="assets/images/download-icon-2-02.svg" height="38px" class="header-arrows"> <span class="header-pointer"> Get Quick Quotation</span></p>
                                <p class="no-margin-bottom"><embed src="assets/images/download-icon-2-02.svg" height="38px" class="header-arrows"> <span class="header-pointer">Talk to our sales Team @ +91-73959 72777</span></p>
                                </p>

                            </div>
                            <div class="col-md-4">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="overview-top-design"></div>
    </section>
    <!-- section end-->

    <!-- Overview section starts-->
    <section id="overview-section" class="pt-4">
        <div class="container-fluid"></div>
        <div class="container overview-container">
            <div class="row">
                <div class="col-md-3" id="overview-heading-text">
                    <a class="btn pre-btn my-2" href="#">OVERVIEW </a>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <p class="overview">Geomagic Control X is a 3D Metrology software that can be connected to 3d scanners, Portable and fixed Coordinate measuring machines, to 3D scan physical objects ,import 3d scan files and perform an advanced level of digital measurements & compare it with original CAD.</p>
                </div>
            </div>
            <div class="row" id="overview-btns">

                <div class="col-xs-6 col-md-6 mobile-features">
                    <a class="btn pre-btn my-2" href="#demo-video">DEMO VIDEOS</a>
                </div>
                <div class="col-xs-6 col-md-5 mobile-specs">
                    <a class="btn pre-btn my-2" href="#application-cx">APPLICATIONS</a>
                </div>

            </div>

    </section>
    <!-- Overview section end-->

    <!-- Key feature section starts-->
    <section id="machine-spec" class="section-padding">
        <div class="container">
            <div class="container">
                <h2 class="text-white text-uppercase kf">KEY FEATURES</h2>
            </div>
            <div id="features">
                <section class="section-padding">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets/images/Geomagic-control-x/ControlX KF1-100.jpg" alt="inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="text-white card-title">3D scanner Plugin & Importing Capabilities</h5>
                                        <p class="card-text geomagic-kf-ppadd">Connect to 3D scanning devices, portable CMM machines and import CAD for even the most-challenging reference models. 3D Scan directly into Geomagic Control X with popular metrology devices from FARO, Hexagon, Creaform, Nikon, Solutionix, and more. Import also geometry from simple text-based formats with the ASCII Reference Geometry importer.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\Geomagic-control-x\ControlX KF2-100.jpg" alt=" 3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">Probing Capabilities </h5>
                                        <p class="card-text">Plugin for Fixed CMMs and portable CMMs to perform small and large object inspection. Predefine the inspection order on CAD data, and let the software guide you with the order sequence to Probe challenging 2D and 3D features, extract CMM points,on physical objects to perform pre-planned inspection.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\Geomagic-control-x\ControlX KF3-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">Large part Inspection</h5>
                                        <p class="card-text">Ensure fast and accurate inspection of large parts using portable CMMs. With the enhanced Move Device functionality, users now have the flexibility and traceability when it comes to repositioning scanning equipment.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\Geomagic-control-x\ControlX KF4-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">History-based inspection </h5>
                                        <p class="card-text">History-based inspection capability enables users to change, modify alignment, replace test objects, and Create repeatable inspection routines that require measurement in different alignment environments. Automatically inspect the most deformed parts, like sheet metal or plastic-moulded components, with repeatable setup.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\Geomagic-control-x\ControlX KF5-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body dark geomagic-kf-hd">
                                        <h5 class="card-title">3D Scan & CAD alignments
                                        </h5>
                                        <p class="card-text">Use surfaces, reference points, features, datum for initial alignment to an advanced level of RPS alignment, the software has more than eight types of alignment procedures that ensure perfect superimposition of 3D Scan into CAD.

                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\Geomagic-control-x\ControlX KF6-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title ">Extract Digital measurements </h5>
                                        <p class="card-text geomagic-kf-ppadd">The software can extract and compare an advanced digital GD&T, 2D, and 3D dimensions between 3D Scan and CAD, the same measurements can be extracted without CAD. Also take advantage of CAD-aware dimensioning and PMI support and comprehensive GD&T callouts.

                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets/images/Geomagic-control-x/ControlX KF7-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">Advanced deviation analysis </h5>
                                        <p class="card-text">Perform advanced-level of deviation analysis on 3D scan file by comparing it to the CAD file. Use information such as boundary, virtual edge, silhouettes and geometric curves.

                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets/images/Geomagic-control-x/ControlX KF8-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">Airfoil and 2D twist Analysis</h5>
                                        <p class="card-text">The Airfoil Analysis tool allows you to analyze the key elements of airfoil profiles in Measured Data by comparing with the Reference Data, also translation and twist rotation can be measured using 2D twist analysis

                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets/images/Geomagic-control-x/ControlX KF9-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">Multiple Results Analysis</h5>
                                        <p class="card-text">Perform 3d inspection with various alignments, Obtain multiple simultaneous results and enable faster comparison and analysis. Gain an understanding of the root causes of production issues being experienced by your factory

                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card control-x-card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets/images/Geomagic-control-x/ControlX KF10-100.jpg" alt="3d inspection software in india">
                                    <div class="card-body geomagic-kf-hd">
                                        <h5 class="card-title">Custom Reporting</h5>
                                        <p class="card-text">Easily create inspection reports to analyze your results, Use data table templates for more flexible reporting, edit header and add your company logo. Insert result navigator information into reports, Export to a PDF.

                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>
            </div>
        </div>
    </section>
    <!-- Key feature section end-->

    <hr class="separator">

    <!-- Workflow Section Starts Here -->
    <section id="workflow">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="text-white text-uppercase kf">WORKFLOW</h2>
                </div>

            </div>

        </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 workflow-background">
                    <img src="assets/images/workflows/Workflows/controlx-01.jpg" alt="3d inspection software in india" class="img-fluid">
                </div>
            </div>

    </section>
    <!-- Workflow Section ends Here -->



    <!-- Demo video section start-->
    <section id="demo-video" class="pt-4 demoVid">
        <div class="container">
        <h4 class="text-white text-uppercase ">Latest features in Geomagic Control X 2022</h4>
        <p class="text-white" style="font-family: sans-serif;background-color: #242424;">Geomagic Control X 2022 has geared with easy and extraordinary functionalities that help better decision making, faster inspection process, improve inspection workflows, reduce risk and cost-efficient</p>
         <div class="row">
            <div class="col-md-7">
            <ol style="padding-left: 18px;">
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Visual Scripting enables customization and automation of Inspection workflows</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Hexagon Structured Light Scanners now allow you to scan within Control X</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Enhances productivity and performance to handle mesh</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Update native CAD file import along with PMI for most formats</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Unequal tolerance zone for surface profile</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Meshes can also be used as reference data</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">CAD tessellated mesh segmentation has been improved.
</li>


</ol>
</div>
<div class="col-md-5 ">
                    <iframe width="100%" height= "215px" src="https://www.youtube.com/embed/eW3GteT7lUA" >
                    </iframe>
                </div>
         </div>
        


        

            <h2 class="text-white text-uppercase kf demV">DEMO VIDEO</h2>

            <div class="row">
                <div class="col-md-8 main-demo-video">
                    <iframe width="100%" height="345" src="https://www.youtube.com/embed/CgdYX1vDQj4" allow="autoplay" id="geomagic_controlX_vdo">
                    </iframe>
                </div>
                <div class="col-md-4 geomagic_yvdo_scroll">
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo1.png" id="geomagic_controlX_vdo1">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo2.png" id="geomagic_controlX_vdo2">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo3.png" id="geomagic_controlX_vdo3">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo4.png" id="geomagic_controlX_vdo4">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo5.png" id="geomagic_controlX_vdo5">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo6.png" id="geomagic_controlX_vdo6">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_controlX_vdo7.png" id="geomagic_controlX_vdo7">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading">Geomagic Control X</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- Demo video section ends-->

    <!-- Application Section Starts Here -->
    <section class="applications" id="application-cx">
        <div class="container">
            <h2 class="text-white text-uppercase kf">APPLICATIONS</h2>
        </div>
        <div class="container">
             <div class="row">
    <div class="col-md-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/scan-to-cad-comparison.php" target=_blank  style="font-size:13px;width:100%;">Scan to CAD Comparison</a></div>
    <div class="col-md-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/cad-to-cad-comparison.php" target=_blank  style="font-size:13px;width:100%;">CAD to CAD comparison</a></div>
    <div class="col-md-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/2d-3d-curvature-comparison.php" target=_blank style="font-size:13px;width:100%;"> 2D /3D Curvature comparison</a></div>
    
     <div class="col-md-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/digital-alignment.php" target=_blank  style="font-size:13px;width:100%;">Digital alignment</a></div>
     <div class="col-md-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/3d-dimensional-analysis.php" target=_blank style="font-size:13px;width:100%;">3D dimensional analysis</a></div>
     <div class="col-md-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/part-to-part-comparison.php" target=_blank style="font-size:13px;width:100%;">Part to part comparison</a></div>
 
         <div class="col-4"> <a class="btn pre-btn my-2" href="https://www.precise3dm.com/digital-volume-analysis.php" target=_blank style="font-size:13px;width:100%;">Digital volume analysis </a></div>
        <div class="col-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/digital-gd&t-analysis.php" target=_blank style="font-size:13px;width:100%;"> Digital GD&T Analysis</a></div>
      
 
    
         <div class="col-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/pmi-based-inspection.php" target=_blank  style="font-size:13px;width:100%;">PMI Based inspection</a></div>
         
           <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/automation-inspection.php" target=_blank style="font-size:13px;width:100%;">Automation inspection</a> </div>
        <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/wall-thickness-analysis.php" target=_blank style="font-size:13px;width:100%;">Wall thickness analysis</a></div>
         <div class="col-4"><a class="btn pre-btn my-2"  href="#" target=_blank  style="font-size:13px;width:100%;">Virtual boundary analysis</a></div>
         
         <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/digital-damage-assessment.php" target=_blank style="font-size:13px;width:100%;">Digital damage assessment</a> </div>
        <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/digital-damage-assessment.php" target=_blank style="font-size:13px;width:100%;">Boundary comparison</a></div>
         <div class="col-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/airfoil-twist-analysis.php" target=_blank  style="font-size:13px;width:100%;">Airfoil Twist analysis</a></div>
        
          <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/airfoil-measurement.php" target=_blank style="font-size:13px;width:100%;">Airfoil measurements</a> </div>
        <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/deformation-analysis.php" target=_blank style="font-size:13px;width:100%;">Deformation analysis</a></div>
         <div class="col-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/dent-corrosion-analysis.php" target=_blank  style="font-size:13px;width:100%;">Dent & Corrosion Analysis</a></div>
         
           <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/crash-analysis.php" target=_blank style="font-size:13px;width:100%;">Crash Analysis</a> </div>
        <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/trend-analysis.php" target=_blank style="font-size:13px;width:100%;">Trend Analysis</a></div>
         <div class="col-4"><a class="btn pre-btn my-2"  href="#" target=_blank  style="font-size:13px;width:100%;">Predictive failure analysis</a></div>
         
               <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/digital-measurement-extraction-of-shape.php" target=_blank style="font-size:13px;width:100%;">Digital measurement extraction of digitized shape</a> </div>
                   <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/digital-gap-and-flush-measurement.php" target=_blank style="font-size:13px;width:100%;">Digital gap and flush measurement</a></div>
  </div>
            <!--<ul class="app-list">
                <li>Scan to CAD Comparison</li>
                <li>CAD to CAD comparison</li>
                <li>2D /3D Curvature comparison</li>
                <li>Digital alignment</li>
                <li>3D dimensional analysis</li>
                <li>Part to part comparison</li>
                <li>Digital volume analysis </li>
                <li>Digital GD&T Analysis</li>
                <li>Digital measurement extraction of digitized shape</li>
                <li>Digital gap and flush measurement</li>
                <li>PMI Based inspection</li>
                <li>Automation inspection</li>
                <li>Wall thickness analysis</li>
                <li>Virtual boundary analysis</li>
                <li>Digital damage assessment</li>
                <li>Boundary comparison</li>
                <li>Airfoil Twist analysis</li>
                <li>Airfoil measurements</li>
                <li>Deformation analysis</li>
                <li>Dent & Corrosion Analysis</li>
                <li>Crash Analysis</li>
                <li>Trend Analysis</li>
                <li>Predictive failure analysis</li>
            </ul>-->
        </div>
        </div>
        </div>
    </section>
    <!-- Application Section Ends Here -->

    <hr class="separator">

    <!--FAQs section start-->
    <section id="faq" class="faq section-padding">
        <div class="container">
            <div class="row">
                <h4 class="text-uppercase text-white mt-2 mb-4 mx-lg-0 mx-2">Frequently asked questions </h4>
                <div class="row faqsectionforscroll ">
            
            <div class="col-md-11 text-left px-lg-0 ">
            <h5 class="pre-color" >I do not have a 3D CAD file, I have only a 2D drawing. Can I still do 3D inspection in Control X?
</h5>
                <div class="left-border">
                    <p class="text-white" >Yes, you can still perform 3D inspection in Geomagic Control X without CAD ,just align 3D scan to word coordinate system ,take cross sections and construct features and extract whatever dimensions you want to measure.Treat 3D scan as CAD file as you use them in 2D drafting in CAD.
</p>
                </div>

                <h5 class="pre-color " >Can I import my old Geomagic control and Wrap files into Geomagic Control X ?
</h5>
                <div class="left-border">
                    <p class="text-white " >You can import legacy Geomagic files directly into Geomagic control X.
</p>
                </div>

                <h5 class="pre-color " >I have a 3D scanner. Can I directly connect my device to Geomagic software ?
</h5>
                <div class="left-border">
                    <p class="text-white " >You can download the hardware plugin and install Scan directly into Geomagic Control X with popular metrology devices from FARO, Hexagon, Creaform, Nikon, Solutionix, and more.

                    </p>
                </div>

                <h5 class="pre-color " >Is Geomagic software a perpetual or a yearly subscription?
</h5>
                <div class="left-border">
                    <p class="text-white " >Geomagic software Design X, Control X wrap and Geomagic for Solidworks, all are one-time purchase perpetual license applications. It's impossible to rent or yearly subscribe to Geomagic design x software.

                    </p>
                </div>

                <h5 class="pre-color " >Do I mandatorily update the Geomagic software AMC every year?
</h5>
                <div class="left-border">
                    <p class="text-white " >To receive a frequent update on Geomagic software, the user needs to go for AMC renewal every year. However, it is not mandatory to renew every year. Users can keep using the software version and updates launched during the AMC period.
</p>
                </div>


                <h5 class="pre-color " >What is the difference between Geomagic Control X and Design X?
</h5>
                <div class="left-border">
                    <p class="text-white " >Control X is an inspection & metrology software used for comparison purposes where as Design X is a reverse engineering software
</p>
                </div>
                <h5 class="pre-color " >Can we 3D scan in Geomagic Control X?
</h5>
                <div class="left-border">
                    <p class="text-white " >Yes, we can scan directly inside software and work on the scan data using LiveInspect settings. It supports all the major 3D scanner and PCMM solutions in the market for scanning and probing operations.
</p>
                </div>
                <h5 class="pre-color " >Which files can be imported in Control X?
</h5>
                <div class="left-border">
                    <p class="text-white " >Control X supports the import of .stl, .obj, .ply, .asc, .igs, .stp, .catpart, .sldprt, .asm and many more.
</p>
                </div>
                <h5 class="pre-color " >Can we do CAD modelling in Control X?
</h5>
                <div class="left-border">
                    <p class="text-white " >Yes, you can use the Curves tool from the toolbar and can sketch and create a 3D model according to your requirement in Control X.
</p>
                </div>
                <h5 class="pre-color " >Why is alignment required in Control X?</h5>
                <div class="left-border">
                    <p class="text-white " >Both the Scan data and the CAD data are imported in different cordinate system. Alignment is used to get both the objects in world cordinate system and superimpose one over other.</p>
                </div>
                <h5 class="pre-color " >Can i able to edit the scan data according to my cad data? </h5>
                <div class="left-border">
                    <p class="text-white " >No, you cannot. Control X shows you the deviation and generates a report according to the data aligned.
</p>
                </div>
                <h5 class="pre-color " >What kind of inspection can I perform on my model?
</h5>
                <div class="left-border">
                    <p class="text-white " >3D & 2D comparison , all kinds of dimensions measuring from co ordinates and GD&T's , Trend Analysis, PMI inspection, Airfoil analysis.
 </p>
                </div>
                <h5 class="pre-color " >Can I import just the scan data and perform inspection?</h5>
                <div class="left-border">
                    <p class="text-white " >Yes you can do three types of inspection with only scan data.<br>
1.scan to scan comparison.<br>
2. Scan to 2d drawing inspection <br>
3. You can extract dimensions from scan data</p>
                </div>
                <h5 class="pre-color " >Can I show SPC Quality tools in the report of Control X?
</h5>
                <div class="left-border">
                    <p class="text-white " >Yes you can show SPC tools from the Chart option available in the Insert toolbar option.
</p>
                </div>
                <h5 class="pre-color " >What formats are available while generating the report for Control X?
</h5>
                <div class="left-border">
                    <p class="text-white " >Control X exports the report in PDF, Excel, Powerpoint, .txt and .csv format.
  </p>
                </div>



            </div>
            </div>
        </div>

    </section>
    <!--FAQs section ends-->

    <hr class="separator">
      <div class="container sectioning" style="margin-top:30px;margin-bottom:30px;" id="geoform">
        <div class="row inside">
            <div class="col-lg-5" style="background-color: #ffffff"  >
                <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                              
                                <div style='width: 100%'><a target='_blank' href='https://drive.google.com/file/d/1BLbwwv3KzYUEvn4GHolE3FwC3XvEk4Cc/view?usp=sharing'><button class='btn pre-btn my-2'>Download Geomagic Control X</button></a></div>
                                <p>Why should you evaluate Geomagic Reverse engineering software from precise 3d?</p>
                                <ul>
                                    <li  style='list-style-type: disclosure-closed;'>We shall recommend you the right software for your reverse engineering application</li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall give you free training during the evaluation </li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall help you with a free benchmark project if you want to model any of your 3d scan data or inspect to cad </li>
                                </ul>
                        </div>";
                    } else {
                        echo "<div class='row status-div'>
                                <p class='status-message'>Oops...Something went wrong, please try again
                            </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <form method="POST" action="uploadgeomagiccontrolx.php" id="regForm" enctype="multipart/form-data" onsubmit="disablebutton();">

                        <div class="tab-step-form" data-form-type="contact">
                            <h2 class="text text-uppercase kf">DOwnload TRIAL now</h2>
                              
                            <p>Thanks for your interest in downloading the geomagic Control x software trial. Precise3dm is ''authorized geomagic software resellers in india to take care of 3d sytems geomagic software sales, pre &post sale support for geomagic reverse engineering and inspection software.
</p><p>
Please fill the form and instantly link will be activated to get yourself started with geomagic solutions 
</p>
                            <h5 style="margin-bottom:10px" >Contact Information</h5>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="name" name="name" placeholder="Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control required" id="email" name="email" placeholder="Email Address *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="contactnumber" name="contactnumber" placeholder="Mobile Number *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyname" name="companyname" placeholder="Company Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyaddress" name="companyaddress" placeholder="Company Address *" required />
                            </div>
                            <span>Do you have a 3d scanner in-house? </span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="homeavailable" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="homeavailable" value="No"> No</label>
                            </div>
                            <span>Do you need a demo during the evaluation?</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="needdemo" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="needdemo" value="No"> No</label>
                            </div>
                            <span>Do you also need a quote for Geomagic Control X?</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="needquote" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="needquote" value="No"> No</label>
                            </div>
                            
                        </div>
                        <button type="submit" class="btn btn-success" id="submit" style="margin-top:10px;">Submit <img src="loader2.gif" id="loader" width="25" style="display: none;" /></button>
 <p style="margin-top:20px;">Why should you evaluate Geomagic Reverse engineering software from precise 3d?</p>
                                <ul>
                                    <li  style='list-style-type: disclosure-closed;'>We shall recommend you the right software for your reverse engineering application</li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall give you free training during the evaluation </li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall help you with a free benchmark project if you want to model any of your 3d scan data or inspect to cad </li>
                                </ul>

                    </form>
                <?php } ?>
            </div>
        </div>
        </div>
    <!--style for download btns-->
    <style>
    .form-popup-bgcx,
    .form-popup-bg2,
    .form-popup-bg3,
    .form-popup-bg4{
      position:absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      flex-direction: column;
      align-content: center;
      justify-content: center;
    }
    .form-popup-bgcx,
    .form-popup-bg2,
    .form-popup-bg3,
    .form-popup-bg4{
      position: fixed;
      left: 0;
      top: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(94, 110, 141, 0.9);
      opacity: 0;
      visibility: hidden;
      -webkit-transition: opacity 0.3s 0s, visibility 0s 0.3s;
      -moz-transition: opacity 0.3s 0s, visibility 0s 0.3s;
      transition: opacity 0.3s 0s, visibility 0s 0.3s;
      overflow-y: auto;
      z-index: 10000;
    }
    .form-popup-bgcx.is-visible,
    .form-popup-bg2.is-visible,
    .form-popup-bg3.is-visible,
    .form-popup-bg4.is-visible{
      opacity: 1;
      visibility: visible;
      -webkit-transition: opacity 0.3s 0s, visibility 0s 0s;
      -moz-transition: opacity 0.3s 0s, visibility 0s 0s;
      transition: opacity 0.3s 0s, visibility 0s 0s;
    }
    .form-container {
    background-color: #2d3638;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
    display: flex;
    flex-direction: column;
    width: 100%;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
    position:relative;
  padding: 40px;
  color: #fff;
}
.close-button {
  background:none;
  color: #fff;
  width: 40px;
  height: 40px;
  position: absolute;
  top: 0;
  right: 0;
  border: solid 1px #fff;
}
    #downloadRecx input + label,
    #downloadDIG input + label,
     #downloadSRG input + label,
    #downloadDSB input + label{
        font-weight: 100 !important;
        font-family: 'firasan-extrathin';
        font-size: 13px;
    }
    </style>
        <?php
            if (isset($_SESSION['status'])) {
                if ($_SESSION['status'] == "success") {
                    echo "<div class='row status-div'>
                        <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/Purchase guide.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                    </div>";
                } else {
                    echo "<div class='row status-div'>
                            <p class='status-message'>Oops...Something went wrong, please try again
                        </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                }
                unset($_SESSION['status']);
            } else { ?>
                <div class="form-popup-bgcx">
                  <div class="form-container">
                    <button id="btnCloseForm" class="close-button">X</button>
                    <form method="POST" action="downloadRecx.php" id="downloadRecx" enctype="multipart/form-data" onsubmit="disablebutton();">
                	 <div class="form-group">
                               <input type="text" class="form-control required" id="name_one" name="name_pop"  placeholder="Name *" onblur="validate()" required />
                                </div>
                               <div class="form-group">
                               <input type="email" class="form-control required" id="email_one" name="email_pop"  onblur="validate()" placeholder="Email Address *" required />
                                            </div>
                               <div class="form-group">
                                <input type="text" class="form-control required" id="contactnumber_one" name="contactnumber_pop"  onblur="validate()" placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"/>
                                            </div>
                           <a href=""><button type="submit" class="btn btn-success submit_pop"  id="submit" onclick="window.open('assets/images/precise_brochure_pdf/Purchase guide.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                    </form>
                	<?php } ?>
                	
                	
                  </div>
                </div>
                    
                <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                                    <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/DX-CX Installation Guide.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                                                </div>";
                    } else {
                        echo "<div class='row status-div'>
                                                        <p class='status-message'>Oops...Something went wrong, please try again
                                                    </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg2">
                        <div class="form-container">
                            <button id="btnCloseForm2" class="close-button">X</button>
                            <form method="POST" action="download_DIGcx.php" id="downloadDIG" enctype="multipart/form-data" onsubmit="disablebutton();">
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="name_dig" name="name_dig" placeholder="Name *" required />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control required" id="email_dig" name="email_dig" placeholder="Email Address *" required />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_dig" name="contactnumber_dig"  placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                                </div>
                                <a href=""><button type="submit" class="btn btn-success submit-dig" id="submit" onclick="window.open('assets/images/precise_brochure_pdf/DX-CX Installation Guide.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                            </form>
                        <?php } ?>
                        </div>
                    </div>
                    
                    <!--three-->
                    <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                                    <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/Geomagic System Requirements.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                                                </div>";
                    } else {
                        echo "<div class='row status-div'>
                                                        <p class='status-message'>Oops...Something went wrong, please try again
                                                    </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg3">
                        <div class="form-container">
                            <button id="btnCloseForm3" class="close-button">X</button>
                            <form method="POST" action="download_SRGcx.php" id="downloadSRG" enctype="multipart/form-data" onsubmit="disablebutton();">
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="name_srg" name="name_srg" placeholder="Name *" required />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control required" id="email_srg" name="email_srg" placeholder="Email Address *" required />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_srg" name="contactnumber_srg"  placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                                </div>
                                <a href=""><button type="submit" class="btn btn-success submit-srg" id="submit" onclick="window.open('assets/images/precise_brochure_pdf/Geomagic System Requirements.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                            </form>
                        <?php } ?>
                        </div>
                    </div>
                    <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                                    <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/Precise Geomagic DesignX Brochure.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                                                </div>";
                    } else {
                        echo "<div class='row status-div'>
                                                        <p class='status-message'>Oops...Something went wrong, please try again
                                                    </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg4">
                        <div class="form-container">
                            <button id="btnCloseForm4" class="close-button">X</button>
                            <form method="POST" action="download_DSBcx.php" id="downloadDSB" enctype="multipart/form-data" onsubmit="disablebutton();">
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="name_dsb" name="name_dsb" placeholder="Name *" required />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control required" id="email_dsb" name="email_dsb" placeholder="Email Address *" required />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_dsb" name="contactnumber_dsb"  placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                                </div>
                                <a href=""><button type="submit" class="btn btn-success submit-dsb" id="submit" onclick="window.open('assets/images/precise_brochure_pdf/Geomagic Control X Brochure.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                            </form>
                        <?php } ?>
                        </div>
                    </div>
    <!--Brochure section start-->
    <section class="section-padding" id="brochure-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="para">Not sure what reverse engineering software from Geomagic will suit your requirement?</h3><br>
                    <h4 class="para">Download reverse engineering software purchase Guide</h4>
                    <a class="btn pre-btn my-2" id="btnOpenForm">Download</a>
                </div>
            </div>
            <div class="row" id="online-demo-btn">
                <div class="col-md-4">
                    <h4 class="para">Download Installation Guide</h4>
                    <a class="btn pre-btn my-2" id="digcx_downloadbtn">Download</a>
                </div>
                <div class="col-md-4">
                    <h4 class="para">System Requirements Guide</h4>
                    <a class="btn pre-btn my-2" id="srgcx_downloadbtn" href="assets/images/precise_brochure_pdf/Geomagic Control X Brochure.pdf" target="_blank">Download</a>
                </div>
                <div class="col-md-4">
                    <h4 class="para">Download Software Brochure</h4>
                    <a class="btn pre-btn my-2" id="dsbcx_downloadbtn"  target="_blank">Download</a>
                </div>
            </div>
        </div>
    </section>
    <!--Brochure section ends-->
    <!--script for download buttons-->
    <script>
        $(document).ready(function(){
            function emptyInputs(){
                if($("#name_one").val() == "" || $("#email_one").val() == "" || $("#contactnumber_one").val() == ""){
                    $("#downloadRecx .submit_pop").attr('disabled', true);
                }
            }
            function emptyInputs2(){
                if($("#name_dig").val() == "" || $("#email_dig").val() == "" || $("#contactnumber_dig").val() == ""){
                    $("#downloadDIG .submit-dig").attr('disabled', true);
                }
            }
            function emptyInputs3(){
                if($("#name_srg").val() == "" || $("#email_srg").val() == "" || $("#contactnumber_srg").val() == ""){
                    $("#downloadSRG .submit-srg").attr('disabled', true);
                }
            }
            function emptyInputs4(){
                if($("#name_dsb").val() == "" || $("#email_dsb").val() == "" || $("#contactnumber_dsb").val() == ""){
                    $("#downloadDSB .submit-dsb").attr('disabled', true);
                }
            }
            $(document).on("keyup blur" , "#downloadRecx input", function(){
                if($(this).valid() == true){
                   $("#downloadRecx .submit_pop").removeAttr('disabled');
                   emptyInputs();
                }
                else{
                   $("#downloadRecx .submit_pop").attr('disabled', true);
                }
            });
            $(document).on("keyup blur" , "#downloadDIG input", function(){
                if($(this).valid() == true){
                  $("#downloadDIG .submit-dig").removeAttr('disabled');
                  emptyInputs2();
                }
                else{
                    $("#downloadDIG .submit-dig").attr('disabled', true);
                }
            });
            $(document).on("keyup blur" , "#downloadSRG input", function(){
                if($(this).valid() == true){
                  $("#downloadSRG .submit-srg").removeAttr('disabled');
                  emptyInputs3();
                }
                else{
                    $("#downloadSRG .submit-srg").attr('disabled', true);
                }
            });
            $(document).on("keyup blur" , "#downloadDSB input", function(){
                if($(this).valid() == true){
                  $("#downloadDSB .submit-dsb").removeAttr('disabled');
                  emptyInputs4();
                }
                else{
                    $("#downloadDSB .submit-dsb").attr('disabled', true);
                }
            });
            $.validator.addMethod("email_check", function(value, element) {
                var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                if (regex.test(value)) {
                    return true
                } else {
                    return false
                }
            });
            $("#downloadRecx").validate({
                rules: {
                    name_pop: {
                        required: true,
                    },
                    email_pop: {
                        required: true,
                        email_check: true,
                    },
                    contactnumber_pop:{
                        required:true,
                        minlength: 10,
                    },
                },
                messages:{
                    email_pop:{
                        email_check:"Please enter the valid email"
                    },
                }
            });
            $("#downloadDIG").validate({
                rules: {
                    name_dig: {
                        required: true,
                    },
                    email_dig: {
                        required: true,
                        email_check: true,
                    },
                    contactnumber_dig:{
                        required:true,
                        minlength: 10,
                    },
                },
                messages:{
                    email_dig:{
                        email_check:"Please enter the valid email"
                    }
                }
            });
            $("#downloadSRG").validate({
                rules: {
                    name_srg: {
                        required: true,
                    },
                    email_srg: {
                        required: true,
                        email_check: true,
                    },
                    contactnumber_srg:{
                        required:true,
                        minlength: 10,
                    },
                },
                messages:{
                    email_srg:{
                        email_check:"Please enter the valid email"
                    }
                }
            });
            $("#downloadDSB").validate({
                rules: {
                    name_dsb: {
                        required: true,
                    },
                    email_dsb: {
                        required: true,
                        email_check: true,
                    },
                    contactnumber_dsb:{
                        required:true,
                        minlength: 10,
                    },
                },
                messages:{
                    email_dsb:{
                        email_check:"Please enter the valid email"
                    }
                }
            });
        });
                        
    </script>
  <!--script ends for download btns-->

    <hr class="separator">
    <?php include('includes/footer.php'); ?>

    <!-- bootstrap links-->
    <!-- <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/slim.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="assets/js/tabs.js"></script> -->
    <script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    <!-- bootstrap links-->
    <script src="assets/js/counter.js"></script>
    
    <script>
function closeForm() {
  $('.form-popup-bgcx').removeClass('is-visible');
}
$(document).ready(function($) {
  

  /* Contact Form Interactions */
  $('#btnOpenForm').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bgcx').addClass('is-visible');
  });
  
  $('#digcx_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg2').addClass('is-visible');
  });
  $('#srgcx_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg3').addClass('is-visible');
  });
  $('#dsbcx_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg4').addClass('is-visible');
  });
  
    //close popup when clicking x or off popup
  $('.form-popup-bgcx').on('click', function(event) {
    if ($(event.target).is('.form-popup-bgcx') || $(event.target).is('#btnCloseForm')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg2').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg2') || $(event.target).is('#btnCloseForm2')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg3').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg3') || $(event.target).is('#btnCloseForm3')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg4').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg4') || $(event.target).is('#btnCloseForm4')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  
  
  });
  </script>
</body>

</html>