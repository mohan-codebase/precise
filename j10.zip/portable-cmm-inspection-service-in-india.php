<!doctype html>
<html lang="en">
   <head><meta charset="euc-kr">
      <!-- Required meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <title>CMM inspection service in india | Portable CMM inspection</title>
      <meta name="description" content="Presice3dM is the best Portable CMM inspection service provider in India, FARO edge Arm for onsite (outsource) CMM inspection service. non-contact portable measurement Get the best quote">
      <meta name="keywords" content="cmm inspection services in india, cmm inspection service, cmm onsite inspection services, portable cmm inspection, get quote">
      <meta name="robots" content="index, follow" />
      <meta name="googlebot" content="index, follow" />
      <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
      <meta name="revisit-after" content="7 days" />
      <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/ON-SITE CMM INSPECTION SERVICE.png" />
      <meta name="twitter:card" content="Precise3dm" />
      <meta name="twitter:site" content="@precise3d_m" />
      <meta name="twitter:title" content="Precise3dm" />
      <meta name="twitter:description" content="Presice3dM is the best Portable CMM inspection service provider in India, FARO edge Arm for onsite (outsource) CMM inspection service. non-contact portable measurement Get the best quote" />
      <meta property="og:type" content="3D Scanning" />
      <meta property="og:title" content="CMM inspection service in india | Portable CMM inspection" />
      <meta property="og:url" content="https://www.precise3dm.com/portable-cmm-inspection-service-in-india.php" />
      <meta property="og:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/ON-SITE CMM INSPECTION SERVICE.png" />
      <meta property="og:description" content="Presice3dM is the best Portable CMM inspection service provider in India, FARO edge Arm for onsite (outsource) CMM inspection service. non-contact portable measurement Get the best quote" />
      
      <!--bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <link rel="stylesheet" href="assets/css/optical-blue-light.css">
      <link rel="stylesheet" href="assets/css/styles.css">
      <link rel="stylesheet" href="assets/css/portable-cmm.css">
      <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">
      <script src="assets/js/jquery-3.6.0.min.js"></script>
      <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [{
        "@type": "Question",
        "name": "Where can I avail portable 3d CMM service in India?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Fill in the form, and we will be able to bring our portable machines from your nearby locations to your factory to perform onsite CMM ins[ection service.Geomagic wrap software alignment method."
        }
      }, {
        "@type": "Question",
        "name": "How to avail portable CMM inspection service?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "You need to fill the form with the size of the appropriate components to measure, so we can choose the right 3D CMM arm and bring them to your location."
        }
      }, {
        "@type": "Question",
        "name": "What is the accuracy of a portable CMM machine?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Measurement Accuracy of portable 3D CMM machines is generally starting from 25 microns to 50 microns."
        }
      }, {
        "@type": "Question",
        "name": "What are Portable 3D CMM machines?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Portable 3D CMM machines are used to extract 3D coordinates of points of the object using probe needles at the end. Later these points are used to extract 2D and 3D dimensional information."
        }
      },{
        "@type": "Question",
        "name": "What is the cost of a portable 3d CMM inspection service in India?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "The price of portable CMM inspection service in 2021 is calculated on a per hour basis starts from 1000 to 1500 per hour. These machines are also given on a per-day rental basis that starts from 10 to 18K per day based on the arm length"
        }
      }]
    }
    </script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>
   </head>
   <body>
      <!-- header start -->
      <?php include('includes/header.php');?>
      <!-- header end -->
       
      <!-- section start-->
      <section id="portable_cmm_banner" class="pt-4">
         <div class="container">
            <div class="row h-300">
            </div>
            <div class="row">
                <div class="col-12 text-left">
                    <a href="javascript:" class="btn pre-btn">call us now</a>
                </div>
            </div>
         </div>
         <div class="container-fluid heading m-320">
            <div class="row ">
               <div class="col-md-12 text-md-left text-center px-2">
                  <div class="container">
                     <h2 class="title text-white">PORTABLE CMM INSPECTION SERVICES</h2>
                     <p class="text-white text-uppercase">MEASUREMENT AT YOUR PLACE</p>
                     <a class="btn cmm-btn my-3" href="https://www.precise3dm.com/3d-scanning-form.php" target=_blank>CMM Inspection Service</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- section end-->
       
      <!-- Overview section starts-->
    <section id="cmm-overview" class="pt-4">
        <div class="container overview-container">
            <div class="row">
                <div class="col-md-6">
                    <div class="py-5">
                    <a class="overview-cmm" href="#">OVERVIEW</a>
                    </div>
                    <p class="overview-cmmpara pb-4">
                        PRECISE3DM A portable CMM inspection service helps the customer with the 3D measurement of the surface geometry of an object. We use a portable 3D CMM machine that can be packed up and moved from station to station or site to site. Portable CMM generally takes an articulated arm with six or seven rotary axes with a rotary encoder. Portable CMMs offer measurement capabilities that are more flexible, convenient and allow for measurements at the job site, especially those bigger die casting and large pumps, fixtures, etc
                    </p>
                </div>
                <div class="col-md-6 d-flex justify-content-center align-items-center">
                    <div class="my-auto mb-4">
                        <img src="assets/images/portable-cmm/overview-img.png" alt="CMM-inspection-service-india" class="img-fluid">
                    </div>
                </div>
            </div>
    </section>
    <!-- Overview section end-->
       
      <!-- section start-->
      <section id="key-feature" class="pre-bg-black question text-white py-5">
         <div class="container">
            <div class="row">
               <h3 class="text-uppercase text-left px-md-none mb-4">
                  Key Features
               </h3>
               <div class="col-md-12 text-left">
               <ul class="cmm-kful ml-2">
                        <li>
                        Our Portable CMM machines are often used for inspection of heavy items or components that are difficult to bring into a fixed CMM facility for measurement.
                        </li>
                        <li>
                        We provide portable 3D CMM inspection service pan India with our various range of portable CMM machines installed in many places of the country to enable PRECISE3DM pan India customers to avail Portable 3D CMM inspection services.
                        </li>
                        <li>
                        Portable CMMs are lightweight and easy to bring from one location to another, whether across a shop floor or to another factory in a different city, so we can carry portable inspection measurements across the country.
                        </li>
                        <li>
                        Our Portable CMM machines are up to date calibrated, and our CMM measurement service is at Aforbale cost. Portable CMM is used to inspect heavy components which are difficult to carry on to a fixed CMM and do not require close tolerances.
                        </li>
                    </ul>
               </div>
            </div>
         </div>
      </section>
      <!-- section end-->
       
      <hr class="separator py-2">
       
      <!--section start-->
      <section id="machine-spec" class="section-padding">
         <div class="container">
            <div class="col-md-12 bg-lite-black text-center">
            <h2 class="text-white text-uppercase text-center py-4">Machine specification</h2>
            </div>
            <div class="table-responsive pb-5">
               <table class="table table-bordered text-white mb-0 cmm-spectable">
                  <thead>
                     <tr>
                        <th>Measurement Range</th>
                        <th>Repeatability</th>
                        <th>Accuracy^2</th>
                        <th>Accuracy^3</th>
                        <th>FaroArm Weight</th>
                     </tr>
                  </thead>
                  <tbody>
                      <tr>
                          <td></td>
                          <td>7 Axis</td>
                          <td>7 Axis_2</td>
                          <td>8-Axis System</td>
                          <td>7 Axis_3</td>
                      </tr>
                      <tr>
                          <td>1.8m 6ft</td>
                          <td>0.024 mm 0.0009 in</td>
                          <td>+/- 0.034 mm +/- 0.001 in</td>
                          <td>+/- 0.034 mm +/- 0.0013 in</td>
                          <td>10.7kg 23.6lb</td>
                      </tr>
                      <tr>
                          <td>2.7m 9ft</td>
                          <td>0.029 mm 0.0011 in</td>
                          <td>+/- 0.041 mm +/- 0.0016 in</td>
                          <td>+/- 0.041 mm +/- 0.0016 in_2</td>
                          <td>10.9kg 24.1lb</td>
                          
                      </tr>
                      <tr>
                            <td>3.7m 12ft"</td>
                            <td>0.064 mm 0.0025 in</td>
                            <td>+/- 0.091 mm +/- 0.0035 in</td>
                            <td>+/- 0.091 mm +/- 0.0035 in_2</td>
                            <td>11.3kg 24.9lb</td>
                      </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </section>
      <!--section end-->
       
      <hr class="separator py-2">
       
      <!-- section start-->
      <section id="gallery" class="pre-bg-grey section-padding">
         <div class="container">
            <div class="row py-3">
               <div class="col-md-6 scanning-service px-lg-4">
                  <p class="text-white text-uppercase">Image Gallery</p>
                  <div class="my-2">
                     <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner scanning3d-figcapnew">
                           <div class="carousel-item active">
                              <img src="assets/images/portable-cmm/image-gallery.jpg" class="img-fluid " alt="CMM-inspection-service-india">
                              <figcaption>EinScan handheld 3D Scanners are portable and easy to use, supporting versatile scan modes including Handheld Rapid Scan, 
                              Handheld HD Scan, and Fixed Scan with or without a turntable. </figcaption>
                           </div>
                           <div class="carousel-item">
                              <img src="assets/images/portable-cmm/thumbnail img.jpg" class="img-fluid " alt="CMM-inspection-service-india">
                              <figcaption>These multifunctional handheld 3D Scanners can capture an objects’ color and texture with the optional Color Pack accessory. </figcaption>
                           </div>
                           <div class="carousel-item">
                              <img src="assets/images/portable-cmm/thumbnail img.jpg" class="img-fluid " alt="CMM-inspection-service-india">
                              <figcaption>It features high-speed, high-accuracy, and fine detail scans. </figcaption>
                           </div>
                           <div class="carousel-item">
                              <img src="assets/images/portable-cmm/thumbnail img.jpg" class="img-fluid " alt="CMM-inspection-service-india">
                              <figcaption>The EinScan multifunctional handheld 3D scanner greatly improves the efficiency of high-quality 3D modeling.</figcaption>
                           </div>
                           <div class="carousel-item">
                              <img src="assets/images/portable-cmm/thumbnail img.jpg" class="img-fluid " alt="CMM-inspection-service-india">
                              <figcaption>It provides services to healthcare, digital entertainment, art and heritage, forensics, etc.</figcaption>
                           </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-md-6 scanning-service px-lg-4">
                  <p class="text-white text-uppercase">Videos</p>
                  <div class="my-2">
                     <iframe width="100%" height="365" src="https://www.youtube.com/embed/Xn3ibxf6B9E" allow="autoplay" id="multifunctional_3d_vdo">
                    </iframe>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- section end-->
       
      <!-- section start-->
      <section class="grey-bg pt-5 my-5">
        <div class="container overview-container">
            <div class="row">
                <div class="col-md-12">
                <h1 class="text-white text-uppercase text-center">ON SITE PORTABLE CMM INSPECTION SERVICE </h1>
                    <p class="overview-cmmpara pb-4 text-center">
                    LET US COME TO YOU
                 </p>
                </div>
            </div>
    </section>
      <section class="section-padding grey-bg">
            <div class="container-fluid px-0 heading my-3">
                <div class="container">
                <div class="row">
                    <div class="col-md-4 text-center">
                        <div class="pan-india-1 my-2">
                            <div class="img">
                            <img src="assets/images/icons/b-1-icon-1.svg" class="img-fluid zoom" alt="CMM-inspection-service-india">
                            </div>
                            <div class="content pre-bg-black ">
                            <h4 class="text-white text-uppercase cmm-hdd">Fill Our Form</h4>
                            <p class="text-white cmm-inspara">Send us a request for a Quotation online</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="pan-india-1 my-2">
                            <div class="img">
                            <img src="assets/images/icons/2-icon-2.svg" class="img-fluid zoom" alt="CMM-inspection-service-india">
                            </div>
                            <div class="content pre-bg-black ">
                            <h4 class="text-white text-uppercase cmm-hdd">equipment transportation</h4>
                            <p class="text-white cmm-inspara">We bring our portable 3D CMM Machine to your factory to perform onsite inspection service</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="pan-india-1 my-2">
                            <div class="img">
                            <img src="assets/images/icons/b-1-icon-3.svg" class="img-fluid zoom" alt="CMM-inspection-service-india">
                            </div>
                            <div class="content pre-bg-black ">
                            <h5 class="text-white text-uppercase cmm-hdd">Deliver Report</h5>
                            <p class="text-white cmm-inspara">We deliver 3D inspection reports and email or submit them on the spot</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 m-auto pt-2">
                        <a class="btn pre-btn text-uppercase w-100 m-auto" href="https://forms.zohopublic.com/virtualoffice20215/form/3DScanningService/formperma/MtUTHPhde1eUkr4ssCr447qF7WKzmM2YaI3DxPyi3e8" target=_blank>get quote now</a>
                    </div>
                </div>
                </div>
            </div>
      </section>

      <section class="grey-bg pt-5 mt-5">
        <div class="container overview-container">
            <div class="row">
                <div class="col-md-12 m-auto text-center py-5">
                        <h2 class="text-white text-uppercase text-center mb-4">Download Portable CMM Inspection Brochure</h2>
                        <a class="btn pre-btn text-uppercase" href="assets/images/precise_brochure_pdf/MULTIFUNCTIONAL 3D SCANNING.pdf" target="_blank">download</a>
                    </div>
            </div>
    </section>
    <hr class="separator py-2 border-0">
       
      <!-- section start-->

      <section id="faq" class="faq pre-bg-grey section-padding faq-link" id="faq">
         <div class="container">
            <div class="row">
               <h4 class="text-uppercase text-white mt-2 mb-4 mx-lg-0 mx-2">Frequently asked questions </h4>
               <div class="col-md-12 text-left px-lg-0">
                  <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">Where can I avail portable 3d CMM service in India?</h5>
                  <div class="left-border">
                     <p class="collapse text-white" id="collapseExample">Fill in the form, and we will be able to bring our portable machines from your nearby locations to your factory to perform onsite CMM ins[ection service.<a href="geomagic-wrap-3d-scanning-software.php">Geomagic wrap</a> software alignment method.</p>
                  </div>
                  <div class="col-md-12 text-left px-lg-0">
                  </div>
                  <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample1" aria-expanded="false" aria-controls="collapseExample">How to avail portable CMM inspection service?</h5>
                  <div class="left-border">
                     <p class="collapse text-white" id="collapseExample1">You need to fill the form with the size of the appropriate components to measure, so we can choose the right 3D CMM arm and bring them to your location.</p>
                  </div>
                  <div class="col-md-12 text-left px-lg-0">
                  </div>
                  <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample3" aria-expanded="false" aria-controls="collapseExample">What is the accuracy of a portable CMM machine?</h5>
                  <div class="left-border">
                     <p class="collapse text-white" id="collapseExample3">Measurement Accuracy of portable 3D CMM machines is generally starting from 25 microns to 50 microns.</p>
                  </div>
                  <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample4" aria-expanded="false" aria-controls="collapseExample">What are Portable 3D CMM machines?</h5>
                  <div class="left-border">
                     <p class="collapse text-white" id="collapseExample4">Portable 3D CMM machines are used to extract 3D coordinates of points of the object using probe needles at the end. Later these points are used to extract 2D and 3D dimensional information.</p>
                  </div>
                  <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample5" aria-expanded="false" aria-controls="collapseExample">What is the cost of a portable 3d CMM inspection service in India?</h5>
                  <div class="left-border">
                     <p class="collapse text-white" id="collapseExample5">The price of portable CMM inspection service in 2021 is calculated on a per hour basis starts from 1000 to 1500 per hour. These machines are also given on a per-day rental basis that starts from 10 to 18K per day based o the arm length</p>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- section end -->
      
      <hr class="separator">
       
      <!-- footer start -->
      <?php include('includes/footer.php');?>
      <!-- footer end -->
       
   </body>
</html>