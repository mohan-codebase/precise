<?php
session_start();
ini_set('upload_max_filesize', '40000M');
ini_set('post_max_size', '40000M');
ini_set('max_input_time', 300000);
ini_set('max_execution_time', '-1');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <title>3D Scanning & Reverse Engineering Software Geomagic Design X </title>
      <meta name="robots" content="index, follow" />
      <meta name="googlebot" content="index, follow" />
      <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
      <meta name="revisit-after" content="7 days" />
      <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/events_images/designx.png" />
      <meta name="twitter:card" content="Precise3dm" />
      <meta name="twitter:site" content="@precise3d_m" />
      <meta name="twitter:title" content="Precise3dm" />
      <meta name="twitter:description" content="Buy Geomagic software from Distributors of Geomagic Design X in India, get quote, Free demo,download free trail geomagic design x software online" />
      <meta property="og:type" content="3D Scanning" />
      <meta property="og:title" content="3D Scanning & Reverse Engineering Software Geomagic Design X" />
      <meta property="og:url" content="https://www.precise3dm.com/reverse-engineering-geomagic-design-x.php" />
      <meta property="og:image" content="https://www.precise3dm.com/assets/images/events_images/designx.png" />
      <meta property="og:description" content="Buy Geomagic software from Distributors of Geomagic Design X in India, get quote, Free demo,download free trail geomagic design x software online" />
    
    <meta name="description" content="Buy Geomagic software from Distributors of Geomagic Design X in India, get quote, Free demo,download free trail geomagic design x software online">
    <meta name="keywords" content="geomagic, design X, scan, CAD, 3d, scanner, mesh, solid, CAD, livetransfer">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/optical-blue-light.css">
    <link rel="stylesheet" href="assets/css/scanner-styles.css">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">
   <script src="assets/js/jquery-3.6.0.min.js"></script>
   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-96527116-1"></script>
      <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      <script type="text/javascript">
  var onloadCallback = function() {
    //alert("grecaptcha is ready!");
  };
</script>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
    async defer>
</script>
   <script type="application/ld+json">
   
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "Is Geomagic software a perpetual or yearly subscription?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Geomagic software Design X, Control X wrap and Geomagic for Solidworks, all are one-time purchase perpetual license application, its not possible to rent or yearly subscribe Geomagic design x software."
    }
  },{
    "@type": "Question",
    "name": "Do I mandatorily update the Geomagic software AMC every year?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "To receive frequent updates on Geomagic software, the user needs to go for AMC renewal every year. However, it is not mandatory to renew every year. Users can keep using the software version and updates launched during the AMC period."
    }
  },{
    "@type": "Question",
    "name": "What are the types of Geomagic licensing?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "It has online activation, offline dongle, and network licensing."
    }
  },{
    "@type": "Question",
    "name": "Is Geomagic software a perpetual or yearly subscription?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Geomagic software Design X, Control X wrap and Geomagic for Solidworks, all are one-time purchase perpetual license application, its not possible to rent or yearly subscribe Geomagic Design X software."
    }
  },{
    "@type": "Question",
    "name": "What is the file format Geomagic Design X provides?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "It provides CAD neutral formats such as IGES ,STEP ,SAT ,Parasolid files."
    }
  },{
    "@type": "Question",
    "name": "Where can I buy Geomagic Design X in India?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "You can buy Geomagic software from 3dsystems software authorized resellers in India."
    }
  },{
    "@type": "Question",
    "name": "Who is an authorized reseller of Geomagic software in India?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We, Precise3DM one of the authorized distributor, a reseller of Geomagic software products in India"
    }
  },{
    "@type": "Question",
    "name": "Can I create a drawing in Solidworks from a part that was reverse engineered Design X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We can create the whole part with a structure tree hierarchy with a \"Live Transfer\" future in Design X for Catiav5, Catia v4, Creo, Solidworks, SolidEdge, and inventor."
    }
  },{
    "@type": "Question",
    "name": "What is Geomagic Design- X software?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Geomagic Design X is a comprehensive and dedicated reverse engineering design software. It enables us to create high-quality 3D scan data of a physical object, and then use the scan data to create parametric surface/solid CAD models."
    }
  },{
    "@type": "Question",
    "name": "What are the file formats I can import / export in Design X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Design X can import over 60 file-formats, including point cloud, polygons, and CAD. It can export output data in neutral CAD (Iges , step , sat, PS) or polygon formats. The Live Transfer tool supports the export of history-based CAD data to native CAD programs."
    }
  },{
    "@type": "Question",
    "name": "Can I use Geomagic Design X files in my native CAD software?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Design X enables us to create and transfer full-history parametric designs to 7 native CAD programs like Solidworks, CATIA, NX, Creo, Inventor, AutoCAD, and Solidedge. However, you can not directly import DX files into the native cad formats, you need to use the live transfer function."
    }
  },{
    "@type": "Question",
    "name": "Why is using Geomagic Design X is better than any reverse engineering software in the market?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Accelerate your time to market with a 3-10x faster time to CAD. Manufacture accurate output models with a 15% increased total end-part accuracy. Reduce product development costs by modeling as built and as designed parts within less time and for less money."
    }
  },{
    "@type": "Question",
    "name": "What are the major application areas to use Geomagic Design X capabilities?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Product design and customization, Re-manufacturing and maintenance, Additive manufacturing, Casting, Sheet-metal stamping, and Prototyping are a few major application areas where Design-X- capabilities are being utilised in the mechanical industry."
    }
  },{
    "@type": "Question",
    "name": "What are the scanning Devices I can connect with Geomagic Design X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Design X is equipped to operate optical 3D scanners, laser trackers, and PCMM arms using its Live Capture ability. Some of the major brands of 3D Scanners that can be operated are Creaform, Hexagon, FARO, Artec, Kreon, Zeiss, and others."
    }
  },{
    "@type": "Question",
    "name": "What are the minimum system requirements for Geomagic Design X?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Operating System-Windows 8, Processor-2GHz clock speed 8GB of RAM, Space- 30GB HDD, Graphic Card-NVIDIA GeForce 900 Series or AMD RADEON 400 Series with 4GB Video Card RAM (GPU must support Open GL 4.0), Display-64-bit true-color with 1280x960 resolution.
We recommend going for higher configurations to handle extensive scan data and better performance as per your applications."
    }
  },{
    "@type": "Question",
    "name": "How the Design X extracts the dimensions of the design from scan data?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Design X has sophisticated Sketch/Curve tools to extract sketch profiles and feature curves from mesh data. The smart dimensioning function will enable us to measure the dimensions from the sketch."
    }
  },{
    "@type": "Question",
    "name": "Can we check the accuracy of the CAD model?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Design X has a dynamic Accuracy Analyzer function for real-time deviation analysis. It enables us to check the deviation of Sketch/Curve/surface/solid data/Mesh data with respect to the original Scan Data at any instance of your design process."
    }
  },{
    "@type": "Question",
    "name": "Is it possible to do standard CAD modeling in Design X software?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, you can do standard surface and solid CAD modeling in Design-X and change the interface according to your CAD programs for user-friendly operation of tools."
    }
  }]
}
</script>

   <style>
       .radiobox label{
           margin-right: 10px;
       }
       .geomagic-kf-hd{
           text-transform:capitalize !important;
       }
   </style>
	
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>
</head>
<style>
@import url('https://fonts.googleapis.com/css?family=Roboto:300,500');

@color-card-background: #2d3638;
@color-tag-background: #191e20;
@color-anchor: #e37544;
@color-body-copy: #b9bcbd;
@default-border-radius: 10px;
@breakpoint-medium: "screen and (min-width: 700px)";

html, body {
  background-color: #fff;
}

.form-popup-bg,
.form-popup-bg2,
.form-popup-bg3,
.form-popup-bg4{
  position:absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-content: center;
  justify-content: center;
}
.form-popup-bg,
.form-popup-bg2,
.form-popup-bg3,
.form-popup-bg4{
  position: fixed;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(94, 110, 141, 0.9);
  opacity: 0;
  visibility: hidden;
  -webkit-transition: opacity 0.3s 0s, visibility 0s 0.3s;
  -moz-transition: opacity 0.3s 0s, visibility 0s 0.3s;
  transition: opacity 0.3s 0s, visibility 0s 0.3s;
  overflow-y: auto;
  z-index: 10000;
}
.form-popup-bg.is-visible,
.form-popup-bg2.is-visible,
.form-popup-bg3.is-visible,
.form-popup-bg4.is-visible{
  opacity: 1;
  visibility: visible;
  -webkit-transition: opacity 0.3s 0s, visibility 0s 0s;
  -moz-transition: opacity 0.3s 0s, visibility 0s 0s;
  transition: opacity 0.3s 0s, visibility 0s 0s;
}
.form-container {
    background-color: #2d3638;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
    display: flex;
    flex-direction: column;
    width: 100%;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
    position:relative;
  padding: 40px;
  color: #fff;
}
.close-button {
  background:none;
  color: #fff;
  width: 40px;
  height: 40px;
  position: absolute;
  top: 0;
  right: 0;
  border: solid 1px #fff;
}

.form-popup-bg:before{
    content:'';
    background-color: #fff;
  opacity: .25;
  position:absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
}
.web-form-col{
    background-color:#FFF;
    margin-top:40px;
    padding:50px 30px;
    border-radius:10px;
    box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
    position:relative;
    z-index:1;
}
.web-input-fields input{
    margin-top:15px;
    border-right:0;
    border-left:0;
    border-top:0;
    border-radius:0;
}
.web-input-fields input::placeholder{
    font-size:14px;
}
.web-input-fields input+label{
    font-family:"firasan-extrathin";
    font-weight:bold;
    color:red;
    font-size:12px;
}
.web-input-fields input:focus{
    box-shadow:none;
    background-color:#000;
    color:#fff;
}
#web_submit{
    border: none;
    text-transform: uppercase;
    background-color: #ff8d1e;
    color: #ffffff;
    font-weight: bold;
    font-family: 'Fira Sans', sans-serif;
    padding: 7px 21px;
    width: 54%;
    margin-top:25px;
    border-radius: 5px;
    font-size: 14px;
}
.web-form-row{
    justify-content:flex-end;
}
.web-form-col h4{
    color:#000;
    font-size: 17px;
    font-family: 'firasan-normal';
    text-align: center;
    text-transform:capitalize;
}
.designx-kf img{
    height:227px;
}
</style>
<body>
    <!-- header start -->
   <?php include('includes/header.php');?>
    <!-- header end -->

    <!-- section start-->
    <section id="Geomagic-design-x-banner" class="pt-4">
        <div class="container">
            <div class="row h-300 web-form-row">
                
                
                
                <!--<div class="col-md-3 web-form-col">-->
                <!--    <h4>webinar registration</h4>-->
                <!--    <form action="webinar_submit.php" id="web_form">-->
                <!--        <div class="form-group web-input-fields">-->
                <!--            <input type="text" name="web_name" id="web_name" class="form-control" placeholder="Name*">-->
                <!--            <input type="email" name="web_email" id="web_email" class="form-control" placeholder="Email*">-->
                <!--            <input type="text" name="web_contnum" id="web_contnum" class="form-control" placeholder="Contact number*" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">-->
                <!--            <input type="text" name="web_companyname" id="web_companyname" placeholder="Company name" class="form-control">-->
                <!--        </div>-->
                <!--        <div class="text-center">-->
                <!--            <button type="submit" id="web_submit" disabled>Submit</button>-->
                <!--        </div>-->
                <!--    </form>-->
                <!--</div>-->
                
                
                
                
                <!----<div class="col-md-3 web-form-col">
                        <h4>webinar registration</h4>
                            <form method="POST" action="webinar_submit.php" id="web_form" autocomplete="off">
                            <div class="form-group web-input-fields">
                                <input type="text" name="web_name" id="web_name" class="form-control" placeholder="Name*">
                                <input type="email" name="web_email" id="web_email" class="form-control" placeholder="Email*">
                                <input type="text" name="web_contnum" id="web_contnum" class="form-control" placeholder="Contact number*" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                <input type="text" name="web_companyname" id="web_companyname" placeholder="Company name" class="form-control">
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn" id="web_submit" disabled>Submit</button>
                            </div>
                        </form>
                       </div>-->
            </div>
        </div>
        <div class="container-fluid heading m-320">
            <div class="row ">
                <div class="col-md-12 text-md-left text-center px-2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 software-mobile">
                                <img src="./assets/images/geomagic-x/dx.png" alt="reverse-engineering-geomagic-design-x" class="software-icons">
                                <h2 class="title text-white">Geomagic Design X</h2>

                                <a class="btn pre-btn my-2" href="https://forms.zohopublic.com/virtualoffice20215/form/Bookademoonlineonsite/formperma/v-Zrwhh8zM330ig-4CD_W6rJsqgkKQ7nBEXF2nOr39M" target=_blank>Fix Up an online demo</a>

                                <!-- <embed src="assets/images/download-icon-1-01-01.svg" type="" class="download-icon-designx"> -->

                                <a class="btn pre-btn my-2 geomagic-design-top-button" href="#geoform">
                                    <img src="assets/images/download-icon.png" alt="reverse-engineering-geomagic-design-x" class="download-icon-png-cdx">
                                    DOwnload TRIAL now
                                </a>

                                <p class="text-white text-uppercase">The Industry’s Most advanced Dedicated reverse engineering software</p>
                                <p class="text-white-next text-uppercase">make an Intelligent move on Your Scan to CAD ProcesS</p>
                                <p class="software-header-list">
                                <p class="no-margin-bottom"><embed src="assets/images/download-icon-2-02.svg" height="38px" class="header-arrows"> <span class="header-pointer"> Get Quick Quotation</span></p>
                                <p class="no-margin-bottom"><embed src="assets/images/download-icon-2-02.svg" height="38px" class="header-arrows"> <span class="header-pointer">Talk to our sales Team @ +91-73959 72777</span></p>
                                </p>
                            </div>
                            <div class="col-md-4">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="overview-top-design"></div>
    </section>
    <!-- section end-->
<script>
//     $(document).ready(function(){
//         function emptyInputsweb(){
//             if($("#web_name").val() == "" || $("#web_email").val() == "" || $("#web_contnum").val() == ""){
//                 $("#web_submit").attr('disabled', true);
//             }
//         }
//         $(document).on("keyup blur", "#web_form input", function(){
//           if($(this).valid() == true){
//               $("#web_submit").removeAttr('disabled');
//               emptyInputsweb();
//             }
//             else{
//               $("#web_submit").attr('disabled', true);
//             }
//         });
//         $("#web_form").validate({
//             rules: {
//                 web_name: {
//                     required: true,
//                 },
//                 web_email: {
//                     required: true,
//                     email_check: true,
//                 },
//                 web_contnum:{
//                     required:true,
//                     minlength: 10,
//                 },
//             },
//             messages:{
//                 web_email:{
//                     email_check:"Please enter the valid email"
//                 },
//                 web_contnum:{
//                     minlength:"Please enter valid 10 numbers."
//                 }
//             }
//         });
//     });
</script>
    <!-- Overview section starts-->
    <section id="overview-section" class="pt-4">
        <div class="container overview-container">
            <div class="row">
                <div class="col-md-3" id="overview-heading-text">
                    <a class="btn pre-btn my-2" href="#">OVERVIEW </a>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <p class="overview">Geomagic Design X is the Industry-leading software dedicated to Digital Reverse Engineering applications. Its comprehensive features enable CAD designers and 3Dexperts to use the 3D scan as a foundation to create history-based design intent and accurate as-built CAD and NURBS surfaces.</p>
                </div>
            </div>
            <div class="row" id="overview-btns">

                <div class="col-xs-6 col-md-6 mobile-features">
                    <a class="btn pre-btn my-2" href="#demo-video" ;>DEMO VIDEOS</a>
                </div>
                <div class="col-xs-6 col-md-5 mobile-specs">
                    <a class="btn pre-btn my-2" href="#application-dx">APPLICATIONS</a>
                </div>

            </div>

    </section>
    <!-- Overview section end-->

    <!-- Key feature section starts-->
    <section id="machine-spec" class="section-padding">
        <div class="container">
            <div class="container">
                <h2 class="text-white text-uppercase kf">KEY FEATURES</h2>
            </div>
            <div id="features">
                <section class="section-padding">
                    <div class="container designx-kf">
                        <div class="row">
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\geomagic-x\PLUGIN TO 3D SCANNERS.png" alt="Accuracy-of-EinScan-Pro-Series-Scanners-reverse-engineering">
                                    <div class="card-body">
                                        <h5 class="text-white card-title geomagic-kf-hd">Plugin to 3D scanners</h5>
                                        <p class="card-text">Exclusive plugin to connect 3d Scanners and portable arms to 3D Scan and probe features. Creates scan groups of different positions. Scan, align and combine them to a set of point clouds and convert the point clouds to mesh models.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\geomagic-x\MESH TOOLS.PNG" alt="Versatile-Scan-Modes-and-Align-Modes">
                                    <div class="card-body">
                                        <h5 class="text-white card-title  geomagic-kf-hd">Mesh Tools</h5>
                                        <p class="card-text">Automatically heal all the mesh defects in one go, decimate down, enhance the detail and shape, instantly optimize and create a watertight mesh for direct use in 3D Printing, CAM, CAE or post 3D Scanning applications such as 3D Scan to Cad or 3D inspection.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\geomagic-x\POWERFULL MESH CROSS SECTIONS.PNG" alt="Full-Color-Scan-reverse-engineering-geomagic-design-x">
                                    <div class="card-body">
                                        <h5 class="card-title  geomagic-kf-hd">Powerful Mesh<BR>Cross-Sections</h5>
                                        <p class="card-text">It is not just by a single plane but also by the volumetric box that brings the full mesh projection into the single plane, facilitating the extraction of lines, arcs, and even detailed sketch profiles.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\geomagic-x\AUTO EXTRACT 3D FEATURES.PNG" alt="New-Scanning-Software-EXSCAN-PRO">
                                    <div class="card-body">
                                        <h5 class="card-title  geomagic-kf-hd">Auto-Extract<BR>3D Features </h5>
                                        <p class="card-text">Extract CAD features intuitively and quickly from the 3D Scan. Traditional designers usually model the file in CAD software to design any object. Here you may use software intelligence to extract surface and solid features and modeling elements such as editable sketch, center axis, cross-section plane, and vectors.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\geomagic-x\LIVE TRANSFER.png" alt="Solid-Edge-SHINING-3D-Edition">
                                    <div class="card-body dark">
                                        <h5 class="card-title  geomagic-kf-hd">Live Transfer
                                        </h5>
                                        <p class="card-text">The robust functionality in Geomagic design X transfers all parametric CAD modeling features extracted from 3D Scan to any leading CAD software for any downstream applications. So designers can modify the design parameters in their CAD software to which they are comfortable.
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4 zoom-out">
                                <div class="card overflow-hidden">
                                    <img class="card-img-top img-fluid" src="assets\images\geomagic-x\ENSURE QUALITY.PNG" alt="Portable-and-User-friendly-Design">
                                    <div class="card-body">
                                        <h5 class="card-title  geomagic-kf-hd">Ensure Quality</h5>
                                        <p class="card-text">Instantly compare and validate the entire model, solid and surface features. Check how close the final model is digitally reverse-engineered from the 3D Scan, re-design them in Geomagic to improve the model within. User-defined deviation tolerances, by its intellectual function accuracy analyzer.
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>
            </div>
        </div>
    </section>
    <!-- Key feature section end-->

    <hr class="separator">

    <!-- Workflow Section Starts Here -->
    <section id="workflow">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="text-white text-uppercase kf">WORKFLOW</h2>
                </div>

            </div>

        </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 workflow-background">
                    <img src="assets/images/geomagic-x/workflow.png" alt="workflow-reverse-engineering-geomagic-design-x" class="img-fluid">
                </div>
            </div>

    </section>
    <!-- Workflow Section ends Here -->



    <!-- Demo video section start-->
    <section id="demo-video" class="pt-4 demoVid">
        <div class="container">
        <h4 class="text-white text-uppercase ">Latest features in Geomagic Design  X 2022</h4>
        <p class="text-white" style="font-family: sans-serif;background-color: #242424;">Geomagic Design X 2022 is launched with advanced features focused on modelling workflows to increase pathways for complicated designing, including revolved parts:</p>
         <div class="row">
            <div class="col-md-7">
            <ol style="padding-left: 18px;">
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Curve or Mesh has new selective surfacing features</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">This update comes with brand new Unrolling, flattening and enrolling tools</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Geomagic Maintenance program now has preview tools</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Update native CAD file import along with PMI for most formats</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Improve File import functionalities</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">The meshing function is provided separately in this version</li>
  <li class="text-white" style="list-style-type: disc;font-family: sans-serif;font-size: 18px;">Improved extracted boundary curves</li>


</ol>
</div>
<div class="col-md-5 ">
                    <iframe width="100%" height= "215px" src="https://www.youtube.com/embed/rzVDyU06imc" >
                    </iframe>
                </div>
         </div>
            <h2 class="text-white text-uppercase kf demV">DEMO VIDEO</h2>
            <div class="row">
                <div class="col-md-8 main-demo-video">
                    <iframe width="100%" height="345" src="https://www.youtube.com/embed/A-qARwOXYJ0" allow=autoplay id ="geomagic_designx_vdo">
                    </iframe>
                </div>
                <div class="col-md-4 geomagic_yvdo_scroll">
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo1.png"  id ="geomagic_designx_vdo1">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo2.png" id ="geomagic_designx_vdo2">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo3.png" id ="geomagic_designx_vdo3">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo4.png" id ="geomagic_designx_vdo4">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo5.png" id ="geomagic_designx_vdo5">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo6.png" id ="geomagic_designx_vdo6">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo7.png" id ="geomagic_designx_vdo7">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo8.png" id ="geomagic_designx_vdo8">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo9.png" id ="geomagic_designx_vdo9">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo10.png" id ="geomagic_designx_vdo10">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <img width="170px" height="75" src="assets/images/video_thumbnails/geomagic_designX_vdo11.png" id ="geomagic_designx_vdo11">
                            </img>
                        </div>
                        <div class="media-body geomagic-media-body">
                            <h4 class="media-heading"> Geomagic Design</h4>
                            <p>geomagic Design X -Industry-leading dedicated software for di</p>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </section>
    <!-- Demo video section ends-->

    <!-- Application Section Starts Here -->
    <section class="applications" id = "application-dx">
        <div class="container">
            <h2 class="text-white text-uppercase kf">APPLICATIONS</h2>
        </div>
        <div class="container">
         <div class="row">
         <div class="col-md-4"> <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/3d-scan-parametric-cad.php" target=_blank  style="font-size:13px;width:100%;">3D Scan to Parametric CAD </a></div>
    <div class="col-md-4"> <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/scan-to-nurbs-modelling.php" target=_blank  style="font-size:13px;width:100%;">Scan to Nurbs modelling</a></div>
    <div class="col-md-4"><a  class="btn pre-btn my-2"  href="#" target=_blank  style="font-size:13px;width:100%;"> Hybrid modelling </a></div>
    
    
    
     <div class="col-md-4"><a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/design-modification-from-3d-scan.php" target=_blank  style="font-size:13px;width:100%;"> Design modification</a></div>
     <div class="col-4">   <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/netural-cad-to-editable-cad.php" target=_blank  style="font-size:13px;width:100%;">  Neutral cad to editable cad</a></div>
        <div class="col-4"> <a  class="btn pre-btn my-2"  href="#" target=_blank  style="font-size:13px;width:100%;"> CAD Modification</a></div>
        <div class="col-4"> <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/automotive-benchmarking-services-in-india.php" target=_blank  style="font-size:10px;width:100%;">Automotive digital transformation </a></div>
        <div class="col-4">  <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/digital-vehicle-development.php" target=_blank  style="font-size:13px;width:100%;"> Digital vehicle development</a> </div>

        <div class="col-4"><a class="btn pre-btn my-2"  href="#" target=_blank  style="font-size:13px;width:100%;">Virtual boundary analysis</a></div>
        <div class="col-4"><a class="btn pre-btn my-2 " href="https://www.precise3dm.com/digital-damage-assessment.php" target=_blank style="font-size:13px;width:100%;">Digital damage assessment</a> </div>
        <div class="col-4"><a class="btn pre-btn my-2 " href="#" target=_blank style="font-size:13px;width:100%;">Boundary comparison</a></div>
         <div class="col-4"><a class="btn pre-btn my-2"  href="https://www.precise3dm.com/airfoil-twist-analysis.php" target=_blank  style="font-size:13px;width:100%;">Airfoil Twist analysis</a></div>
         <div class="col-4"> <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/product-development-from-existing-scan.php" target=_blank  style="font-size:13px;width:100%;"> Product development from existing scan</a></div>
          <div class="col-md-4"> <a  class="btn pre-btn my-2"  href="#" target=_blank  style="font-size:13px;width:100%;"> Organic shapes feature based cad reconstruction </a></div>
           <div class="col-md-4"> <a  class="btn pre-btn my-2"  href="https://www.precise3dm.com/digital-measurement-extraction-of-shape.php" target=_blank  style="font-size:13px;width:100%;"> Digital sculpting from digitized shape </a></div>
  </div>
               <!-- <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   3D Scan to Parametric CAD
                                </a><br>
                 <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   Scan to Nurbs modelling
                                </a><br>
                 <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   Hybrid modelling
                                </a><br>
                 <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   Organic shapes feature based cad reconstruction
                                </a><br>
                <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   Digital sculpting from digitized shape
                                </a><br>
                 <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   Design modification
                                </a><br>
                 <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                  Neutral cad to editable cad
                                </a><br>
                 <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                   CAD Modification
                                </a><br>
               <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                 Automotive digital transformation
                                </a><br>
                                <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                  Digital vehicle development
                                </a><br>
                                <a class="btn pre-btn my-2 geomagic-design-top-button" href="#">
                                Product development from existing scan
                                </a>-->
                                
                <!--<li>3D Scan to Parametric CAD</li>
                <li>Scan to Nurbs modelling</li>
                <li>Hybrid modelling</li>
                <li>Organic shapes feature based cad reconstruction</li>
                <li>Digital sculpting from digitized shape</li>
                <li>Design modification</li>
                <li>Neutral cad to editable cad</li>
                <li>CAD Modification</li>
                <li>Automotive digital transformation</li>
                <li>Digital vehicle development</li>
                <li>Product development from existing scan</li>-->
            
        </div>
        </div>
        </div>
    </section>
    <!-- Application Section Ends Here -->

    <hr class="separator">

    <!--FAQs section start-->
    <section id="faq" class="faq section-padding">
        <div class="container">
        <h4 class="text-uppercase text-white mt-2 mb-4 mx-lg-0 mx-2" >Frequently asked questions </h4>

        
            <div class="row faqsectionforscroll">
            
                <div class="col-md-11 text-left px-lg-0 ">

                    <h5 class="pre-color" >Is Geomagic software a perpetual or yearly subscription?</h5>
                    <div class="left-border">
                        <p class="text-white" >Geomagic software Design X, Control X wrap and Geomagic for Solidworks, all are one-time purchase perpetual license application, its not possible to rent or yearly subscribe Geomagic design x software.
                        </p>
                    </div>

                    <h5 class="pre-color "  >Do I mandatorily update the Geomagic software AMC every year?</h5>
                    <div class="left-border">
                        <p class="text-white " >To receive frequent updates on Geomagic software, the user needs to go for AMC renewal every year. However, it is not mandatory to renew every year. Users can keep using the software version and updates launched during the AMC period.</p>
                    </div>

                    <h5 class="pre-color " >What are the types of Geomagic licensing?</h5>
                    <div class="left-border">
                        <p class="text-white " >It has online activation, offline dongle, and network licensing.</p>
                    </div>

                    <h5 class="pre-color " >Is Geomagic software a perpetual or yearly subscription?</h5>
                    <div class="left-border">
                        <p class="text-white " >Geomagic software Design X, Control X wrap and Geomagic for Solidworks, all are one-time purchase perpetual license application, its not possible to rent or yearly subscribe Geomagic Design X software.
                        </p>
                    </div>

                    <h5 class="pre-color " >What is the file format Geomagic Design X provides?</h5>
                    <div class="left-border">
                        <p class="text-white " >It provides CAD neutral formats such as IGES ,STEP ,SAT ,Parasolid files.</p>
                    </div>

                    <h5 class="pre-color " >Where can I buy Geomagic Design X in India?</h5>
                    <div class="left-border">
                        <p class="text-white " >You can buy Geomagic software from 3dsystems software authorized resellers in India.</p>
                    </div>

                    <h5 class="pre-color " >Who is an authorized reseller of Geomagic software in India?</h5>
                    <div class="left-border">
                        <p class="text-white " >We, Precise3DM one of the authorized distributor, a reseller of Geomagic software products in India</p>
                    </div>

                    <h5 class="pre-color " >Can I create a drawing in Solidworks from a part that was reverse engineered Design X?</h5>
                    <div class="left-border">
                        <p class="text-white " >We can create the whole part with a structure tree hierarchy with a "Live Transfer" future in Design X for Catiav5, Catia v4, Creo, Solidworks, SolidEdge, and inventor.</p>
                    </div>
                    <h5 class="pre-color " >What is Geomagic Design- X software?</h5>
                    <div class="left-border">
                        <p class="text-white " >Geomagic Design X is a comprehensive and dedicated reverse engineering design software. It enables us to create high-quality 3D scan data of a physical object, and then use the scan data to create parametric surface/solid CAD models.</p>
                    </div>
                    <h5 class="pre-color " >What are the file formats I can import / export in Design X?</h5>
                    <div class="left-border">
                        <p class="text-white " >Design X can import over 60 file-formats, including point cloud, polygons, and CAD. It can export output data in neutral CAD (Iges , step , sat, PS) or polygon formats. The Live Transfer tool supports the export of history-based CAD data to native CAD programs.</p>
                    </div>
                    <h5 class="pre-color " >Can I use Geomagic Design X files in my native CAD software?</h5>
                    <div class="left-border">
                        <p class="text-white " >Design X enables us to create and transfer full-history parametric designs to 7 native CAD programs like Solidworks, CATIA, NX, Creo, Inventor, AutoCAD, and Solidedge. However, you can not directly import DX files into the native cad formats, you need to use the live transfer function.</p>
                    </div>
                    <h5 class="pre-color " >Why is using Geomagic Design X is better than any reverse engineering software in the market?</h5>
                    <div class="left-border">
                        <p class="text-white " >
                            
                                Accelerate your time to market with a 3-10x faster time to CAD.
                                Manufacture accurate output models with a 15% increased total end-part accuracy. 
                                Reduce product development costs by modeling as built and as designed parts within less time and for less money. 
                        </p>
                    </div>
                    <h5 class="pre-color " >What are the major application areas to use Geomagic Design X capabilities?</h5>
                    <div class="left-border">
                        <p class="text-white " >Product design and customization, Re-manufacturing and maintenance, Additive manufacturing, Casting, Sheet-metal stamping, and Prototyping are a few major application areas where Design-X- capabilities are being utilised in the mechanical industry.</p>
                    </div>
                    <h5 class="pre-color " >What are the scanning Devices I can connect with Geomagic Design X?</h5>
                    <div class="left-border">
                        <p class="text-white " >Design X is equipped to operate optical 3D scanners, laser trackers, and PCMM arms using its Live Capture ability. Some of the major brands of 3D Scanners that can be operated are Creaform, Hexagon, FARO, Artec, Kreon, Zeiss, and others.</p>
                    </div>
                    <h5 class="pre-color " >What are the minimum system requirements for Geomagic Design X?</h5>
                    <div class="left-border">
                        <p class="text-white " >Minimum system requirements for working with the Design-X are:<br>
                            Operating System-Windows 8, Processor-2GHz clock speed 8GB of RAM, Space- 30GB HDD, Graphic Card-NVIDIA GeForce 900 Series or AMD RADEON 400 Series with 4GB Video Card RAM (GPU must support Open GL 4.0), Display-64-bit true-color with 1280x960 resolution.

                            <br>*We recommend going for higher configurations to handle extensive scan data and better performance as per your applications.
                        </p>
                    </div>
                    <h5 class="pre-color " >How the Design X extracts the dimensions of the design from scan data?</h5>
                    <div class="left-border">
                        <p class="text-white " >Design X has sophisticated Sketch/Curve tools to extract sketch profiles and feature curves from mesh data. The smart dimensioning function will enable us to measure the dimensions from the sketch. </p>
                    </div>
                    <h5 class="pre-color " >Can we check the accuracy of the CAD model?</h5>
                    <div class="left-border">
                        <p class="text-white " >Design X has a dynamic Accuracy Analyzer function for real-time deviation analysis. It enables us to check the deviation of Sketch/Curve/surface/solid data/Mesh data with respect to the original Scan Data at any instance of your design process.</p>
                    </div>
                    <h5 class="pre-color " >Is it possible to do standard CAD modeling in Design X software?</h5>
                    <div class="left-border">
                        <p class="text-white " >Yes, you can do standard surface and solid CAD modeling in Design-X and change the interface according to your CAD programs for user-friendly operation of tools.</p>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--FAQs section ends-->

    <hr class="separator" >
    
     <div class="container sectioning" style="margin-top:30px;margin-bottom:30px;" id="geoform">
        <div class="row inside">
            <div class="col-lg-5" style="background-color: #ffffff"  >
                <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                              
                                <div style='width: 100%'><a target='_blank' href='https://drive.google.com/drive/folders/1h8SEQjQPVs-X9ujHwq-d-cl-w1dsbi4s?usp=sharing'><button class='btn pre-btn my-2'>Download Geomagic Design X</button></a></div>
                                <p>Why should you evaluate Geomagic Reverse engineering software from precise 3d?</p>
                                <ul>
                                    <li  style='list-style-type: disclosure-closed;'>We shall recommend you the right software for your reverse engineering application</li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall give you free training during the evaluation </li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall help you with a free benchmark project if you want to model any of your 3d scan data or inspect to cad </li>
                                </ul>
                        </div>";
                    } else {
                        echo "<div class='row status-div'>
                                <p class='status-message'>Oops...Something went wrong, please try again
                            </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <form method="POST" action="uploadgeomagicx.php" id="regForm" enctype="multipart/form-data" onsubmit="disablebutton();">

                        <div class="tab-step-form" data-form-type="contact">
                            <h2 class="text text-uppercase kf">DOwnload TRIAL now</h2>
                              
                            <p>Thanks for your interest in downloading the geomagic design x software trial. Precise3dm is ''authorized geomagic software resellers in india to take care of 3dsytems geomagic software sales, pre &post sale support for geomagic reverse engineering and inspection software.
</p><p>
Please fill the form and instantly link will be activated to get yourself started with geomagic solutions 
</p>
                            <h5 style="margin-bottom:10px" >Contact Information</h5>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="name" name="name" placeholder="Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control required" id="email" name="email" placeholder="Email Address *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="contactnumber" name="contactnumber" placeholder="Mobile Number *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyname" name="companyname" placeholder="Company Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyaddress" name="companyaddress" placeholder="Company Address *" required />
                            </div>
                            <span>Do you have a 3d scanner in-house? </span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="homeavailable" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="homeavailable" value="No"> No</label>
                            </div>
                            <span>Do you need a demo during the evaluation?</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="needdemo" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="needdemo" value="No"> No</label>
                            </div>
                            <span>Do you also need a quote for Geomagic Design X?</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="needquote" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="needquote" value="No"> No</label>
                            </div>
                            <div style="margin-left:15px;margin-bottom:15px;" class="g-recaptcha mx-auto" data-sitekey="6LezZJIbAAAAACQe2yY5z5-p8a2ZdgvOhZr9WQYh"></div>

                            
                        </div>
                        <button type="submit" class="btn btn-success" id="submit" style="margin-top:10px;">Submit <img src="loader2.gif" id="loader" width="25" style="display: none;" /></button>
                         <p style="margin-top:20px;">Why should you evaluate Geomagic Reverse engineering software from precise 3d?</p>
                                <ul>
                                    <li  style='list-style-type: disclosure-closed;'>We shall recommend you the right software for your reverse engineering application</li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall give you free training during the evaluation </li>
                                    <li  style='list-style-type: disclosure-closed;'>We shall help you with a free benchmark project if you want to model any of your 3d scan data or inspect to cad </li>
                                </ul>

                    </form>
                <?php } ?>
            </div>
        </div>
        </div>
		    <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                            <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/Precise Geomagic DesignX Brochure.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                        </div>";
                    } else {
                        echo "<div class='row status-div'>
                                <p class='status-message'>Oops...Something went wrong, please try again
                            </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg">
                      <div class="form-container">
                        <button id="btnCloseForm" class="close-button">X</button>
                        <form method="POST" action="downloadRe.php" id="downloadRe" enctype="multipart/form-data" onsubmit="disablebutton();">
                    	 <div class="form-group">
                                   <input type="text" class="form-control required" id="name_one" name="name_pop"  placeholder="Name *" onblur="validate()" required />
                                    </div>
                                   <div class="form-group">
                                   <input type="email" class="form-control required" id="email_one" name="email_pop"  onblur="validate()" placeholder="Email Address *" required />
                                                </div>
                                   <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_one" name="contactnumber_pop"  onblur="validate()" placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"/>
                                                </div>
                               <a href=""><button type="submit" class="btn btn-success submit_pop"  id="submit" onclick="window.open('brochures/Purchaseguid.pdf')" style="margin-top:10px;">Submit and Download</button></a>
                        </form>
                    	<?php } ?>
                    	
                    	
                      </div>
                    </div>
                    
                <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                                    <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/DX-CX Installation Guide.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                                                </div>";
                    } else {
                        echo "<div class='row status-div'>
                                                        <p class='status-message'>Oops...Something went wrong, please try again
                                                    </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg2">
                        <div class="form-container">
                            <button id="btnCloseForm2" class="close-button">X</button>
                            <form method="POST" action="download_DIG.php" id="downloadDIG" enctype="multipart/form-data" onsubmit="disablebutton();">
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="name_dig" name="name_dig" placeholder="Name *" required />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control required" id="email_dig" name="email_dig" placeholder="Email Address *" required />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_dig" name="contactnumber_dig"  placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                                </div>
                                <a href=""><button type="submit" class="btn btn-success submit-dig" id="submit" onclick="window.open('assets/images/precise_brochure_pdf/DX-CX Installation Guide.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                            </form>
                        <?php } ?>
                        </div>
                    </div>
                    
                    <!--three-->
                    <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                                    <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/Geomagic System Requirements.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                                                </div>";
                    } else {
                        echo "<div class='row status-div'>
                                                        <p class='status-message'>Oops...Something went wrong, please try again
                                                    </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg3">
                        <div class="form-container">
                            <button id="btnCloseForm3" class="close-button">X</button>
                            <form method="POST" action="download_SRG.php" id="downloadSRG" enctype="multipart/form-data" onsubmit="disablebutton();">
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="name_srg" name="name_srg" placeholder="Name *" required />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control required" id="email_srg" name="email_srg" placeholder="Email Address *" required />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_srg" name="contactnumber_srg"  placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                                </div>
                                <a href=""><button type="submit" class="btn btn-success submit-srg" id="submit" onclick="window.open('assets/images/precise_brochure_pdf/Geomagic System Requirements.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                            </form>
                        <?php } ?>
                        </div>
                    </div>
                    <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                                    <div style='width: 100%'><a target='_blank' href='assets/images/precise_brochure_pdf/Precise Geomagic DesignX Brochure.pdf'><button class='btn pre-btn my-2'>Download Brochure</button></a></div>
                                                </div>";
                    } else {
                        echo "<div class='row status-div'>
                                                        <p class='status-message'>Oops...Something went wrong, please try again
                                                    </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <div class="form-popup-bg4">
                        <div class="form-container">
                            <button id="btnCloseForm4" class="close-button">X</button>
                            <form method="POST" action="download_DSB.php" id="downloadDSB" enctype="multipart/form-data" onsubmit="disablebutton();">
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="name_dsb" name="name_dsb" placeholder="Name *" required />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control required" id="email_dsb" name="email_dsb" placeholder="Email Address *" required />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control required" id="contactnumber_dsb" name="contactnumber_dsb"  placeholder="Mobile Number *" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                                </div>
                                <a href=""><button type="submit" class="btn btn-success submit-dsb" id="submit" onclick="window.open('assets/images/brouche/Precise Geomagic DesignX-Brochure.pdf')" style="margin-top:10px;" disabled>Submit and Download</button></a>
                            </form>
                        <?php } ?>
                        </div>
                    </div>
                    <style>
                        #downloadRe input + label,
                        #downloadDIG input + label,
                         #downloadSRG input + label,
                        #downloadDSB input + label{
                            font-weight: 100 !important;
                            font-family: 'firasan-extrathin';
                            font-size: 13px;
                        }
                    </style>
                    <script>
                        $(document).ready(function(){
                            // $("#btnOpenForm").on("click" ,function(){
                            //     $("#downloadRe .submit_pop").attr('disabled', true);
                            // });
                            $("#downloadRe .submit_pop").attr('disabled', true);
                            function emptyInputs(){
                                if($("#name_one").val() == "" || $("#email_one").val() == "" || $("#contactnumber_one").val() == ""){
                                    $("#downloadRe .submit_pop").attr('disabled', true);
                                }
                            }
                            function emptyInputs2(){
                                if($("#name_dig").val() == "" || $("#email_dig").val() == "" || $("#contactnumber_dig").val() == ""){
                                    $("#downloadDIG .submit-dig").attr('disabled', true);
                                }
                            }
                            function emptyInputs3(){
                                if($("#name_srg").val() == "" || $("#email_srg").val() == "" || $("#contactnumber_srg").val() == ""){
                                    $("#downloadSRG .submit-srg").attr('disabled', true);
                                }
                            }
                            function emptyInputs4(){
                                if($("#name_dsb").val() == "" || $("#email_dsb").val() == "" || $("#contactnumber_dsb").val() == ""){
                                    $("#downloadDSB .submit-dsb").attr('disabled', true);
                                }
                            }
                            $(document).on("keyup blur" , "#downloadRe input", function(){
                                if($(this).valid() == true){
                                   $("#downloadRe .submit_pop").removeAttr('disabled');
                                   emptyInputs();
                                }
                                else{
                                   $("#downloadRe .submit_pop").attr('disabled', true);
                                }
                            });
                            $(document).on("keyup blur" , "#downloadDIG input", function(){
                                if($(this).valid() == true){
                                   $("#downloadDIG .submit-dig").removeAttr('disabled');
                                   emptyInputs2();
                                }
                                else{
                                    $("#downloadDIG .submit-dig").attr('disabled', true);
                                }
                            });
                            $(document).on("keyup blur" , "#downloadSRG input", function(){
                                if($(this).valid() == true){
                                   $("#downloadSRG .submit-srg").removeAttr('disabled');
                                   emptyInputs3();
                                }
                                else{
                                    $("#downloadSRG .submit-srg").attr('disabled', true);
                                }
                            });
                            $(document).on("keyup blur" , "#downloadDSB input", function(){
                                if($(this).valid() == true){
                                   $("#downloadDSB .submit-dsb").removeAttr('disabled');
                                   emptyInputs4();
                                }
                                else{
                                    $("#downloadDSB .submit-dsb").attr('disabled', true);
                                }
                            });
                            $.validator.addMethod("email_check", function(value, element) {
                                var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                if (regex.test(value)) {
                                    return true
                                } else {
                                    return false
                                }
                            });
                            $("#downloadRe").validate({
                                rules: {
                                    name_pop: {
                                        required: true,
                                    },
                                    email_pop: {
                                        required: true,
                                        email_check: true,
                                    },
                                    contactnumber_pop:{
                                        required:true,
                                        minlength: 10,
                                    },
                                },
                                messages:{
                                    email_pop:{
                                        email_check:"Please enter the valid email"
                                    },
                                }
                            });
                            $("#downloadDIG").validate({
                                rules: {
                                    name_dig: {
                                        required: true,
                                    },
                                    email_dig: {
                                        required: true,
                                        email_check: true,
                                    },
                                    contactnumber_dig:{
                                        required:true,
                                        minlength: 10,
                                    },
                                },
                                messages:{
                                    email_dig:{
                                        email_check:"Please enter the valid email"
                                    }
                                }
                            });
                            $("#downloadSRG").validate({
                                rules: {
                                    name_srg: {
                                        required: true,
                                    },
                                    email_srg: {
                                        required: true,
                                        email_check: true,
                                    },
                                    contactnumber_srg:{
                                        required:true,
                                        minlength: 10,
                                    },
                                },
                                messages:{
                                    email_srg:{
                                        email_check:"Please enter the valid email"
                                    }
                                }
                            });
                            $("#downloadDSB").validate({
                                rules: {
                                    name_dsb: {
                                        required: true,
                                    },
                                    email_dsb: {
                                        required: true,
                                        email_check: true,
                                    },
                                    contactnumber_dsb:{
                                        required:true,
                                        minlength: 10,
                                    },
                                },
                                messages:{
                                    email_dsb:{
                                        email_check:"Please enter the valid email"
                                    }
                                }
                            });
                        });
                        
                    </script>
                   <!-- <script>
                    jQuery("#submit").prop('disabled', true);

var toValidate = jQuery('#name, #email, #contactnumber'),
    valid = false;
toValidate.keyup(function () {
    if (jQuery(this).val().length > 0) {
        jQuery(this).data('valid', true);
    } else {
        jQuery(this).data('valid', false);
    }
    toValidate.each(function () {
        if (jQuery(this).data('valid') == true) {
            valid = true;
        } else {
            valid = false;
        }
    });
    if (valid === true) {
        jQuery("#submit").prop('disabled', false);
    } else {
        jQuery("#submit").prop('disabled', true);
    }
});

</script>-->
    <!--Brochure section start-->
    <section class="section-padding" id="brochure-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!--<h3 class="para">Not sure what reverse engineering software from Geomagic will suit your requirement?</h3><br>-->
                     <h3 class="para">Downloadable Resources</h3><br>
                    <h4 class="para">Download reverse engineering software purchase Guide</h4>
                    <a class="btn pre-btn my-2" id="btnOpenForm">Download</a>
                </div>
            </div>
            <div class="row" id="online-demo-btn">
                <div class="col-md-4">
                    <h4 class="para">Download Installation Guide</h4>
                    <a class="btn pre-btn my-2" id="dig_downloadbtn">Download</a>
                </div>
                <div class="col-md-4">

                    <h4 class="para">System Requirements Guide</h4>
                    <a class="btn pre-btn my-2" id="srg_downloadbtn" target="_blank">Download</a>
                </div>
                <div class="col-md-4">
                    <h4 class="para">Download Software Brochure</h4>
                    <a class="btn pre-btn my-2" id="dsb_downloadbtn"  target="_blank">Download</a>
                </div>
            </div>
        </div>
    </section>
    <!--Brochure section ends-->

    <hr class="separator">
    <?php include('includes/footer.php'); ?>

    <!-- bootstrap links-->
    <!-- <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/slim.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="assets/js/tabs.js"></script> -->
    <!-- bootstrap links-->
    <script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/counter.js"></script>
</body>
 <script type="text/javascript">
// 	$('input[type="text"]').on('blur',function(){
// 			var val = $(this).val();
// 			$(this).val($.trim(val));
// 	});

	function disablebutton()
	{
		$('#loader').show();
		
		//$('#submit').attr('disabled',true);
	}
</script>
<script>
	function manage(txt) {
        var bt = document.getElementById('submit');
        if (txt.value != '') {
            bt.disabled = false;
        }
        else {
            bt.disabled = true;
        }
    }    
</script>
<script>
var fileInput = document.querySelector('input[type=file]');
var filenameContainer = document.querySelector('.custom-file-upload');
fileInput.addEventListener('change', function() {
    filenameContainer.innerText = fileInput.value.split('\\').pop();
});

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab-step-form");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  // fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab-step-form");
  var currentTabValue = $(".tab-step-form").eq(currentTab).attr("data-form-type");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm(currentTabValue)) return false;
  if (currentTab < x.length-1){
  // Hide the current tab:
  x[currentTab].style.display = "none";
    }
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    $('#loader').show();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm(form) {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;

  console.log(form);

  if(form == 'contact')
  {
    console.log("in");
    var input_fields = ['name','email','companyname','contactnumber'];
    var inputs;
    var emailpattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
    $.each(input_fields,function(index,value){
        inputs = $('input[name="'+value+'"]');

        if($.trim(inputs.val()) == "")
        {
            inputs.addClass(' invalid');
            valid = false;
        }else{
            inputs.removeClass(' invalid');
            console.log(value+" invalid removed");
        }

        if(value == 'email')
        {
            if(!emailpattern.test(inputs.val()))
            {
                inputs.addClass(' invalid');
                valid = false;
            }
        }
    });
    
  }else if(form == 'technical')
  {
    console.log("in-technical");
    var checkbox = $(".technical-checkbox");
    if (checkbox.filter(':checked').length == 0) {
        console.log("no-selected");
                $(".technical-checkbox-error").show();
                    valid = false;
        }else{
            console.log("selected any");
             $(".technical-checkbox-error").hide();
        }

  }else if(form == 'deliverables')
  {
        /*no validation*/
  }else if(form == '' || form == undefined)
  {
    console.log("out");
      x = document.getElementsByClassName("tab-step-form");
      y = x[currentTab].getElementsByTagName("input");
      // A loop that checks every input field in the current tab:
      for (i = 0; i < y.length; i++) {
        // If a field is empty...
        if (y[i].value == "") {
          // add an "invalid" class to the field:
          y[i].className += " invalid";
          // and set the current valid status to false
          valid = false;
        }
      }
  }
  
  return valid; // return the valid status
}

</script>
<script>
    // vars
'use strict'
var	testim = document.getElementById("testim"),
		testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 4500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
		touchStartPos,
		touchEndPos,
		touchPosDiff,
		ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
		
		testim.addEventListener("touchstart", function(e) {
				touchStartPos = e.changedTouches[0].clientX;
		})
	
		testim.addEventListener("touchend", function(e) {
				touchEndPos = e.changedTouches[0].clientX;
			
				touchPosDiff = touchStartPos - touchEndPos;
			
				console.log(touchPosDiff);
				console.log(touchStartPos);	
				console.log(touchEndPos);	

			
				if (touchPosDiff > 0 + ignoreTouch) {
						testimLeftArrow.click();
				} else if (touchPosDiff < 0 - ignoreTouch) {
						testimRightArrow.click();
				} else {
					return;
				}
			
		})
}
</script>
<script>
function closeForm() {
  $('.form-popup-bg').removeClass('is-visible');
}

$(document).ready(function($) {
  
  /* Contact Form Interactions */
  $('#btnOpenForm').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg').addClass('is-visible');
  });
  
  $('#dig_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg2').addClass('is-visible');
  });
  $('#srg_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg3').addClass('is-visible');
  });
  $('#dsb_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg4').addClass('is-visible');
  });
  
    //close popup when clicking x or off popup
  $('.form-popup-bg').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg') || $(event.target).is('#btnCloseForm')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg2').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg2') || $(event.target).is('#btnCloseForm2')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg3').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg3') || $(event.target).is('#btnCloseForm3')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg4').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg4') || $(event.target).is('#btnCloseForm4')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  
  
  
  
  
  });
  </script>
 <!-- <script>
  $(document).ready(function () {
  let areAllValid = false;
  const fields$ = jQuery('input[type="text"], input[type="email"]');

  function checkValues() {
    areAllValid = true;
    for(const field of fields$) {
      if(!$(field).val()) {
        areAllValid = false
      }
    }
  }
 
  $("input").on("input", function () {
    checkValues()
   $("#submit").prop("disabled", !areAllValid);
  });
});
			</script>-->	
  <!-- <script type="text/javascript">
        function DownloadFile(fileName) {
            //Set the File URL.
            var url = "Files/" + fileName;
 
            //Create XMLHTTP Request.
            var req = new XMLHttpRequest();
            req.open("GET", url, true);
            req.responseType = "blob";
            req.onload = function () {
                //Convert the Byte Data to BLOB object.
                var blob = new Blob([req.response], { type: "application/octetstream" });
 
                //Check the Browser type and download the File.
                var isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    var url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.setAttribute("download", fileName);
                    a.setAttribute("href", link);
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                }
            };
            req.send();
        };
    </script>-->
 <script>
	function validate() {
		
		var valid = true;
		valid = checkEmpty($("#name"));
		valid = valid && checkEmail($("#email"));
		
		$("#btn-submit").attr("disabled",true);
		if(valid) {
			$("#btn-submit").attr("disabled",false);
		}	
	}
	function checkEmpty(obj) {
		var name = $(obj).attr("name");
		$("."+name+"-validation").html("");	
		$(obj).css("border","");
		if($(obj).val() == "") {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Required");
			return false;
		}
		
		return true;	
	}
	function checkEmail(obj) {
		var result = true;
		
		var name = $(obj).attr("name");
		$("."+name+"-validation").html("");	
		$(obj).css("border","");
		
		result = checkEmpty(obj);
		
		if(!result) {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Required");
			return false;
		}
		
		var email_regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,3})+$/;
		result = email_regex.test($(obj).val());
		
		if(!result) {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Invalid");
			return false;
		}
		
		return result;	
	}
</script>


</html>