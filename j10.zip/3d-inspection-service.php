<?php
session_start();
ini_set('upload_max_filesize', '40000M');
ini_set('post_max_size', '40000M');
ini_set('max_input_time', 300000);
ini_set('max_execution_time', '-1');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D inspection service | Online inspection service in India</title>
    <meta name="description" content="Best 3d inspection service provider in India,  Our team will perform a high-quality inspection of any part.">
    <meta name="keywords" content="3D application,Reverse Engineering Service,3D Inspection Service in India,3D softwares">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow" />
    <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
    <meta name="revisit-after" content="7 days" />
    <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/DIGITAL REVERSE ENGINEERING SERVICE.png" />
    <meta name="twitter:card" content="Precise3dm" />
    <meta name="twitter:site" content="@precise3d_m" />
    <meta name="twitter:title" content="Precise3dm" />
    <meta name="twitter:description" content="PRECISE3DM Provides all types of 3D inspection & Reverse engineering service done using specific 3D softwares" />
    <meta property="og:type" content="3D Scanning" />
    <meta property="og:title" content="3D application | Reverse Engineering Service | 3D Inspection Service in India " />
    <meta property="og:url" content="https://www.precise3dm.com/3d-inspection-service.php" />
    <meta property="og:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/DIGITAL REVERSE ENGINEERING SERVICE.png" />
    <meta property="og:description" content="PRECISE3DM Provides all types of 3D inspection & Reverse engineering service done using specific 3D softwares" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/optical-blue-light.css">
    <link rel="stylesheet" href="assets/css/scanner-styles.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="dig-insp-serv.css">
    <script src="assets/js/jquery-3.6.0.min.js"></script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-96527116-1"></script>
<script></script>
<style>
    .hero-image {
        background-image: url("assets/images/Reverse_engineering.jpg");
        background-color: #cccccc;
        height: 600px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
    }

    .hero-text {
        position: relative;
        left: 50%;
        top: 500px;
        transform: translate(-50%, -50%);
        color: white;
    }

    #regForm {
        /*background-color: #ffffff;*/
        background-image: url(printimages/BgImageServicePortfolio.jpg);
        background-position: right bottom;
        background-position: center center;
        background-repeat: no-repeat;
        background-size:cover;
        /*opacity: 0.9;*/
        /*margin: 100px auto;*/
        /*font-family: Raleway;*/
        padding: 40px;
        /*width: 70%;*/
        max-width: 450px;
        margin-bottom: 100px;
}
    
    }

    /* Hide all steps by default: */
    .tab-step-form {
        display: none;
        color: #dbdddf;
    }

    .tab-step-form .form-control {
        background: transparent;
        border: none;
        padding: 0;
        height: 40px;
        color: #fff;
        border-bottom: 1px solid rgb(68 58 58 / 20%);
        border-radius: 0;
    }

    button.step-form-btn,
    label.custom-file-upload {
        border: none;
        text-transform: uppercase;
        margin: 18px 17px 30px 17px;
        background-color: #ff8d1e;
        color: #ffffff;
        font-weight: bold;
        font-family: 'Fira Sans', sans-serif;
        padding: 7px 21px;
        width: 54%;
        border-radius: 5px;
        font-size: 14px;
    }

    input[type="file"] {
        display: none;
    }

    /* Mark input boxes that gets an error on validation: */
    input.invalid {
        border-bottom: 1px solid #dc0d0d !important;
    }

    .form-group {
        margin: 35px 0px;
    }

    #loader {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        background: rgba(0, 0, 0, 0.75) url(load2.gif) no-repeat center center;
        z-index: 10000;
    }

    input[type=checkbox] {
        position: relative;
        cursor: pointer;
        margin: 10px 20px 10px 10px;
    }

    input[type=checkbox]:before {
        content: "";
        display: block;
        position: absolute;
        width: 16px;
        height: 16px;
        top: 0;
        left: 0;
        border: 2px solid #555555;
        border-radius: 3px;
        background-color: white;
    }

    input[type=checkbox]:checked:after {
        content: "";
        display: block;
        width: 5px;
        height: 10px;
        border: solid black;
        border-width: 0 2px 2px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
        position: absolute;
        top: 2px;
        left: 6px;
    }

    textarea.form-control {
        box-shadow: 0 0 8px 2px rgb(0 0 0 / 20%);
        font-size: 12px;
        height: 100px !important;
        resize: none;
    }

    .shadow-textarea textarea.form-control::placeholder {
        font-weight: 300;
    }

    .shadow-textarea textarea.form-control {
        padding-left: 0.8rem;
        padding:15px;
    }

    span.error {
        color: red;
        display: none;
    }

    div.status-div {
        height: 100% !important;
        align-content: center;
        text-align: center;
        margin: auto;
    }

    button.status-btn {
        width: 100% !important;
    }
    .digital-inspection-car {
        background-color:black;
        padding-bottom: 4px;
    }
    .digital-inspection-car img{
        width:100%;
        height:175px;
    }
    .pt-100px {
        padding-top:100px;
    }
    .owl-carousel .owl-item img {
     -webkit-filter: grayscale(0); 
     filter: grayscale(0); 
    }
    .leftBg{
        background-image: url("images/cadnew.png");
    }
#import {
    
    /*width: 100vw;*/
    background-position: center;
    background-size: cover;
    position: relative;
}
</style>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-96527116-1');
</script>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '2980089008869976');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=2980089008869976&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<script type="text/javascript">
_linkedin_partner_id = "2283548";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(){var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
s.parentNode.insertBefore(b, s);})();
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "What is 3D Inspection?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "The physical part is 3D scanned by a 3D scanner and converted to 3D digital file, and imported into the 3D inspection software as a test object. CAD is also imported as a reference to the same interface and aligned to mesh(3D scan data). Subsequently, 3D shape & dimensional analysis is performed; as a result, it shows the difference between the manufactured part and the CAD design. This helps product makers to avoid manufacturing inaccuracy and miscalculation of ration."
    }
  },{
    "@type": "Question",
    "name": "How 3D Inspection helps in the automotive industry?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "The automotive industry needs plastic parts inspection, sheet metal inspection, 3D Inspection of Automotive engine components, engine cooling systems, cluster assembly, carburettors, engine body cylinder heads 3D scanning and Inspection, gap and flush of doors, windows, electrical panes inspection, braking systems and reservoirs, car body components inspection, lighting systems inspection, bulbs and interiors, fuel supply systems, vehicle tires, air-conditioning, and passenger seats. We shall 3d scan all such types of parts and compare them with CAD and perform advanced 3D inspection analysis."
    }
  },{
    "@type": "Question",
    "name": "What CAD files do you accept?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We accept all types of CAD file extensions in our 3D metrology software, such as CATIA, UG, Creo, and we accept their own native extension files."
    }
  },{
    "@type": "Question",
    "name": "Who needs an online 3D inspection service?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Our online and onsite 3D inspection service gives direct benefits to 3D scanning service providers. We get 3D scan and 3D CAD from 3D scanning service providers, who are providing 3D scanning and inspection service across many industries ."
    }
  },{
    "@type": "Question",
    "name": "I have a part and no CAD model. Can I still perform 3D Inspection?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, you can just upload the file in our 3D inspection form, and we shall go through your requirement, measure the scan file, and extract all the required dimensions."
    }
  },{
    "@type": "Question",
    "name": "Can I add my company logo to the final inspection report?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, you can email us the existing template and your current logo, we will create a customized inspection report."
    }
  }]
}
</script>
</head>
<body>
    <!-- header start -->
    <?php include('includes/header.php'); ?>
    <!-- header end -->
    <!-- section start-->
     <div class="cover-container pt-7">
        <div class="container">
            <div class="row">
            <div class="col-xs col-md-7">
            <div class="cover-title">
            <h1>Online 3D inspection service</h1>
            </div>
            <div class="cover-description">
                <h4><b>Unique web platform to support 3D Inspection</b></h4>
                
            </div>
            <div class="row mt-5">
                <div class=" col-12  d-flex">
                <h5> <ul>
                    <li>• Compare your 3D scans</li>
                    <li>• Perform the advanced digital Inspection</li>
                </ul></h5>
                </div>
                <div class="col-6">

                </div>
            </div>
            
            <div class="row mt-5 pb-2">
                <!--<div class="col-lg-8">-->
                    <div class="col-4 col-lg-2 b-right">
                        <div class="cover-title">
                            <h2>15+</h2>
                        </div>
                        <p class="cover-dash-para">
                        Industries served
                        </p>
                    </div>
                    <div class="col-4 col-lg-2">
                        <div class="cover-title">
                            <h2> 5+</h2>
                        </div>
                        <p class="cover-dash-para">
                        3D scanner technology to scan a wide range of 3D application
                        </p>
                    </div>
                    <div class="col-4 col-lg-2 b-left">
                        <div class="cover-title">
                            <h2> 20+</h2>
                        </div>
                        <p class="cover-dash-para">
                        Digital Applications
                        </p>
                    </div>
                <!--</div>-->
                
                
            </div>
            </div>
            <div class="col-xs col-md-5"sec1 ><br><br>
                <!-- <h3 class="content-heading mb-5" style="margin-top:20px;">Get Quote</h3> -->
                <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                                <p class='status-message'>Thanks for uploading the file<br/>Wait for 15 minutes for a rapid quotation to your Email or Whatsapp</p>
                                <div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    } else {
                        echo "<div class='row status-div'>
                                <p class='status-message'>Oops...Something went wrong, please try again
                            </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <form method="POST" action="digitalupload.php" id="regForm" enctype="multipart/form-data" onsubmit="disablebutton();">

                    <div class="tab-step-form" data-form-type="technicals" style="text-align:center">
                            <div class="form-group" style="margin:10px 0px -5px 0px">
                            <i class="fas fa-file-import fa-5x"></i><br>
                                <label for="uploadscan" class="custom-file-upload">
                                    Choose Files &nbsp;
                                    <i class="fas fa-arrow-up"></i>
                                </label>
                                <input type="file" class="form-control invisible" id="uploadscan" name="uploadscan" required />
                               
                            </div>
                          
                            <div class="form-group shadow-textarea">
                                    <p class="content-heading mb-5">(No Registration Required)</p>
                            </div>
                    </div>
                        
                    
                    <div class="tab-step-form" data-form-type="contact">
                            <h5>Contact Information</h5>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="name" name="name" placeholder="Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control required" id="email" name="email" placeholder="Email Address *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyname" name="companyname" placeholder="Company Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="contactnumber" name="contactnumber" placeholder="Contact Number *" required />
                            </div>
                        </div>
                       
                        <div class="tab-step-form" data-form-type="deliverables">
                            <h5>Types of Alignment</h5>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Best-fit-alignment"> Best fit alignment</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="RPS-alignment"> RPS alignment</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Datum-alignment"> Datum alignment</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="3-2-1-alignment"> 3-2-1 alignment</label>
                            </div>
                            <div class="form-group">
                                <label for="tolerancelimit">Tolrerance Limit (in mm)</label>
                                <input type="number" name="tolerancelimit"  style="width:50%">
                            </div>
                        </div>

                        <div class="tab-step-form" data-form-type="analysis">
                            <h5>Analysis</h5>
                            <div class="checkbox">
                                <label><input type="checkbox" name="2D-Comparison"> 2D Comparison</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="3D-Comparison"> 3D Comparison</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Sheet-metal-Boundary-Comparison"> Sheet metal / Boundary Comparison</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Virtual-edge-comparison-measurment"> Virtual edge comparison & measurment</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Profile-projection-comparison"> Profile projection comparison</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Geometry-Deviation"> Geometry Deviation</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="3D-2D-Curve-Deviation"> 3D/2D Curve Deviation</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Airfoil-Related-analysis-Airfoil-Twist"> Airfoil Related analysis (Airfoil & Twist)</label>
                            </div>
                        </div>

                        <div class="tab-step-form" data-form-type="inspections">
                            <p>Inspection report file format</p>
                            <div class="checkbox">
                                <label><input type="checkbox" name="pdf">.pdf</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="pptx"> .pptx</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="xls">.xls</label>
                            </div>
                            <p>Do you need customised report with your logo, pls upload the logo image</p>
                            <div class="form-group" style="margin:10px 0px -5px 0px">
                                <label for="uploadscan" class="custom-file-upload">
                                    Choose Files &nbsp;
                                    <i class="fas fa-arrow-up"></i>
                                </label>
                                <!--<input type="file" class="form-control" id="uploadscans" name="uploadscans" accept=".stl" required />-->
                               
                            </div>
                            <p>Kindly mention your specific requirement (if any):</p>
                        </div>
                        <div style="overflow:auto;">
                            <div style="display: flex;align-items: center;justify-content: center;">
                                <button type="button" id="prevBtn" class="step-form-btn" onclick="nextPrev(-1)">Back</button>
                                <button type="button" id="nextBtn" class="step-form-btn" onclick="nextPrev(1)">Next</button>
                            </div>
                        </div>
                        <!-- <button type="submit" class="btn btn-success" id="submit">Submit <img src="loader2.gif" id="loader" width="25" style="display: none;" /></button> -->


                    </form>
                <?php } ?>
                            
            </div>
         </div>
            </div>
            
                
                
            <div class="row p-absolute ">
                <div class="col-12 d-flex  justify-content-center">
                    <div class="button-slope-2">
                        <div class="button-slope-2-content">
                        3D Inspection Workflow

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

                
    <div class="cover-departments">
        <div class="container">
            <div class="row my-5">
            <!--<div class="col-12 justify-content-center mb-7">-->
                <div class="col-sm-6 col-lg-3">
                    <div class="service-gallery d-scanning-img">
                        <div class="rounded-button"><a href="#import"></a>Import 3D Scan/CAD</div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="service-gallery d-reverse-eng-img">
                        <div class="rounded-button"><span style=" padding: 0.2rem;"><a href="#alignment">Align</a></span></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="service-gallery low-volume-prod-img">
                        <div class="rounded-button"><a href="#types">Analysis</a></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="service-gallery d-inspection-img">
                        <div class="rounded-button"><a href="#caseStudy">Report</a></div>
                    </div>
                </div>

            <!--</div>-->
        </div>
        </div>
    </div>
    <div class="cover-feature">
        <div class="container">
            <div class="row">
                <div class="col-md-3 ">
                    <div id="v-nav" class="col-12 my-stick-nav" style="padding:6px;position:sticky !important;top:90px;" >
                        <ul class="vertical-navigator">
                        <li class="n-items"><a href='#overview'><span>OverView</span></a></li>
                    <li class="n-items"><a href='#keyfeature'><span>Key Features</span></a></li>
                    <li class="n-items"><a href='#imageGallery'><span>Image Gallery</span></a></li>
                    <li class="n-items"><a href='#videoGallery'><span>Video Gallery</span></a></li>                
                    <li class="n-items"><a href='#import'><span>Import Test & Reference data</span></a></li>
                    <li class="n-items"><a href='#alignment'><span>Alignment</span></a></li>
                    <li class="n-items"><a href='#types'><span>Types of 3D analysis</span></a></li>
                    <li class="n-items"><a href='#caseStudy'><span>Case Study</span></a></li>
                    <li class="n-items"><a href='#faqs'><span>FAQs</span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9 text-white" id="overview">
                    <div class="pt-100px">
                        <h3 class="content-heading mb-5">OVERVIEW</h3>
                        <p class="justify-para">Precise3DM digital inspection service provides advanced digital measurements of 3D scanned data or comparison between two digital files to perform a high level of shape and dimensional analysis that will help manufacturers have a complete study on manufacturing errors. Input for our digital inspection service will be two different CAD files or two 3D scanned files of separate parts or objects, or the CAD files of before manufacturing and 3D scanned files of end parts after the manufacturing. Once we perform the Inspection, we provide a customized pdf inspection report. In addition, we also offer all types of 3D scanning services in India if data.</p>
          </p>
                    </div>
                    <div id="keyfeature" class="pt-100px">
                <h3 class="content-heading mb-5">Key Features</h3>
                <p class="justify-para"> 
                    <ul>
                        <li>• We accept any 3D scan output <li>• CAD and no CAD inspection for 3D scanned parts <li>• Even partial 3D Scans we accept to compare with CAD or extract digital measurement. <li>• 3D Scan groups, point clouds, STL files are acceptable. <li>• A decade of experience in 3D inspection application <li>• We deliver output in customized or standard pdf format <li>• More than 25 3D metrology specialists to support any large volume projects</li>
                    </ul>
                </p>
                
            </div>
 
                    <div id="imageGallery" class="pt-100px">
                <h3 class="content-heading mb-5">Image Gallery</h3>
                
                <div class="owl-carousel owl-theme chennai-carousel-box owl-prev-set">
                <div class="item chennai-car-item">
                        <div class="printing-service-car">
                            <img src="DigitalInspectionServices/imageGallery/sheetmetal(new).png" alt="3D inspection service in India-nut bolt" class="img-fluid">
                            <div class="text-center mt-2">
                                <span></span>
                            </div>
                            <p class='text-center mb-3'>3D Inspection of sheet metal</p>
                        </div>
                    </div>
                    <div class="item chennai-car-item">
                        <div class="printing-service-car">
                            <img src="DigitalInspectionServices/imageGallery/10.png" alt="3D inspection service in India-ear buds" class="img-fluid">
                            <div class="text-center mt-2">
                                <span></span>
                            </div>
                            <p class='text-center'>3D Inspection of sheet metal</p>
                        </div>
                    </div>
                    <div class="item chennai-car-item">
                        <div class="printing-service-car">
                            <img src="DigitalInspectionServices/imageGallery/impeller.png" alt="3D inspection service in India-jewellery" class="img-fluid">
                            <div class="text-center mt-2">
                                <span></span>
                            </div>
                            <p class='text-center'>3D Inspection of impeller</p>
                        </div>
                    </div>
                    <div class="item chennai-car-item">
                        <div class="printing-service-car">
                            <img src="DigitalInspectionServices/imageGallery/sheetmetal.png" alt="3D inspection service in India-nut bolt" class="img-fluid">
                            <div class="text-center mt-2">
                                <span></span>
                            </div>
                            <p class='text-center mb-3'>3D Inspection of sheet metal</p>
                        </div>
                    </div>
                </div>
                <!-- image carousel ends -->
                <!-- <div class="owl-carousel owl-theme chennai-carousel-box mt-5 pt-5 owl-prev-set">
                    <div class="item chennai-car-item">
                        <div class="img-cadcont">
                            <img src="printimages/howItWorks.PNG" alt="3d mesh" class="img-fluid">
                        </div>
                    </div>
                    <div class="item chennai-car-item">
                        <div class="img-cadcont">
                            <img src="printimages/howItWorks.PNG" alt="3d mesh" class="img-fluid">
                        </div>
                    </div>
                    <div class="item chennai-car-item">
                        <div class="img-cadcont">
                            <img src="printimages/howItWorks.PNG" alt="3d mesh" class="img-fluid">
                        </div>
                    </div>
                    <div class="item chennai-car-item">
                        <div class="img-cadcont">
                            <img src="printimages/howItWorks.PNG" alt="3d mesh" class="img-fluid">
                        </div>
                    </div>
                </div> -->
            </div>
            <div id="videoGallery" class="pt-100px">
                <h3 class="content-heading mb-5">Video Gallery</h3>
                <div id="demo1" class="carousel slide" data-ride="carousel">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">
                        <li data-target="#demo1" data-slide-to="0" class="active"></li>
                        <li data-target="#demo1" data-slide-to="1"></li>
                        <li data-target="#demo1" data-slide-to="2"></li>
                    </ul>

                    <!-- The slideshow -->
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <iframe width="950" height="450" src="https://www.youtube.com/embed/TrVHD6Ji3CQ">
                            </iframe>
                            <!-- <img src="printimages/nut bolt.jpg" class=" d-block w-100" alt="sw"> -->
                            <div class=" carousel-caption d-none d-md-block text-center text-py-4 ">
                                <h5 class="text-white"></h5>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <iframe width="950" height="450" src="https://www.youtube.com/embed/3gxgc6kiIKI">
                            </iframe>
                            <div class=" carousel-caption d-none d-md-block text-center py-4 ">
                                <h5 class="text-white"></h5>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <iframe width="950" height="450" src="https://www.youtube.com/embed/YOwQxGhVWyk">
                            </iframe>
                            <div class=" carousel-caption d-none d-md-block text-center py-4 ">
                                <h5 class="text-white"></h5>
                            </div>
                        </div>
                    </div>
                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo1" data-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo1" data-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </a>
                </div>
            </div>

            <div id="import" class="pt-100px leftbg" >
                <h3 class="content-heading mb-5">Import Test (SCAN DATA) & Reference data (CAD DATA)</h3>
                <div class="row">
                    <div class="col-lg-5" >
                        <p class="justify-para" > 
                            <ul style="background-image: url(images/scannew.png);
    background-repeat: no-repeat;
    /* opacity: 0.9; */
    color: #fff !important;
    background-position-y: -101px;
    background-position-x: -68px;">
                                <li>- IGES File (.igs) <li>- STEP File (.stp)<li> - CATIA V4 File (.model) <li>- CATIA V5 File (.catpart) <li>- XO Model (.xdl) <li>- Parasolid Text File (.x_t) <li>- Parasolid Binary File (.x_b) <li>- ACIS Text File (.sat) <li>- ACIS Binary File (.sab) <li>- RapidForm2006 Model File 4.0 (.mdl)
                            </ul>
                        </p>
                    </div>
                    <div class="col-lg-5" class="rightBg">
                        <p class="justify-para"> 
                        <ul style="background-image: url(images/cadnew.png);
    background-repeat: no-repeat;
    /* opacity: 0.9; */
    color: #fff !important;
    background-position-y: -101px;
    background-position-x: -68px;">
                            <li>- Binary STL File (.stl) <li>- Ascii Point File (.asc) <li>- CyberWare Binary File (.ply) <li>- CyberWare Ascii File (.ply) <li>- OBJ File (.obj) <li>- Geomagic Points File (.pts) <li>- Geomagic Polygons File (.fcs) <li>- XO Model (.xdl) <li>- 3D Studio File (.3ds) <li>- AutoCAD DXF File (.dxf)
                        </ul>
                    </p>
                    </div>

                </div>
                
            </div>
            <div id="alignment" class="pt-100px ">
                <h3 class="content-heading">Alignment</h3>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">                
                        <p class="justify-para">
                            <h4 class="content-heading">3D Scan to CAD Alignment</h4>
                            The 3D Scan to CAD alignment tool helps in initial alignment of the measured data with the reference data automatically using Geomagic feature information. This alignment is used to position the measured data with the reference data as closely as possible before using advanced alignment tools. This scan can be used for aligning distant measured data, fully scanned data or partially scanned data.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/alignment/3D Scan to CAD.jpg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">                
                        <p class="justify-para">
                            <h4 class="content-heading">Best Fit Alignment:</h4>
                            The Best Fit alignment tool aligns measured data to the reference data using the overlapping regions between them. This tool is majorly used after using the 3D Scan to CAD alignment option. The Geomagic algorithm optimizes the rough alignment into more precise by minimizing the overall deviation between the measured data and the reference data.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/alignment/Best Fit Alignment.jpg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                </div>
                <br><br>

                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">                
                        <p class="justify-para">
                            <h4 class="content-heading">Datum Feature Alignment:</h4>
                            The Datum Alignment aligns measured data to the reference data by matching geometric features defined as datums. Datum Feature Alignment is useful for aligning measured data to the reference data by matching datum and geometric features.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/alignment/Datum Alignment - 1.jpg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">                
                        <p class="justify-para">
                            <h4 class="content-heading">RPS Alignment:</h4>
                            RPS stands for Reference Point System. The RPS Alignment aligns measured data to the reference data by matching pairs of circles, slots, spheres or any other conical geometric shapes. RPS Alignment is best used for sheet metal parts as well as parts which does not have clearly defined geometric features.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/alignment/RPS Alignment-1.jpg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">                
                        <p class="justify-para">
                            <h4 class="content-heading">3-2-1 Alignment:</h4>
                            The 3-2-1 Alignment tool aligns measured data to the reference data by matching pair sets of datums constructed by three (Plane), two (Vector), and one (Position) points, and locking down all six degrees of freedom of the coordinate system. 3 points are used to define a primary plane, 2 points define a secondary plane perpendicular to the primary plane, and the last single point defines the final plane that is perpendicular to both the primary and secondary plane.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/alignment/3-2-1 Alignment 1.jpg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                </div>
                <br><br>
            </div>


            <div id="types" class="pt-100px">
                <h3 class="content-heading">Type of 3D Analysis</h3>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">                
                        <p class="justify-para">
                            <h4 class="content-heading">1 . 2D Comparison</h4>
                            Creates a 2D plane that graphically illustrates the deviations between the reference data and the measured data. Easily accessible to compare the multiple points on the same plane. It is beneficial to compare the reference data and the measured Data on a sectional plane.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/2D comparison.jpeg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/3D Comparison - 1.jpeg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">
                        <p class="justify-para">
                        <h4 class="content-heading">2. 3D Comparison:</h4>
                        Calculate and display the shape and form deviation between reference and measured. The 3D Compare tool analyses the deviation between the reference and measured data by projecting all paired points onto the reference data.The deviation is displayed with a color map that helps analyze negative and positive deviation plots through a whole part.</p>
                    </div>

                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">
                        <p class="justify-para">
                        <h4 class="content-heading">3. Sheet Metal / Boundary Comparison:</h4>
                        Sheet metal or boundary comparison is basically used for sheet metal parts that are hard to analyze in 3D or 2D Comparison. This tool is handy to compare the boundaries, holes, and trim lines of the sheet metal between the reference data and the measured data.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/Sheet Metal_Boundary Comparison.jpg" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>


                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/virtualEdgeComparison.png" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                    <div class="col-lg-6 justify-content-center align-items-center mr-3">
                    <h4 class="content-heading">4. Virtual Edge Comparison &amp; Measurement:</h4>
                        <p>The Virtual Edge Comparison tool creates theoretical edges from rounded edges featured in a model and analyses the deviation between the reference and measured Data on the edges. In most cases of the real engineering world, a part has rounded edges modeled by filleting or abrasion caused by milling machine tooling. The Virtual Edge Comparison tool allows checking thedeviation on virtual edges created from the reference and measured data.</p>
                    </div>

                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">
                        <p class="justify-para">
                        <h4 class="content-heading">5. Profile Projection Comparison:</h4>    
                        The Profile Projection Comparison tool creates a silhouette from the Reference and Measured Data, and analyses the deviation on it.It is useful in analysing the outer part of a plastic part and trim lines for sheet metal parts.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/ProfileProjectionComparison.png" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>


                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/geometryDeviation.png" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                    <div class="col-lg-6 justify-content-center align-items-center mr-3">
                    <h4 class="content-heading">6. Geometry Deviation:</h4>
                        <p>The Geometry Deviation tool compares geometries such as cylinders, circles, and planes between the reference and measured data.This tool is useful for analysing important geometries on a part and comparing the sizes of geometries.</p>
                    </div>

                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-6  justify-content-center align-items-center mr-3">
                        <p class="justify-para">
                        <h4 class="content-heading">7. 2D/3D Curve Deviation:</h4>    
                        The 2D/3D Curve Deviation tool compares between curves created from the reference and measured Data, and displays the deviation results as coloured whiskers or points.This tool is basically essential to analyse freeform shapes, character lines and section curves.</p>
                    </div>
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/2D3DCurveDeviation.png" alt="3D inspection service in India"  class="keyfeature-img" />
                    </div>


                </div>
                <br><br>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-5">
                        <img src="DigitalInspectionServices/Types3DAnalysis/Airfoil.png" alt="3D inspection service in India" class="keyfeature-img" />
                    </div>
                    <div class="col-lg-6 justify-content-center align-items-center mr-3">
                    <h4 class="content-heading">8. Airfoil and Twist Analysis:</h4>
                        <p>The Airfoil Analysis tool allows you to analyse the key elements such as leading edge, trailing edge chord length and angle of airfoil profiles in measured data by comparing with the reference data. The 2D Twist Analysis tool analyses the deviation of twist angle between section profiles of the Reference and Measured Data.</p>
                    </div>

                </div>
            </div>
            <br><br>
            <div id="caseStudy" class="pt-100px">
                        <h3 class="content-heading mb-5">Case Study</h3>
                        <img src="printimages/caseStudy.PNG" alt="3D inspection service in India" class="col-12" />
                    </div>

                    <div id="faqs" class="pt-100px">
                        <h3 class="content-heading mb-5">FAQs</h3>
                        <section id="faq" class="faq  section-padding faq-link">
                            <div class="container">
                                <div class="row">
                                    <!-- <h4 class="text-uppercase text-white mt-2 mb-4 mx-lg-0 mx-2 pre-color">Frequently asked questions
                                    </h4> -->
                                    <div class="col-md-12 text-left px-lg-0">
                                        <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample"
                                            aria-expanded="false" aria-controls="collapseExample">What is 3D Inspection?</h5>
                                        <div class="left-border">
                                            <p class="collapse text-white" id="collapseExample">
The physical part is 3D scanned by a 3D scanner and converted to 3D digital file, and imported into the 3D inspection software as a test object. CAD is also imported as a reference to the same interface and aligned to mesh(3D scan data). Subsequently, 3D shape & dimensional analysis is performed; as a result, it shows the difference between the manufactured part and the CAD design. This helps product makers to avoid manufacturing inaccuracy and miscalculation of ration.

                                            </p>
                                        </div>
                                        <div class="col-md-12 text-left px-lg-0">
                                        </div>
                                        <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample1"
                                            aria-expanded="false" aria-controls="collapseExample">How 3D Inspection helps in the automotive industry?</h5>
                                        <div class="left-border">
                                            <p class="collapse text-white" id="collapseExample1">The automotive industry needs plastic parts inspection, sheet metal inspection, 3D Inspection of Automotive engine components, engine cooling systems, cluster assembly, carburettors, engine body cylinder heads 3D scanning and Inspection, gap and flush of doors, windows, electrical panes inspection, braking systems and reservoirs, car body components inspection, lighting systems inspection, bulbs and interiors, fuel supply systems, vehicle tires, air-conditioning, and passenger seats. We shall 3d scan all such types of parts and compare them with CAD and perform advanced 3D inspection analysis.

                                            </p>
                                        </div>
                                        <div class="col-md-12 text-left px-lg-0">
                                        </div>
                                        <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample3"
                                            aria-expanded="false" aria-controls="collapseExample">What CAD files do you accept?

                                        </h5>
                                        <div class="left-border">
                                            <p class="collapse text-white" id="collapseExample3">We accept all types of CAD file extensions in our 3D metrology software, such as CATIA, UG, Creo, and we accept their own native extension files.</p>
                                        </div>
                                        <div class="col-md-12 text-left px-lg-0">
                                        </div>
                                        <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample4"
                                            aria-expanded="false" aria-controls="collapseExample4">Who needs an online 3D inspection service?</h5>
                                        <div class="left-border">
                                            <p class="collapse text-white" id="collapseExample4">Who needs an online 3D inspection service?
Our online and onsite 3D inspection service gives direct benefits to 3D scanning service providers. We get 3D scan and 3D CAD from 3D scanning service providers, who are providing 3D scanning and inspection service across many industries .

                                            </p>
                                        </div>
                                        <div class="col-md-12 text-left px-lg-0">
                                        </div>
                                        <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample5"
                                            aria-expanded="false" aria-controls="collapseExample5">I have a part and no CAD model. Can I still perform 3D Inspection?</h5>
                                        <div class="left-border">
                                            <p class="collapse text-white" id="collapseExample5">I have a part and no CAD model. Can I still perform 3D Inspection?
Yes, you can just upload the file in our 3D inspection form, and we shall go through your requirement, measure the scan file, and extract all the required dimensions.

                                            </p>
                                        </div>
                                        
                                        <div class="col-md-12 text-left px-lg-0">
                                        </div>
                                        <h5 class="pre-color collapsed" data-toggle="collapse" href="#collapseExample8"
                                            aria-expanded="false" aria-controls="collapseExample8">Can I add my company logo to the final inspection report?</h5>
                                        <div class="left-border">
                                            <p class="collapse text-white" id="collapseExample8">Yes, you can email us the existing template and your current logo, we will create a customized inspection report.
                                            </p>
                                        </div>
                                        <div class="col-md-12 text-left px-lg-0">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>

    <hr class="separator">
    <?php include('includes/footer.php'); ?>

    <!-- bootstrap links-->
    <!-- <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/slim.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="assets/js/tabs.js"></script> -->
    <!-- bootstrap links-->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
    crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
    crossorigin="anonymous"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="assets/js/highlight.js"></script>
    <script src="assets/js/counter.js"></script>
</body>
<script type="text/javascript">
	$('input[type="text"]').on('blur',function(){
			var val = $(this).val();
			$(this).val($.trim(val));
	});

	function disablebutton()
	{
		$('#loader').show();
		//$('#submit').attr('disabled',true);
	}
	$(document).ready(function() {
    var owl = $('.owl-carousel');
    owl.owlCarousel({
        loop: true,
        nav: true,
        autoplay: false,
        autoplayTimeout: 3000,
        margin: 5,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            960: {
                items: 3
            },
            1200: {
                items: 3
            }
        }
    });
})
	
</script>
<script>
var fileInput = document.querySelector('input[type=file]');
var filenameContainer = document.querySelector('.custom-file-upload');
fileInput.addEventListener('change', function() {
    filenameContainer.innerText = fileInput.value.split('\\').pop();
});

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab-step-form");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  // fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab-step-form");
  var currentTabValue = $(".tab-step-form").eq(currentTab).attr("data-form-type");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm(currentTabValue)) return false;
  if (currentTab < x.length-1){
  // Hide the current tab:
  x[currentTab].style.display = "none";
    }
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    $('#loader').show();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm(form) {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;

  console.log(form);

  if(form == 'contact')
  {
    console.log("in");
    var input_fields = ['name','email','companyname','contactnumber'];
    var inputs;
    var emailpattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
    $.each(input_fields,function(index,value){
        inputs = $('input[name="'+value+'"]');

        if($.trim(inputs.val()) == "")
        {
            inputs.addClass(' invalid');
            valid = false;
        }else{
            inputs.removeClass(' invalid');
            console.log(value+" invalid removed");
        }

        if(value == 'email')
        {
            if(!emailpattern.test(inputs.val()))
            {
                inputs.addClass(' invalid');
                valid = false;
            }
        }
    });
    
  }else if(form == 'technical')
  {
    console.log("in-technical");
    var checkbox = $(".technical-checkbox");
    if (checkbox.filter(':checked').length == 0) {
        console.log("no-selected");
                $(".technical-checkbox-error").show();
                    valid = false;
        }else{
            console.log("selected any");
             $(".technical-checkbox-error").hide();
        }

  }else if(form == 'deliverables' || form == "inspections")
  {
        /*no validation*/
  }else if(form == '' || form == undefined)
  {
    console.log("out");
      x = document.getElementsByClassName("tab-step-form");
      y = x[currentTab].getElementsByTagName("input");
      // A loop that checks every input field in the current tab:
      for (i = 0; i < y.length; i++) {
        // If a field is empty...
        if (y[i].value == "") {
          // add an "invalid" class to the field:
          y[i].className += " invalid";
          // and set the current valid status to false
          valid = false;
        }
      }
  }
  
  return valid; // return the valid status
}

</script>
<script>
    // vars
'use strict'
// var	testim = document.getElementById("testim"),
// 		testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
//     testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
//     testimLeftArrow = document.getElementById("left-arrow"),
//     testimRightArrow = document.getElementById("right-arrow"),
//     testimSpeed = 4500,
//     currentSlide = 0,
//     currentActive = 0,
//     testimTimer,
// 		touchStartPos,
// 		touchEndPos,
// 		touchPosDiff,
// 		ignoreTouch = 30;
// ;

// window.onload = function() {

//     // Testim Script
//     function playSlide(slide) {
//         for (var k = 0; k < testimDots.length; k++) {
//             testimContent[k].classList.remove("active");
//             testimContent[k].classList.remove("inactive");
//             testimDots[k].classList.remove("active");
//         }

//         if (slide < 0) {
//             slide = currentSlide = testimContent.length-1;
//         }

//         if (slide > testimContent.length - 1) {
//             slide = currentSlide = 0;
//         }

//         if (currentActive != currentSlide) {
//             testimContent[currentActive].classList.add("inactive");            
//         }
//         testimContent[slide].classList.add("active");
//         testimDots[slide].classList.add("active");

//         currentActive = currentSlide;
    
//         clearTimeout(testimTimer);
//         testimTimer = setTimeout(function() {
//             playSlide(currentSlide += 1);
//         }, testimSpeed)
//     }

//     testimLeftArrow.addEventListener("click", function() {
//         playSlide(currentSlide -= 1);
//     })

//     testimRightArrow.addEventListener("click", function() {
//         playSlide(currentSlide += 1);
//     })    

//     for (var l = 0; l < testimDots.length; l++) {
//         testimDots[l].addEventListener("click", function() {
//             playSlide(currentSlide = testimDots.indexOf(this));
//         })
//     }

//     playSlide(currentSlide);

//     // keyboard shortcuts
//     document.addEventListener("keyup", function(e) {
//         switch (e.keyCode) {
//             case 37:
//                 testimLeftArrow.click();
//                 break;
                
//             case 39:
//                 testimRightArrow.click();
//                 break;

//             case 39:
//                 testimRightArrow.click();
//                 break;

//             default:
//                 break;
//         }
//     })
		
// 		testim.addEventListener("touchstart", function(e) {
// 				touchStartPos = e.changedTouches[0].clientX;
// 		})
	
// 		testim.addEventListener("touchend", function(e) {
// 				touchEndPos = e.changedTouches[0].clientX;
			
// 				touchPosDiff = touchStartPos - touchEndPos;
			
// 				console.log(touchPosDiff);
// 				console.log(touchStartPos);	
// 				console.log(touchEndPos);	

			
// 				if (touchPosDiff > 0 + ignoreTouch) {
// 						testimLeftArrow.click();
// 				} else if (touchPosDiff < 0 - ignoreTouch) {
// 						testimRightArrow.click();
// 				} else {
// 					return;
// 				}
			
// 		})
// }
//

</html>