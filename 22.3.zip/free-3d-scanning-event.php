<?php
session_start();
ini_set('upload_max_filesize', '40000M');
ini_set('post_max_size', '40000M');
ini_set('max_input_time', 300000);
ini_set('max_execution_time', '-1');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="3D Scanning and 3D Printing open house event">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- font awesome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/events_land.css">
    <title>Free Live 3D Scanning & Reverse Engineering event in Coimbatore</title>
    <script src="assets/js/jquery-3.6.0.min.js"></script>
</head>

<body>
    <!-- header start -->
    <?php include('includes/header.php'); ?>
    <!-- header end -->

    <!--event deatils section start-->
    <section id="events_details4_banner" class="pt-4">
            <!--<button class="banner-btn" onclick="window.location.href='https://docs.google.com/forms/d/e/1FAIpQLScuot_c5N459BQDRZbb3Ph02HLBJDqOQ5diMYZ9OUHnQP7nlQ/viewform'" target="_blank" type=button>REGISTER NOW</button>-->
    </section>
    <div class="heading_event m-320">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 aboutus-herohead pl-0">
                    <h3 id="reg click">Live 3D Scanning & Reverse Engineering event in Coimbatore. 

 
 </h3>
                </div>
            </div>
        </div>
    </div>
    <!-- event deatils banner section end-->
    <section id="events_section_one">
        <div class="container">
            <div class="row">
                <div class="col-12 eve-details-cont">
                    <button onclick="window.location.href='https://forms.gle/mACA8MW1uDkMezBx7'" target="_blank" >REGISTER NOW</button>
                    <h5>Join us on Friday 6th th,  May  2022, (9 am to 7.30 pm)</h5>
                    <div class="row eve-details-2">
                        <div class="col-md-8">
                            <h4>What is this event about?</h4>
                             <p style="text-align: justify;">We, Precise3DM India's largest 3d scanning service and solution provider, would like to invite Manufacturing and product development companies to witness the applications of 3D Reverse engineering and 3D Inspection using 3D scanning technology right in the centre of the city Ganapathy, Coimbatore. 

 </p>
                        </div>
                       
                        <div class="col-md-12 eve-de-img-house">
                             <h4>Featured products and solutions </h4>
                        
                            <!--<img src="assets/images/events_images/events_webinarphoto.png" alt="" class="img-fluid">-->
                            <div class="row">
                            <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/arm-based-3d-scanning-service-in-india.php" class=""><img src="assets/images/products/arm-based.png" alt="" class="img-fluid"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;">  FARO ARM BASED SCANNER

</h6>

                                </div>
                                <div class="col-md-3 mt-5" style="margin-top: 5px;padding-top: 19px;">
                                    <a href="optical-blue-light-3d-scanning-service-in-india.php" class=""><img src="assets/images/products/optical-blue-light_3d-scanning.png" style="height: 168px;position: relative;top: -34px;" alt="" class="img-fluid"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;">  GOM ATOS COMPACT SCAN
</h6>

                                </div>
                                <div class="col-md-3">
                                    <a href="einscan-pro-2x-2020-3d-scanner-in-india.php"><img src="assets/images/products/chapter3-png-2.png" alt="" class="img-fluid" style="display: block;  
margin-left: auto;  
margin-right: auto;"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;"> EINSCAN PRO2X 2020
</h6>

                                    <div>
                                        
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <a href="freescan-ue-series-3d-scanner-in-india.php" class=""><img src="assets/images/products/chapter4-Image-5.png" alt="" class="img-fluid" style="display: block;  
margin-left: auto;  
margin-right: auto;"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;">  Freescan UE7</h6>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 eve-details-3">
                    <h4>When and where?</h4>
                    <ul>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Date: may 6th Friday, 2022 

                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Venue: PRECISE3DM -Coimbatore 
60/61, Vivekanandha Street, Ramakrishnapuram, Ganapathy (Po), Coimbatore - 641006

 </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Time morning 9 to 7.30 pm ( Must pre-book the slots as each slot only ten members are allowed )
 </li>
                    </ul>
                    
                    <h4>What will you witness? 
</h4>
                    <ul>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Live 3d scanning using GOM, Einscan, Freescan and portable laser arm
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Different types of 3d scanners 
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        3D reverse engineering of scanned parts 
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        3D Inspection of live components 
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Production 3D printed sample parts  
                        </li>
                    </ul>
                    
                    <h4>Key features </h4>
                    <ul>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Bring your live component and get it scanned <strong>"Free Of Cost" </strong>(Pay for only modelling & Inspection)
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Get free 3d scan files 
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Free Demonstration of all scanner equipment 
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Geomagic software demo 

                        </li>
                        
                    </ul>
                    <h4>Who can attend  </h4>
                    <ul>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Die casting Manufacturers
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        OEM                         </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Tool and Die makers 
                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Foundries 

                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Jig and fixture manufacturers 
 

                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Home appliance manufacturers 
 

                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        SPM & machine builders 
 

                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Motor, Pump & Valve industries 
 

                        </li>
                        <li><img src="assets/images/events_images/right pointing arrow..png" alt="">
                        Technology enthusiasts and others 
 

                        </li>
                        
                    </ul>
                    <h4>What's next?</h4>
                    <div class=eve-details-cont>
                    <button onclick="window.location.href='https://forms.gle/mACA8MW1uDkMezBx7'" target="_blank" >REGISTER NOW</button>
</div>  
</ul>
                    
                </div>

<!--                <div class="col-md-12 eve-details-3 mb-4">-->
<!--                    <h4>Speaker</h4>-->
<!--                    <div class="row">-->
<!--                        <div class="col-md-2 text-center">-->
<!--                            <img src="assets/images/events_images/speaker.png" alt="" class="img-fluid">-->
<!--                        </div>-->
<!--                        <div class="col-md-10 event-mdname pl-0">-->
<!--                            <h3>SINGARAJ MAHARAJAN</h3>-->
<!--                            <p>Managing Director</p>-->
<!--                            <p>Precise 3D Metrology & Design Solutions Pvt Ltd</p><br>-->
<!--                            <p>A technopreneur owns three technology-based companies that cater to three different sets of industries as Automotive and Engineering, Healthcare, Civil & construction.</p>-->
<!--                            <p>He has got a decade of experience in using different types of 3D scanners along with Geomagic Reverse Engineering software.-->
<!--He is also ex 3dsysetms territory manager in India to take care of channel management and technical sales of 3dsystems geomagic 3d scanning software. Before 3dsystems, he had worked in Geomagic Inc, USA, to look after Geoagic software post and pre-sales support to 3d scanner OEM'S and 3d scanner distributors, in south Asian countries, so he has got Great Knowledge of Geomagic Design X software to demonstrate the capability and key industrial application usages with varieties of different technology scanners.</p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
            </div>
        </div>
    </section>
    <!-- modalcontent here -->
    <!-- Button trigger modal -->
    <!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">-->
    <!--    Launch demo modal-->
    <!--</button>-->

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Webinar Registration</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                    if (isset($_SESSION['status'])) {
                        if ($_SESSION['status'] == "success") {
                            echo "<div class='col-md-3 web-form-col'>
                                <div style='width: 100%'>Thanks for submitting the details! We will get back to you soon!</div>
                            </div>";
                        } else {
                            echo "<div class='row status-div'>
                                    <p class='status-message'>Oops...Something went wrong, please try again
                                </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                        }
                        unset($_SESSION['status']);
                    } else { ?>
                        <div class="col-md-12 web-form-col">
                            <form method="POST" action="web_submitevent.php" id="web_form" autocomplete="off">
                            <div class="form-group web-input-fields">
                                <input type="text" name="web_name" id="web_name" class="form-control" placeholder="Name*">
                                <input type="email" name="web_email" id="web_email" class="form-control" placeholder="Email*">
                                <input type="text" name="web_contnum" id="web_contnum" class="form-control" placeholder="Contact number*" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                <input type="text" name="web_companyname" id="web_companyname" placeholder="Company name" class="form-control">
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn" id="web_submit" disabled>Submit</button>
                            </div>
                        </form>
                        	<?php } ?>
                       </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modalcontent here -->
    <hr class="term-seperator">
    <?php include('includes/footer.php'); ?>


    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/counter.js"></script>
    <script>
    $(document).ready(function(){
        function emptyInputsweb(){
            if($("#web_name").val() == "" || $("#web_email").val() == "" || $("#web_contnum").val() == ""){
                $("#web_submit").attr('disabled', true);
            }
        }
        $(document).on("keyup blur", "#web_form input", function(){
           if($(this).valid() == true){
               $("#web_submit").removeAttr('disabled');
               emptyInputsweb();
            }
            else{
               $("#web_submit").attr('disabled', true);
            }
        });
        $.validator.addMethod("email_check", function(value, element) {
            var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if (regex.test(value)) {
                return true
            } else {
                return false
            }
        });
        $("#web_form").validate({
            rules: {
                web_name: {
                    required: true,
                },
                web_email: {
                    required: true,
                    email_check: true,
                },
                web_contnum:{
                    required:true,
                    minlength: 10,
                },
            },
            messages:{
                web_email:{
                    email_check:"Please enter the valid email"
                },
                web_contnum:{
                    minlength:"Please enter valid 10 numbers."
                }
            }
        });
    });
</script>
 <script type="text/javascript">
// 	$('input[type="text"]').on('blur',function(){
// 			var val = $(this).val();
// 			$(this).val($.trim(val));
// 	});

	function disablebutton()
	{
		$('#loader').show();
		
		//$('#submit').attr('disabled',true);
	}
</script>
<script>
	function manage(txt) {
        var bt = document.getElementById('submit');
        if (txt.value != '') {
            bt.disabled = false;
        }
        else {
            bt.disabled = true;
        }
    }    
</script>
<script>
var fileInput = document.querySelector('input[type=file]');
var filenameContainer = document.querySelector('.custom-file-upload');
fileInput.addEventListener('change', function() {
    filenameContainer.innerText = fileInput.value.split('\\').pop();
});

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab-step-form");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  // fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab-step-form");
  var currentTabValue = $(".tab-step-form").eq(currentTab).attr("data-form-type");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm(currentTabValue)) return false;
  if (currentTab < x.length-1){
  // Hide the current tab:
  x[currentTab].style.display = "none";
    }
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    $('#loader').show();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm(form) {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;

  console.log(form);

  if(form == 'contact')
  {
    console.log("in");
    var input_fields = ['name','email','companyname','contactnumber'];
    var inputs;
    var emailpattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
    $.each(input_fields,function(index,value){
        inputs = $('input[name="'+value+'"]');

        if($.trim(inputs.val()) == "")
        {
            inputs.addClass(' invalid');
            valid = false;
        }else{
            inputs.removeClass(' invalid');
            console.log(value+" invalid removed");
        }

        if(value == 'email')
        {
            if(!emailpattern.test(inputs.val()))
            {
                inputs.addClass(' invalid');
                valid = false;
            }
        }
    });
    
  }else if(form == 'technical')
  {
    console.log("in-technical");
    var checkbox = $(".technical-checkbox");
    if (checkbox.filter(':checked').length == 0) {
        console.log("no-selected");
                $(".technical-checkbox-error").show();
                    valid = false;
        }else{
            console.log("selected any");
             $(".technical-checkbox-error").hide();
        }

  }else if(form == 'deliverables')
  {
        /*no validation*/
  }else if(form == '' || form == undefined)
  {
    console.log("out");
      x = document.getElementsByClassName("tab-step-form");
      y = x[currentTab].getElementsByTagName("input");
      // A loop that checks every input field in the current tab:
      for (i = 0; i < y.length; i++) {
        // If a field is empty...
        if (y[i].value == "") {
          // add an "invalid" class to the field:
          y[i].className += " invalid";
          // and set the current valid status to false
          valid = false;
        }
      }
  }
  
  return valid; // return the valid status
}

</script>
<script>
    // vars
'use strict'
var	testim = document.getElementById("testim"),
		testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 4500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
		touchStartPos,
		touchEndPos,
		touchPosDiff,
		ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
		
		testim.addEventListener("touchstart", function(e) {
				touchStartPos = e.changedTouches[0].clientX;
		})
	
		testim.addEventListener("touchend", function(e) {
				touchEndPos = e.changedTouches[0].clientX;
			
				touchPosDiff = touchStartPos - touchEndPos;
			
				console.log(touchPosDiff);
				console.log(touchStartPos);	
				console.log(touchEndPos);	

			
				if (touchPosDiff > 0 + ignoreTouch) {
						testimLeftArrow.click();
				} else if (touchPosDiff < 0 - ignoreTouch) {
						testimRightArrow.click();
				} else {
					return;
				}
			
		})
}
</script>
<script>
function closeForm() {
  $('.form-popup-bg').removeClass('is-visible');
}

$(document).ready(function($) {
  
  /* Contact Form Interactions */
  $('#btnOpenForm').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg').addClass('is-visible');
  });
  
  $('#dig_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg2').addClass('is-visible');
  });
  $('#srg_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg3').addClass('is-visible');
  });
  $('#dsb_downloadbtn').on('click', function(event) {
    event.preventDefault();

    $('.form-popup-bg4').addClass('is-visible');
  });
  
    //close popup when clicking x or off popup
  $('.form-popup-bg').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg') || $(event.target).is('#btnCloseForm')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg2').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg2') || $(event.target).is('#btnCloseForm2')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg3').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg3') || $(event.target).is('#btnCloseForm3')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  $('.form-popup-bg4').on('click', function(event) {
    if ($(event.target).is('.form-popup-bg4') || $(event.target).is('#btnCloseForm4')) {
      event.preventDefault();
      $(this).removeClass('is-visible');
    }
  });
  
  
  
  
  
  });
  </script>
 <!-- <script>
  $(document).ready(function () {
  let areAllValid = false;
  const fields$ = jQuery('input[type="text"], input[type="email"]');

  function checkValues() {
    areAllValid = true;
    for(const field of fields$) {
      if(!$(field).val()) {
        areAllValid = false
      }
    }
  }
 
  $("input").on("input", function () {
    checkValues()
   $("#submit").prop("disabled", !areAllValid);
  });
});
			</script>-->	
  <!-- <script type="text/javascript">
        function DownloadFile(fileName) {
            //Set the File URL.
            var url = "Files/" + fileName;
 
            //Create XMLHTTP Request.
            var req = new XMLHttpRequest();
            req.open("GET", url, true);
            req.responseType = "blob";
            req.onload = function () {
                //Convert the Byte Data to BLOB object.
                var blob = new Blob([req.response], { type: "application/octetstream" });
 
                //Check the Browser type and download the File.
                var isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    var url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.setAttribute("download", fileName);
                    a.setAttribute("href", link);
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                }
            };
            req.send();
        };
    </script>-->
 <script>
	function validate() {
		
		var valid = true;
		valid = checkEmpty($("#name"));
		valid = valid && checkEmail($("#email"));
		
		$("#btn-submit").attr("disabled",true);
		if(valid) {
			$("#btn-submit").attr("disabled",false);
		}	
	}
	function checkEmpty(obj) {
		var name = $(obj).attr("name");
		$("."+name+"-validation").html("");	
		$(obj).css("border","");
		if($(obj).val() == "") {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Required");
			return false;
		}
		
		return true;	
	}
	function checkEmail(obj) {
		var result = true;
		
		var name = $(obj).attr("name");
		$("."+name+"-validation").html("");	
		$(obj).css("border","");
		
		result = checkEmpty(obj);
		
		if(!result) {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Required");
			return false;
		}
		
		var email_regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,3})+$/;
		result = email_regex.test($(obj).val());
		
		if(!result) {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Invalid");
			return false;
		}
		
		return result;	
	}
</script>


</body>

</html>