<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Precise3DM uses Freeform reverse engineering software to convert 3D sculpted mesh into the NURBS-based CAD format. The output format is STEP, IGES, and Parasolid files">
    <meta name="keywords" content="NURBS modeling in Geomagic software, 3D mesh to NURBS modeling service, NURBS surface reference model services, Geomagic Freeform software, NURBS solids & surfaces, 3D modeling NURBS surfaces ">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/optical-blue-light.css">

    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/parametric-cad.css">
    <title>Reverse engineering freeform software-3D scan services-Scan to tyre-flatten-analysis</title>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-96527116-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-96527116-1');
    </script>
    <!-- Facebook Pixel Code -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '2980089008869976');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2980089008869976&ev=PageView&noscript=1" /></noscript>
    <!-- End Facebook Pixel Code -->
    <script type="text/javascript">
        _linkedin_partner_id = "2283548";
        window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
        window._linkedin_data_partner_ids.push(_linkedin_partner_id);
    </script>
    <script type="text/javascript">
        (function() {
            var s = document.getElementsByTagName("script")[0];
            var b = document.createElement("script");
            b.type = "text/javascript";
            b.async = true;
            b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
            s.parentNode.insertBefore(b, s);
        })();
    </script>
    <noscript>
        <img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
    </noscript>
</head>
<style>
    .need-to-fixtop{
        position:fixed;
        top:86px;
    }
    #myTabnew li a i{
        float:right;
        padding-top:4px;
    }
</style>
<body>
    <!-- header start -->
    <?php include('includes/header.php'); ?>
    <!-- header end -->

    <!--about us banner section start-->
    <section id="tyre-flatten-analysis" class="pt-4">
        <div class="container">
            <div class="row h-300">
            </div>
        </div>
        <div class="heading m-320">
            <div class="container">
                <div class="row ">
                    <div class="col-md-6 aboutus-herohead pl-0">
                        <h3>Tyre-flatten-analysis</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about us banner section end-->

    <!-- about us section starts-->
    <section id="aboutus-bg" class="pb-3">
        <div class="aboutus-sec2">

        </div>
        <div class="container mt-4">
            <div class="row">
                <div class="col-md-4 cad-left-pills">
                    <div class="w-100">
                        <div class="my-stick-nav">
                            <ul class="nav" id="myTabnew">
                                <li class="nav-item">
                                    <a class="nav-link active" id="overview-tab" href="#overview">OVERVIEW <i class="fas fa-angle-right"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="workflow-tab" href="#workflow">WORKFLOW <i class="fas fa-angle-right"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="imagegallery-tab" href="#imagegallery">IMAGE GALLERY <i class="fas fa-angle-right"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="videogallery-tab" href="#videogallery">VIDEO GALLERY <i class="fas fa-angle-right"></i></a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" id="cadindustry-tab" href="#cadindustry">INDUSTRY <i class="fas fa-angle-right"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="whatsnext-tab" href="#whatsnext">WHAT'S NEXT <i class="fas fa-angle-right"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="cadblog-tab" href="#rel_blog">BLOGS<i class="fas fa-angle-right"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
                <div class="col-md-8 mt-3">
                    <div class="" id="myTabContentnew">
                        <div class="" id="overview">
                            <h4>Overview</h4>
                            <div class="overview-cont">
                                <h6>Tyre Flatten analysis </h6>
                                <p>Tyres make up the most dynamic part of the vehicle as they change shape significantly because of the range of forces acting upon them. In military applications, it is important to capture the tyre impressions of the rival territory vehicles to know what vehicles they used to attack. Traditionally, such evidence or impression is captured by taking 2D color photographs and these photographs require overlapping and stitching them together. But with the help of handheld 3D scanner, we can digitize tyre impression evidence which have long spatial spans such as long tyre track impressions which would be difficult to fit into a single photographic shot. We can scan the gaps between layered gum rubber strips and flat rubber sheets that make up the body of the tire. This 3D scan data is imported in 3D inspection software like Geomagic Control X where a complete set of built-in extrusion measurement tools that include functions such as length, width, height, depth, angle, vertex location, surface data for dents and bulges, and groove dimension of the tyre can be measured. Final 3D CAD file inspection report can be customized and given to the customer in the desirable format.
</p>
                                
                            </div>
                        </div>
                        <!-- workflow tabs -->
                        <div class="mt-5" id="workflow">
                            <h4>WORKFLOW</h4>
                            <div class="owl-carousel owl-theme chennai-carousel-box owl-prev-set">
                                <div class="item chennai-car-item">
                                    <div class="wf-cadcont">
                                        <img src="assets/images/tyre-flatten-analysis/1) import original data.png" alt="3d mesh" class="img-fluid">
                                        <div class="text-center mt-2">
                                            <span>1</span>
                                        </div>
                                        <p>Import original data</p>
                                    </div>
                                </div>
                                <div class="item chennai-car-item">
                                    <div class="wf-cadcont">
                                    <img src="assets/images/tyre-flatten-analysis/2) flatten the scan data.png" alt="3d mesh" class="img-fluid">
                                        <div class="text-center mt-2">
                                            <span>2</span>
                                        </div>
                                        <p>Flatten the scan data</p>
                                    </div>
                                </div>
                                <div class="item chennai-car-item">
                                    <div class="wf-cadcont">
                                    <img src="assets/images/tyre-flatten-analysis/3) Allign between fatten data _ original.png" alt="3d mesh" class="img-fluid">
                                        <div class="text-center mt-2">
                                            <span>3</span>
                                        </div>
                                        <p>Allign between fatten data _ original</p>
                                    </div>
                                </div>
                                <div class="item chennai-car-item">
                                    <div class="wf-cadcont">
                                    <img src="assets/images/tyre-flatten-analysis/4) check deviation.png" alt="3d mesh" class="img-fluid">
                                        <div class="text-center mt-2">
                                            <span>4</span>
                                        </div>
                                        <p>Check deviation</p>
                                    </div>
                                </div>
                                <div class="item chennai-car-item">
                                    <div class="wf-cadcont">
                                    <img src="assets/images/tyre-flatten-analysis/5) Check Deviation with colorbar.png" alt="3d mesh" class="img-fluid">
                                        <div class="text-center mt-2">
                                            <span>5</span>
                                        </div>
                                        <p>Check Deviation with colorbar</p>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <!-- workflow tabs end-->
                        <!-- image tabs -->
                        <div class="mt-5" id="imagegallery">
                            <h4>IMAGE</h4>
                            <div id="demo" class="carousel slide" data-ride="carousel">

                                <!-- Indicators -->
                                <ul class="carousel-indicators">
                                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                                    <li data-target="#demo" data-slide-to="1"></li>
                                    <li data-target="#demo" data-slide-to="2"></li>
                                </ul>

                                <!-- The slideshow -->
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                    <img src="assets/images/tyre-flatten-analysis/3.jpg" alt="sw">
                                        <div class="text-center py-4 bg-white">
                                            <p>Tyre Flatten analysis </p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                    <img src="assets/images/tyre-flatten-analysis/3.jpg "alt="sw">
                                        <div class="text-center py-4 bg-white">
                                            <p>Tyre Flatten analysis </p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                    <img src="assets/images/tyre-flatten-analysis/3.jpg" alt="sw">
                                        <div class="text-center py-4 bg-white">
                                            <p>Tyre Flatten analysis </p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Left and right controls -->
                                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                                    <span class="carousel-control-prev-icon"></span>
                                </a>
                                <a class="carousel-control-next" href="#demo" data-slide="next">
                                    <span class="carousel-control-next-icon"></span>
                                </a>
                            </div>
                        </div>
                        <!-- image tabs end-->
                        <!-- video tabs -->
                        <div class="mt-5" id="videogallery">
                            <h4>VIDEO</h4>
                            <div id="demo1" class="carousel slide" data-ride="carousel">

                                <!-- Indicators -->
                                <ul class="carousel-indicators">
                                    <li data-target="#demo1" data-slide-to="0" class="active"></li>
                                    <li data-target="#demo1" data-slide-to="1"></li>
                                    <li data-target="#demo1" data-slide-to="2"></li>
                                </ul>

                                <!-- The slideshow -->
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <iframe width="100%" height="345" src="https://www.youtube.com/embed/E5VhABS2rPY" allow="autoplay" id="einscan_h_vdo">
                                        </iframe>
                                        <div class="text-center py-4 bg-white">
                                            <p>Tyre Flatten analysis</p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <iframe width="100%" height="345" src="https://www.youtube.com/embed/E5VhABS2rPY" allow="autoplay" id="einscan_h_vdo">
                                        </iframe>
                                        <div class="text-center py-4 bg-white">
                                            <p>Tyre Flatten analysis</p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <iframe width="100%" height="345" src="https://www.youtube.com/embed/E5VhABS2rPY" allow="autoplay" id="einscan_h_vdo">
                                        </iframe>
                                        <div class="text-center py-4 bg-white">
                                            <p>Tyre Flatten analysis</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Left and right controls -->
                                <a class="carousel-control-prev" href="#demo1" data-slide="prev">
                                    <span class="carousel-control-prev-icon"></span>
                                </a>
                                <a class="carousel-control-next" href="#demo1" data-slide="next">
                                    <span class="carousel-control-next-icon"></span>
                                </a>
                            </div>
                        </div>
                        <!-- video tabs end-->
                        <div class="mt-5" id="cadindustry">
                            <h4>INDUSTRIES WE SERVE</h4>
                            <!--industry serve section start -->
                            <div class="container indus-bg">
                                <div class="row ">
                                    <div class="col-md-6">
                                        <div class="row">
                                        <div class="col-lg-3 col-md-3 col-6 text-center px-2 ind-icon">
                                                <div class=" my-2">
                                                    <a href=""><img src="assets/images/icons/ind-22.svg" class="img-fluid" alt="Tire Industry"></a>
                                                    <a href="">
                                                        <p class="name text-white">Tire Industry</p>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-md-3 col-6 text-center px-2 ind-icon">
                                                <div class=" my-2">
                                                    <a href=""><img src="assets/images/icons/ind-17.svg" class="img-fluid" alt="Defence"></a>
                                                    <a href="">
                                                        <p class="name text-white">Defence</p>
                                                    </a>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                <!--row end-->
                                <!--row start-->
                                
                            </div>
                            <!--industry serve section end -->
                        </div>
                        <div class="mt-5" id="whatsnext">
                            <h4>WHAT'S NEXT?</h4>
                            <div class="overview-cont">
                                <div class="row">
                                    <div class="col-sm-12 whatnext-cont">
                                        <img src="assets/images/Scanto_parametric_CAD/cx.jpeg" alt="sw">
                                        <a href="https://precise3dm.com/geomagic-control-x-3d-inspection-software.php">Buy dedicated Reverse Engineering software</a>
                                    </div>
                                    <div class="col-sm-12 whatnext-cont">
                                        <img src="assets/images/Scanto_parametric_CAD/upload.png" alt="upload">
                                        <a href="scan-to-cad-service.php" >Upload your 3D Scan for converting into Tyre Flatten analysis </a>
                                    </div>
                                    <div class="col-sm-12 whatnext-cont">
                                        <img src="assets/images/Scanto_parametric_CAD/Quote.png" alt="quote">
                                        <a href="javascript:" data-toggle="modal" data-target=".bd-example-modal-sm">Submit your Request for Quote</a>
                                    </div>
                                    <div class="col-sm-12 whatnext-cont">
                                        <img src="assets/images/Scanto_parametric_CAD/system.png" alt="system">
                                        <a href="javascript:" data-toggle="modal" data-target=".related-services-modal-sm">Related services</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Small modal -->
                        <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-sm modal-dialog-centered">
                            <div class="modal-content">
                                <h5 class="mt-4 text-dark text-center">Get Quote</h5>
                                 <?php
                                    if (isset($_SESSION['status'])) {
                                        if ($_SESSION['status'] == "success") {
                                            echo "<div class='row status-div'>
                                                    <p class='status-message'>Thanks for your interest in our 3d scanning cad service. You will receive the call and the quote from our business executives.</p>
                                                    <div style='width: 100%'><a href='https://www.precise3dm.com/reverse-engineering-geomagic-design-x.php'><button class='step-form-btn'>Back</button></a></div></div>";
                                        } else {
                                            echo "<div class='row status-div'>
                                                    <p class='status-message'>Oops...Something went wrong, please try again
                                                </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                                        }
                                        unset($_SESSION['status']);
                                    }else { ?>
                                <form method="POST" action="webinar_submit.php" id="web_form" autocomplete="off">
                                <div class="form-group cad-input-fields">
                                    <input type="text" name="cadName" id="cadName" class="form-control" placeholder="Name*">
                                    <input type="email" name="cadEmail" id="cadEmail" class="form-control" placeholder="Email*">
                                    <input type="text" name="cadContnum" id="cadContnum" class="form-control" placeholder="Contact number*" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                    <input type="text" name="cadLocation" id="cadLocation" placeholder="Location" class="form-control">
                                    <input type="text" name="cadCompanyname" id="cadCompanyname" placeholder="Company name" class="form-control">
                                </div>
                                <div class="text-center mb-4">
                                    <button type="submit" class="btn" id="cadsubmit">Submit</button>
                                </div>
                            </form>
                            <?php } ?>
                            </div>
                          </div>
                        </div>
                        <!-- Small modal -->
                        <!-- Related services Small modal -->
                         <div class="modal fade related-services-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-sm modal-dialog-centered">
                            <div class="modal-content" style="padding:25px;">
                            <a class="btn pre-btn my-2" href="https://precise3dm.com/3d-scanning-services-in-india.php" target="_blank">3D scanning Service</a>
                            <a class="btn pre-btn my-2" href="https://precise3dm.com/3d-scanners-in-india.php" target="_blank">3D Scanner</a>
                            <a class="btn pre-btn my-2" href="https://precise3dm.com/3d-software-provider-in-india.php" target="_blank">3D Software</a>
                                     
                            </div>
                          </div>
                        </div>
                        <!-- Small modal -->
                        <!--related blogs-->
                        <div class="mt-5" id="rel_blog">
                            <div class="row">
                                <div class="col-12 mt-4">
                                    <h4 class="">RELATED BLOGS</h4>
                                </div>
                                <div class="col-sm-6 mt-4 blog-cont">
                                    <img src="assets/images/Scanto_parametric_CAD/1 import 3D mesh file.PNG" alt="3d mesh" class="img-fluid">
                                    <h5>Scan To Parametric CAD</h5>
                                    <p>Parametric cad consists of a history-based feature
                                        modeling tree that can be edited to make design
                                    </p>
                                    <a href="#">Read more</a>
                                </div>
                                <div class="col-sm-6 mt-4 blog-cont">
                                    <img src="assets/images/Scanto_parametric_CAD/1 import 3D mesh file.PNG" alt="3d mesh" class="img-fluid">
                                    <h5>Scan To Parametric CAD</h5>
                                    <p>Parametric cad consists of a history-based feature
                                        modeling tree that can be edited to make design
                                    </p>
                                    <a href="#">Read more</a>
                                </div>
                                <div class="col-sm-6 mt-4 blog-cont">
                                    <img src="assets/images/Scanto_parametric_CAD/1 import 3D mesh file.PNG" alt="3d mesh" class="img-fluid">
                                    <h5>Scan To Parametric CAD</h5>
                                    <p>Parametric cad consists of a history-based feature
                                        modeling tree that can be edited to make design
                                    </p>
                                    <a href="#">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Who we are division start -->
    </section>
    <!-- Workflow Section Starts Here -->
    <hr class="separator">
    <?php include('includes/footer.php'); ?>
    <!-- bootstrap links-->
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="assets/js/highlight.js"></script>
    <script src="assets/js/counter.js"></script>
    <script src="assets/js/parametric-cad.js"></script>
</body>

</html>