<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> 3D Printing service in India | 3D printing service near me</title>
    <meta name="description" content="3d printing service in India - Additive manufacturing is the best option for low-volume production in many industries.">
    <meta name="keywords" content="3d printing service provider, additive manufacturing in india, dlp printing service, small batch production ">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow" />
    <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
    <meta name="revisit-after" content="7 days" />
    <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/3D PRINTING SERVICE.png" />
    <meta name="twitter:card" content="Precise3dm" />
    <meta name="twitter:site" content="@precise3d_m" />
    <meta name="twitter:title" content="Precise3dm" />
    <meta name="twitter:description" content="PRECISE3DM Provides all types of 3D inspection & Reverse engineering service done using specific 3D softwares" />
    <meta property="og:type" content="3D printing service " />
    <meta property="og:title" content="3D printing service in India " />
    <meta property="og:url" content="https://www.precise3dm.com/3d-printing-service-in-india.php/" />
    <meta property="og:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/3D PRINTING SERVICE.png" />
    <meta property="og:description" content="3D printing service in India - Additive manufacturing is the best option for low-volume production in many industries" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/optical-blue-light.css">
    <link rel="stylesheet" href="assets/css/.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/print3dnew.css">
    <script src="assets/js/jquery-3.6.0.min.js"></script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-96527116-1"></script>
    <script>
<style>
    
</style>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-96527116-1');
</script>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '2980089008869976');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=2980089008869976&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<script type="text/javascript">
_linkedin_partner_id = "2283548";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(){var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
s.parentNode.insertBefore(b, s);})();
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "Is 3D printing as strong as injection molding?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We Precise3DM equipped with four Figure 4 offers some materials that are as strong as injection molded parts. Some of these materials provide tensile strength as high as 80 Mpa after proper post-processing."
    }
  },{
    "@type": "Question",
    "name": "How can I avail 3D printing services in India?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We at Precise3Dm provide 3d printing services all over India. To use the services, you can contact us through our website or call any Precise3dm technical representatives."
    }
  },{
    "@type": "Question",
    "name": "What is the part size that you can do 3d printing and low volume production?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "For general 3d printing, we can have a build volume of 300x300x500mm, and for low volume production, the build volume is 124.8 x 70.2 x 346 mm."
    }
  },{
    "@type": "Question",
    "name": "What technology do you use for 3d printing and low volume production?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We use DLP (Digital Light Projection) technology for low volume production. It has high print speeds that make it possible to print multiple parts in a realistic time frame"
    }
  },{
    "@type": "Question",
    "name": "How long do you take to 3D Print my part?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Print time depends on the size and complexity of the part. To get an exact estimate of the time required to print your file, we would need a .stl file. You can directly upload your file on our website and get an estimate for time and cost as well."
    }
  },{
    "@type": "Question",
    "name": "My part is rubber. Do you print rubber-like material?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes!! We print rubber as well as many other production materials like bio-compatible materials and flexible materials. Our materials can effectively match the properties of some of the most used materials in production."
    }
  },{
    "@type": "Question",
    "name": "Per day how many parts can you print?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We use DLP (Digital Light Projection) technology for low volume production. It has high print speeds that make it possible to print multiple parts in a realistic time frame"
    }
  },{
    "@type": "Question",
    "name": "How do you increase the strength of a 3D-printed part?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "The strength of 3D printed parts can be increased by utilizing some post-processing measures like curing, for which we have special equipment. After curing, the properties of the material changes to some extent giving more strength to the materials"
    }
  }]
}
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>
</head>
<style>
    .top-height-adjust {
        height:50px;
    }
</style>

<body>
    <!-- header start -->
    <?php include('includes/header.php'); ?>
    <!-- header end -->

    <div class="container-fluid cover-container">
        <div class="col-md-12 ">
            <div class="container">
                <div class="col-md-12 mt-5"style="position:relative;top:30px;">
                    <h1 style="text-transform: capitalize;font-weight: bold; color: white;">
                        3D printing Service
                    </h1>
                </div>
                <div class="col-md-12 mt-5">
                    <h2 style="text-transform: capitalize;font-weight: bold;color: white;">
                        Pan India Supply Delivery Of Small Batch Production Part

                    </h2>
                </div>
                <div class="col-md-12" style="color: #f69322;">
                    <h4>We Make Cost Effective
                    </h4>
                    <h4>Low Volume Production 3D Printing At Your Doorstep
                    </h4>
                </div>
                <div class="col-md-12 ">
                    <div class="row">
                        <div class="col-md-3 mt-3">
                            <div class="btn btn-info btn-lg" style="background-color: #FE8D1D;">
                                <a href="3d-printing-service-form.php" style="color:white">Get Quote</a>
                                
                            </div>
                        </div>
                        <div class="col-md-4 explobut mt-3">
                        <div class="btn btn-info btn-lg" style="background-color: #FE8D1D;">
                                <a href="#mater" style="color:white">Explore Our Material</a>
                            </div>
                        </div>
                        <div class="col-md-4"></div>
        
                    </div>
                </div>
                <div class="col-md-12 mt-5"style="padding-bottom:20px;">
                    <div class="row">
                        <div class="col-md-2 topsec mt-3">
                            <h2 style="text-align: center;font-weight:bold;color:white; margin-top:10px;">+15</h2>
                            <p style="color: white; " >Unique engineering & Bio compatible materials
    
                            </p>
    
                        </div>
                        <div class="col-md-2 topsec mt-3">
                            <h2 style="text-align: center;font-weight:bold;color:white;margin-top:10px;">10 </h2>
                            <p style="color: white; " > industries Served
    
                            </p>
    
                        </div>
                        <div class="col-md-2 topsec mt-3">
                            <h2 style="text-align: center;font-weight:bold;color:white;margin-top:10px;">5 to 5000</h2>
                            <p style="color: white; " >Parts can be produced per day
    
                            </p>
    
                        </div>
                    </div>
                    
                </div>
            </div>

            
        </div>
        
    </div>
    <div class="container-fluid topsecsticky"   >
            <div class="row " >
                <div class="col-md-1 mt-2 mb-2 "></div>
                <div class="col-md-1 mt-2 mb-2 stickposition">
                    <a href="#overview" class="text-uppercase" style="color: #FE8D1D;">OVERVIEW</a>
                    </div>
                    <div class="col-md-1 mt-2 mb-2 stickposition1">
                        <a href="#feature" class="text-uppercase" style="color: #FE8D1D;"> FEATURES</a>
                        </div>
                        <div class="col-md-1 mt-2 mb-2 stickposition2">
                            <a href="#material" class="text-uppercase" style="color: #FE8D1D;">Materials</a>
                            </div>
                            <div class="col-md-2 mt-2 mb-2 stickposition3">
                                <a href="#How" class="text-uppercase" style="color: #FE8D1D;">How It Works</a>
                                </div>
                                <div class="col-md-2 mt-2 mb-2 stickposition4">
                                    <a href="#Imagegallery" class="text-uppercase" style="color: #FE8D1D;">Image gallery </a>
                                    </div>
                                    <div class="col-md-2 mt-2 mb-2 stickposition5">
                                        <a href="#Videogallery" class="text-uppercase" style="color: #FE8D1D;">Video gallery</a>
                                        </div>
                                        <div class="col-md-1 mt-2 mb-2 stickposition6">
                                            <a href="#Casestudy" class="" style="color: #FE8D1D;">case study</a>
                                            </div>
                                            <div class="col-md-1 mt-2 mb-2 stickposition7">
                                                <a href="#faq" class="text-uppercase" style="color: #FE8D1D;">faq</a>
                                                </div>
            </div>        
            

            
            

 </div>


 <div class="container-fluid overcolor" >
    <div class="row">
        <div class="col-md-2"></div>
     
        <div class="col-md-10 mt-5"id="overview">
            <h3 class="content-heading">
               OVERVIEW
            </h3>
        </div>
        <div class="col-md-2"></div>
        <div class="col-md-5 mt-3 ">
            <p class="justify-para">
                Our PRECISE3DM Digital manufacturing service transforms the Indian manufacturing industry to produce low-volume end-use plastic parts without making any tool or mold using 3D printing technology. Complex function parts are 3D Printed directly from CAD design with fine geometries and complex features at a significantly lower cost. Our process also significantly reduces the lead time for production from months to days or hours in a short timeframe. Unlike traditional manufacturing methods, which need dedicated tooling and molds, The 3D printed parts made are superior in strength, finish, smoothness, weight, repeatability, accuracy, and execution over manually fabricated components.
            </p>
        </div>
        <div class="col-md-5 ">
            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/overview.webp" alt="" class="img-fluid">
        </div>
        <div class="col-md-2"></div>
     
        <div class="col-md-10 "id="feature">
            <h3 class="content-heading">
                KEY FEATURES
            </h3>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/keyFeatures/keyFeature1.webp" alt="tough-plastic-3d-printing-service" class="img-fluid">
                            <div style="background-color: #FE8D1D ;" class="heikey">
                                <p class="printinc">Our DM service is Ultra-Fast & Affordable, with same-day prototyping and low volume production without making any tool.</p>
                            </div>
    
                            

                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/keyFeatures/keyfeatureprint.png" width="100%" alt="rubber-valve-3d-printing-service" class="img-fluid">
                            <div style="background-color: #FE8D1D ; " class="heikey">
                                <p class="printinc">An alternative to traditional injection molding that enables designs to go straight from CAD to manufacturing without tooling or delay</p>
                            </div>
    
                            

                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/keyFeatures/keyfeature3.webp" alt="Biocompatible-plastic-3d-printing-service-in india" class="img-fluid">
                            <div style="background-color: #FE8D1D ;" class="heikey">
                                <p class="printinc">We use 3Dsdsystems resin materials that are production and indirect production- grade and certified bio compatible and rapid prototyping materials.</p>
                            </div>
    
                            

                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-3"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/keyFeatures/keyfeature4.webp" alt="pan-india-3d-printing-service" class="img-fluid">
                            <div style="background-color: #FE8D1D ;" class="heikey">
                                <p class="printinc">The 3D printer is installed at technology partner locations in more than five places to cater to low volume production 3D printing service to pan India customers.</p>
                            </div>
    
                            

                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/keyFeatures/keyfeature5.webp" alt="dlp-3d-printing-service-in india" class="img-fluid">
                            <div style="background-color: #FE8D1D ;" class="heikey">
                                <p class="printinc">Traditional design restrictions do not apply anymore. Design complexity does not come at an additional cost during the production process with additive manufacturing techniques.</p>
                            </div>
    
                            

                        </div>
                        
                    </div>
                    
                       
                </div>

            </div>
            
        </div>
        
        












    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5"id="material" >
            <h3 class="content-heading">
                MATERIALS            </h3>
        </div>
        <div class="col-md-2"></div>
        <div class="col-md-9 mt-3">
            <p class="justify-para">
                We use only 3dsystems resin to 3D print parts that are segmented into production-grade, indirect Production, and prototype materials. We use Direct production materials to produce long-term end-use parts like typical thermoplastic and rubber, with six sigma certifications. We have industry-best Indirect production castable materials that are unique and appropriate for master prototype wax patterns from which we produce direct end parts. Our prototype materials offer versatile properties required in functional testing, fitments, and other prototyping applications.            </p>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5" id="mater" >
            <h3 class="content-heading">
                MATERIAL GENERAL KEY FEATURES            </h3>
        </div>
        <!--section-1-->
        <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material1.webp" alt="direct-production-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeatur">
                            Direct Production Grade
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material2.webp" alt="Bio-Compatible-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeatur">
                            <div class="materialcont">
                                Bio Compatibility

                           
                            </div>
                             
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material3.webp" alt="excellence-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeature">
                            Excellent Flammability Resistance
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>



                



            </div>
            <!--section-2-->
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material4.webp" alt="print-quality-3d-printing-service-in-india" width="100%" height="230px" >
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeatur">
                            Excellent Print Quality
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material5.webp" alt="environmental-stability-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeature">
                            Long Term Environmental Stability
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material6.webp" alt="indoor-outdoor-stability-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeature">
                            Eight Years Indoor One Year Outdoor Stability
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>



                



            </div>
            <!--section3-->
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material7.webp" alt="thermoplastic-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeature">
                            Thermoplastic Behaviours For SnapFit
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material8.webp" alt=" withstand-uv-and-humidity-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeatur">
                            Withstand UV And Humidity
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material9.webp" alt="rigid-high-strength-3d-printing-service-in-india" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeatur">
                            Rigid High Strength Plastic
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>



                



            </div>
                        <!--section4-->

            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/Materials/material10.webp" alt="thermoplastic" width="100%">
                            
    
                            

                        </div>
                        <div class="col-md-8 materialfeatur">
                            <div class="materialconte">
                                Thermoplastic Nature

                           
                            </div>
                            
                        </div>
                        
                    </div>
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    
                    
                       
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-3" >
                    
                    
                       
                </div>
                <div class="col-md-1"></div>



                



            </div>


        </div>







    

    </div>


    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5" id="How">
            <h3 class="content-heading">
                HOW IT WORKS
             </h3>

        </div>
        <div class="col-md-2"></div>
        <div class="col-md-8 mt-5">
            <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/howitworks/howitworks.webp" alt="3d printing service in india-howItWorks" class="img-fluid">

        </div>
        
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5 "id="Imagegallery">
            <h3 class="content-heading">
                IMAGE GALLERY
             </h3>

        </div>
        <div class="col-md-2"></div>
        <div class=" col-md-8 mt-5">
        <div class="owl-carousel owl-theme">
                 <div class="item">
                        <img src="assets/images/3DprintingServicesNewpage/3DprintingServices/image gallery/Mask-Group-65.webp" alt="3d printing service in india-ear buds" class="printing">
                        
                        <p class='text-center mb-3' style="color: white">Ear buds</p>

                    </div>
<div class="item">
<img src="assets/images/3DprintingServicesNewpage/3DprintingServices/image gallery/Mask-Group-64.webp"  alt="3d-printing-service-in-india-nut bolt" class="img-fluid">
                                    
                                    <p class='text-center' style="color: white">Nut bolt</p>
                    </div>

<div class="item">
<img src="assets/images/3DprintingServicesNewpage/3DprintingServices/image gallery/Mask-Group-60.webp"  alt="3d-printing-service-in-india-jewellery" class="img-fluid">
                                    
                                    <p class='text-center' style="color: white">Jewellery</p>
                    </div>

<div class="item">
<img src="assets/images/3DprintingServicesNewpage/3DprintingServices/image gallery/engineeringPart.webp" alt="3d-printing-service-in-india-engineeringPart" class="img-fluid">
                                    
                                    <p class='text-center mb-3' style="color: white">EngineeringPart</p>
                    </div>

                    
                </div>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5" id="Videogallery">
            <h3 class="content-heading">
                VIDEO GALLERY
             </h3>
        </div>
        <div class="col-md-2"></div>
        <div class="col-md-6 mt-5 main-demo-video" >
            <iframe width="100%" height="345" src="https://www.youtube.com/embed/4G4U8avvib4" allow="autoplay" >
            </iframe>
        </div>
        <div class="col-md-3 mt-5">
            <iframe width="100%" height="200px" src="https://www.youtube.com/embed/C-HiX2o5cEA" allow="autoplay" >
            </iframe>

            

        </div>
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5" id="Casestudy">
            <h3 class="content-heading">
                CASE STUDY
             </h3>

        </div>
        <style>
                .owl-nav button{
                     height:40px;
                     width:40px;
                     border-radius:30px !important;
                 }
                 @media only screen and (min-width: 712px) {
                    .owl-theme .owl-nav [class*=owl-] {
                     margin-left:-26px;
                     margin-right:-26px;
                 }


                 }

                 #owlblog .owl-nav button{
                     background-color:#ff8d1e !important;
                 }
             </style>

        <div class="col-md-2"></div>
        <div class="col-md-8 mt-5">
                <div class="owl-carousel owl-theme" id="owlblog" >
                 <div class="item">
                        <img src="assets/images/solutionix c500/slidepicnew/Mask Group 69.png" style="filter: grayscale(20%);" width="350px" height="250px"alt="3d printing service in india-ear buds" class="printing">
                        <h5 style="color:#FE8700; margin-top:5px;">3D Inspection of Large Parts using Handheld Metrology 3D Scanning</h5>
                        <div class=" text-center mt-3">
                        <a class=' mb-3' style="color: white"><i class="far fa-clock" style="position:relative;left: -4px;"></i>July 20, 2021  </a> <a class= "text-white" style="padding-left:20px;"><i class="fas fa-bars" style="position:relative;left: -4px;"></i>3D Inspections</a>

                        </div>
                        <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="" target="_blank">READ MORE</a>
                        </div>


                    </div>
                    <div class="item">
                        <img src="assets/images/solutionix c500/slidepicnew/Mask Group 69.png" style="filter: grayscale(20%);" width="350px" height="250px"alt="3d printing service in india-ear buds" class="printing">
                        <h5 style="color:#FE8700; margin-top:5px;">3D Inspection of Large Parts using Handheld Metrology 3D Scanning</h5>
                        <div class=" text-center mt-3">
                        <a class=' mb-3' style="color: white"><i class="far fa-clock" style="position:relative;left: -4px;"></i>July 20, 2021  </a> <a class= "text-white" style="padding-left:20px;"><i class="fas fa-bars" style="position:relative;left: -4px;"></i>3D Inspections</a>

                        </div>
                        <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="" target="_blank">READ MORE</a>
                        </div>


                    </div>
                    <div class="item">
                        <img src="assets/images/solutionix c500/slidepicnew/Mask Group 69.png" style="filter: grayscale(20%);" width="350px" height="250px"alt="3d printing service in india-ear buds" class="printing">
                        <h5 style="color:#FE8700; margin-top:5px;">3D Inspection of Large Parts using Handheld Metrology 3D Scanning</h5>
                        <div class=" text-center mt-3">
                        <a class=' mb-3' style="color: white"><i class="far fa-clock" style="position:relative;left: -4px;"></i>July 20, 2021  </a> <a class= "text-white" style="padding-left:20px;"><i class="fas fa-bars" style="position:relative;left: -4px;"></i>3D Inspections</a>

                        </div>
                        <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="" target="_blank">READ MORE</a>
                        </div>


                    </div>

                    <div class="item">
                        <img src="assets/images/solutionix c500/slidepicnew/Mask Group 69.png" style="filter: grayscale(20%);" width="350px" height="250px"alt="3d printing service in india-ear buds" class="printing">
                        <h5 style="color:#FE8700; margin-top:5px;">3D Inspection of Large Parts using Handheld Metrology 3D Scanning</h5>
                        <div class=" text-center mt-3">
                        <a class=' mb-3' style="color: white"><i class="far fa-clock" style="position:relative;left: -4px;"></i>July 20, 2021  </a> <a class= "text-white" style="padding-left:20px;"><i class="fas fa-bars" style="position:relative;left: -4px;"></i>3D Inspections</a>

                        </div>
                        <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="" target="_blank">READ MORE</a>
                        </div>


                    </div>
                    
                </div>
        </div>
                
    </div>
    <!--<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5">
            <h3 class="content-heading">
                CASE STUDY
             </h3>

        </div>
        <div class="col-md-2"></div>
        <div class="col-md-8 mt-5">
            <img src="printimages/caseStudy.PNG" class="img-fluid">

        </div>
        
    </div>-->
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5"id=faq>
            <h3 class="content-heading">
                FAQs

             </h3>

        </div>
        <div class="col-md-2"></div>
        <div class="col-md-10 mt-5">
            <div class="col-md-11 text-left px-lg-0 faqsectionforscroll " >
                <section id="backfs" class="backfs ">
    
    
                        
                        
                      <h5 class="pre-colorfs " style="color: #ff931e;">Is 3D printing as strong as injection molding?
                    </h5>
                      <div class="left-border">
                        <p class="text-white " >We Precise3DM equipped with four Figure 4 offers some materials that are as strong as injection molded parts. Some of these materials provide tensile strength as high as 80 Mpa after proper post processing.

                        </p>
                      </div>
                      <h5 class="pre-colorfs " style="color: #ff931e;">How can I avail 3D printing services in India?
                    </h5>
                        <div class="left-border">
                            <p class="text-white " >We at Precise3Dm provide 3d printing services all over India. To use the services, you can contact us through our website or call any Precise3dm technical representatives.

                            </p>
                        </div>
                        
                        <h5 class="pre-colorfs " style="color: #ff931e;">What is the part size that you can do 3d printing and low volume production?
                        </h5>
                        <div class="left-border">
                            <p class="text-white " >For general 3d printing, we can have a build volume of 300x300x500mm, and for low volume production, the build volume is 124.8 x 70.2 x 346 mm.

                            </p>
                        </div>
                        <h5 class="pre-colorfs " style="color: #ff931e;">What technology do you use for 3d printing and low volume production?
                        </h5>
                        <div class="left-border">
                            <p class="text-white " >We use DLP (Digital Light Projection) technology for low volume production. It has high print speeds that make it possible to print multiple parts in a realistic time frame

                            </p>
                        </div>
                        <h5 class="pre-colorfs " style="color: #ff931e;">How long do you take to 3D Print my part?
                        </h5>
                        <div class="left-border">
                            <p class="text-white " >Print time depends on the size and complexity of the part. To get an exact estimate of the time required to print your file, we would need a .stl file. You can directly upload your file on our website and get an estimate for time and cost as well.

                            </p>
                        </div>
                        <h5 class="pre-colorfs " style="color: #ff931e;">My part is rubber. Do you print rubber-like material?
                        </h5>
                        <div class="left-border">
                            <p class="text-white " >Yes!! We print rubber as well as many other production materials like bio-compatible materials and flexible materials. Our materials can effectively match the properties of some of the most used materials in production.

                            </p>
                        </div>
    
                        <h5 class="pre-colorfs " style="color: #ff931e;">Per day how many parts can you print?
                        </h5>
                        <div class="left-border">
                            <p class="text-white " >We use DLP (Digital Light Projection) technology for low volume production. It has high print speeds that make it possible to print multiple parts in a realistic time frame

                            </p>
                        </div>
                        <h5 class="pre-colorfs " style="color: #ff931e;">How do you increase the strength of a 3D-printed part?
                        </h5>
                        <div class="left-border">
                            <p class="text-white " >The strength of 3D printed parts can be increased by utilizing some post-processing measures like curing, for which we have special equipment. After curing, the properties of the material changes to some extent giving more strength to the materials

                            </p>
                        </div>
                        
    
    
    
               </section>
    
                    </div>
            
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12 mt-5"></div>
    </div>
    
     
     
 </div>
 <hr class="separator">
 <?php include('includes/footer.php'); ?>

    <!-- bootstrap links-->
    <!-- <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/slim.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="assets/js/tabs.js"></script> -->
    <!-- bootstrap links-->
    <script src="assets/js/counter.js"></script>


</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"-->
<!--    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"-->
<!--    crossorigin="anonymous"></script>-->
<!--<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"-->
<!--    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"-->
<!--    crossorigin="anonymous"></script>-->
    <script src="assets/js/owl.carousel.min.js"></script>
   <!-- <script src="assets/js/app.js"></script>
    <script src="assets/js/highlight.js"></script>-->
    <script src="assets/js/counter.js"></script>
    <script>
    
    $(document).ready(function() {
    var owl = $('.owl-carousel');
    owl.owlCarousel({
        loop: true,
        nav: true,
        autoplay: false,
        autoplayTimeout: 3000,
        margin: 30,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            960: {
                items: 3
            },
            1200: {
                items: 3
            }
        }
    });
})
</script>
</html>
