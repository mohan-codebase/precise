<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="3D SCANNING SERVICE">
      <!--bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <link rel="stylesheet" href="assets/css/scanning-service.css">
      <link rel="stylesheet" href="assets/css/styles.css">
	  <meta charset="UTF-8">
      <meta name="apple-mobile-web-app-title" content="CodePen">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
      <title>Filter_Page</title>
<style>
h1 {
  text-align: center;
  margin-bottom: 0;
  font-size:18px;
}
.container {
  display: grid;
  font-size:12px;
}
aside {
  padding: 0 1em;
  margin-top: 39px;
  margin-left:20px;
  font-size:12px;
  width: 254px;
}
aside div {
  margin: .25em 0;
}
input {
  margin-right: 5px;
}
main {
  display: grid;
  grid-column-gap:0px;
  margin-bottom: 5em;
}
.player {
  margin: 2em 0;
}
.player h3 {
  margin-bottom:0px;
  text-align:center;
  font-size:18px;
 
}
p {
  margin: 0;
  text-align:center;
  font-size: 13px !important;
    
}
</style>
<style>
@import url(https://fonts.googleapis.com/css?family=Open+Sans);

* { box-sizing: border-box; }

body { 
  font-family: 'Open Sans', sans-serif;
  color:white;
  background-color:#002f3f;
}

/* STRUCTURE */

.wrapper {
	padding: 5px;
	width: 95%;
	margin: 20px auto;
	margin-left: 170px;
    margin-top:-400px;
}
header {
	padding: 0 15px;
}

.columns {
	display: flex;
	flex-flow: row wrap;
	justify-content: center;
	margin: 5px 0;
}

.column {
	flex: 1;
	margin: 2px;
	padding: 10px;
	&:first-child { margin-left: 0; }
	&:last-child { margin-right: 0; }
	
}

@media screen and (max-width: 980px) {
  .columns .column {
		margin-bottom: 5px;
    flex-basis: 40%;
		&:nth-last-child(2) {
			margin-right: 0;
		}
		&:last-child {
			flex-basis: 100%;
			margin: 0;
		}
	}
}

@media screen and (max-width: 680px) {
	.columns .column {
		flex-basis: 50%;
		margin: 0 0 5px 0;
	}
}
.button {
  font-family: Verdana, Arial, Helvetica, sans-serif; 
  font-size: 12px; 
  font-weight: bold; 
  background-color:#ff8d1e;
  color:white;
  border:7px;
  margin-left:100px;
  text-align:center;
  width:100px;
  height:25px;
}
</style>

  <script>
  window.console = window.console || function(t) {};
</script>

  
  
  <script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>


</head>
 <style>

.hero-image {
  background-image: url("assets/images/image1/Figure_Banner.jpg");
  background-color: #cccccc;
  height:600px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  position: relative;
  left:40%;
  top: 298px;
  margin-left: 134px;
  transform: translate(-50%, -50%);
  color: white;
}

.img-fluid {
    height:300px;
    width: 261px;
}

</style>
   <body>
	   <section>
      <div class="hero-image">
		<div class="hero-text">
			<div class="row">
			<div class="col-md-5">
                  <div class="logo-image">
                     <img src="assets/images/image1/figure1.png" class="img-fluid">
                  </div>
				  <br>
				  <h4 class="text-left" style="font-color:white;">FIGURE 4 STANDALONE</h4>
                  <P class="text-left">ULTRA-FAST AND AFFORDABLE FOR SAME DAY PROTOTYPING AND
				LOW-VOLUME PRODUCTION</P>
               </div>
			   <br>
			   <div class="col-md-7">
                  <h4 class="text-left" style="font-color:white;">OVER VIEW</h4>
                  <P class="text-left">Affordable and versatile for low-volume production and fast prototyping,
					offering quality and accuracy with industrial-grade durability, service and
					support.</P>
					 <div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">KEY FEATURES</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">SPECIFICATIONS</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">APPLICATIONS</a></div>
					 <div class="" style="padding-top:10px;">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">INDUSTRY</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">SUPPORTED MATERIALS</a></div>
					 <div class="" style="padding-top:10px;">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">3D PRINTING SERVICES</a>
                  </div>
               </div>
            </div>
		 </div>
			</div>
</section>
<hr class="separator">
  
   <a href="#" class="btn pre-btn my-2 text-uppercase">BOOK A DEMO</a>
   <a href="#" class="btn pre-btn my-2 text-uppercase">GET A QUOTE</a>
  <aside>
	 <h6>MATERIALS FOR THIS PRINTER</h6>
	 <br>
    <div>
	  <div><input type="checkbox" name="nbaTeam" value="bos1" id="bos1">	
      <label for="bos1">Plastic</label>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;16</div>
      <div><input type="checkbox" name="nbaTeam" value="bos" id="bos"><label for="bos">Biocompatible Capable</label>&emsp;&emsp;06</div>
      <div><input type="checkbox" name="nbaTeam" value="cle" id="cle"><label for="cle">General Purpose</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;04</div>
      <div><input type="checkbox" name="nbaTeam" value="cha" id="cha"><label for="cha">High Temperature</label>&emsp;&emsp;&emsp;&emsp;&ensp;04</div>
      <div><input type="checkbox" name="nbaTeam" value="det" id="det"><label for="det">Elastomer/Rubber-Like</label>&emsp;&emsp;03</div>
      <div><input type="checkbox" name="nbaTeam" value="gsw" id="gsw"><label for="gsw">Tough_ABS_Like</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp; 03</div>
      <div><input type="checkbox" name="nbaTeam" value="hou" id="hou"><label for="hou">Castable Plastics</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;02</div>
      <div><input type="checkbox" name="nbaTeam" value="ind" id="ind"><label for="ind">Durable-Polypropylene-like</label>
	  <label for="ind">02</label></div>
      <div><input type="checkbox" name="nbaTeam" value="mia" id="mia"><label for="mia">JewelryCasting</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;02</div>
     <div><input type="checkbox" name="nbaTeam" value="mil" id="mil"><label for="mil">Rigid–Polycarbonate-like,</label>
	  <label for="mil">Urethane-like</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&nbsp;02</div>
      <div><input type="checkbox" name="nbaTeam" value="min" id="min"><label for="min">Master Pattern</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;02</div>
      <div><input type="checkbox" name="nbaTeam" value="nop" id="nop"><label for="nop">Transparent/Translucent</label>&emsp;&nbsp;02</div>
    </div>
  </aside>

  <div class="container">
  <main>
  
  <div class="wrapper">
	<header>
		<h1>PLASTIC</h1>
	</header>
	<br>
<section class="columns">
	
	<div class="column">
	<section>
      <div class="player bos mil bos1 injured starting lebron">
        <img src="assets/images/image2/image-1.png" style="width:300px;background-color:white;">
		<br>
		<br>
        <h3>Figure 4 Rigid White</h3>
        <p>Opaque rigid white</p>
		<p>production- grade plastic</p>
		<br>
		<a href="figure4-rigid-white.php">
		 <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
       
      </div>
      <div class="player guard bos bos1 det starting lebron">
        <img src="assets/images/image2/image-4.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 RUBBER-BLK 10</h3>
        <p>Durable, hard</p>
		<p>rubber-like material</p>
		<br>
		<a href="rubberblk10.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player guard hou nop bos1 reserves lebron">
        <img src="assets/images/image2/image-7.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 EGGSHELL-AMB 10</h3>
        <p>Process-optimized material for</p>
		<p>sacrificial tooling to cast silicone</p>
		<br>
		<a href="eggshell.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player forward bos cha bos1 reserves lebron">
        <img src="assets/images/image2/image-10.jpg" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 MED-WHT 10</h3>
        <p>Rigid white material that can be</p>
		<p>sterilized and tested at high</p> 
		<p>temperature</p>
		<br>
		<a href="med1.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      
      <div class="player forward hou mia injured bos1 reserves lebron">
        <img src="assets/images/image2/image-13.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 JCAST-GRN 10</h3>
        <p>Jewelry castable material for</p>
		<p>high-resolution patterns</p>
		<br>
		<a href="jcast.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player guard cle gsw bos1 reserves lebron">
        <img src="assets/images/image2/image-16.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 TOUGH-GRY 10</h3>
        <p>High speed, production</p> 
		<p>rigid dark gray material</p>
		<br>
		<a href="tough_gry_10.php">
       <input type="reset" class="button" name="refresh" value="Learn more">
	   </a>
      </div>
    </section>
	</div>
	
	<div class="column">
	<section>
       <div class="player min cha mia bos1 starting lebron">
        <img src="assets/images/image2/image-2.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 JEWEL MASTER GRY</h3>
        <p>Jewelry master patterns</p>
		<p>and prototypes</p>
		<br>
		<a href="figure4-jewel.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player guard forward ind east bos1 starting lebron">
        <img src="assets/images/image2/image-5.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 FLEX-BLK 20</h3>
        <p>High stability, durable and</p> 
		<p>flexible plastic</p>
		<br>
		<a href="flex-blk-20.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
     <div class="player guard bos mil bos1 reserves lebron">
        <img src="assets/images/image2/image-8.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 PRO-BLK 10</h3>
        <p>Production-grade,rigid material for</p> 
		<p>production parts</p>
		<br>
		<a href="problk.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player forward center cle cha injured bos1 reserves lebron">
        <img src="assets/images/image2/image-11.jpg" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 MED-AMB 10</h3>
        <p>Rigid, translucent material that can be</p> 
		<p>sterilized and tested at high</p> 
		<p>temperature</p>
		<br>
		<a href="med.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player guard det east bos1 reserves lebron">
        <img src="assets/images/image2/image-14.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 ELAST-BLK 10</h3>
        <p>Rubber-like, design</p> 
		<p>elastomeric material</p>
		<br>
		<a href="elast.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
    </section>
	</div>
  
  <div class="column">
	<section>
        <div class="player forward bos det bos1 starting lebron">
        <img src="assets/images/image2/image-3.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 RUBBER-65A BLK</h3>
        <p>Mid tear strength</p>
		<p>tproduction-grade rubber</p>
		<br>
		<a href="rubberblk.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
	  <div class="player forward cha west bos1 reserves lebron">
        <img src="assets/images/image2/image-6.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 HI TEMP 300-AMB</h3>
        <p>High temperature resistant</p>
		<p>translucent plastic with HDT over 300</p>
		<br>
		<a href="hitemp.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
      <div class="player center cle gsw bos1 reserves lebron">
        <img src="assets/images/image2/image-9.jpg" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 TOUGH-BLK 20</h3>
        <p>Strong material with long-term</p> 
		<p>environmental stability</p>
		<br>
		<a href="toughblk.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
	  <div class="player guard cle ind bos1 reserves lebron" >
        <img src="assets/images/image2/image-12.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 FLEX-BLK 10</h3>
        <p>Durable, hard</p>
		<p>rubber-like material</p>
		<br>
		<br>
		<a href="flex-blk-10.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
	  <div class="player guard cle gsw injured bos1 reserves lebron">
        <img src="assets/images/image2/image-15.png" style="width:300px;background-color:white;">
		<br><br>
        <h3>Figure 4 TOUGH-GRY 15</h3>
        <p>Economical, production</p>
		<p>rigid gray material</p>
		<br>
		<a href="tough_gry.php">
        <input type="reset" class="button" name="refresh" value="Learn more">
		</a>
      </div>
     </section>
	</div>
</section>	
</div>
</main>
</div>
<script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-157cd5b220a5c80d4ff8e0e70ac069bffd87a61252088146915e8726e5d9f147.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.min.js'></script>
      <script id="rendered-js" >
// not exactly vanilla as there is one lodash function

var allCheckboxes = document.querySelectorAll('input[type=checkbox]');
var allPlayers = Array.from(document.querySelectorAll('.player'));
var checked = {};

getChecked('startingReserves');
getChecked('injured');
getChecked('position');
getChecked('nbaTeam');
getChecked('conference');

Array.prototype.forEach.call(allCheckboxes, function (el) {
  el.addEventListener('change', toggleCheckbox);
});

function toggleCheckbox(e) {
  getChecked(e.target.name);
  setVisibility();
}

function getChecked(name) {
  checked[name] = Array.from(document.querySelectorAll('input[name=' + name + ']:checked')).map(function (el) {
    return el.value;
  });
}

function setVisibility() {
  allPlayers.map(function (el) {
    var startingReserves = checked.startingReserves.length ? _.intersection(Array.from(el.classList), checked.startingReserves).length : true;
    var injured = checked.injured.length ? _.intersection(Array.from(el.classList), checked.injured).length : true;
    var position = checked.position.length ? _.intersection(Array.from(el.classList), checked.position).length : true;
    var nbaTeam = checked.nbaTeam.length ? _.intersection(Array.from(el.classList), checked.nbaTeam).length : true;
    var conference = checked.conference.length ? _.intersection(Array.from(el.classList), checked.conference).length : true;
    if (startingReserves && injured && position && nbaTeam && conference) {
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  });
}
//# sourceURL=pen.js
    </script>
        <hr class="separator">
      <!-- footer start -->
      <!-- footer end -->
      
   </body>
</html>