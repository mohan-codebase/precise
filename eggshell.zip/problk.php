<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="3D SCANNING SERVICE">
      <!--bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <link rel="stylesheet" href="assets/css/scanning-service.css">
      <link rel="stylesheet" href="assets/css/styles.css">
      <title>Figure-4-Landing-Page</title>
   </head>
 <style>

.hero-image {
  background-image: url("assets/images/image1/Figure_Banner.jpg");
  background-color: #cccccc;
  height:600px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
  top: -60px;
}

.hero-text {
  position: relative;
  left:40%;
  top: 298px;
  margin-left:100px;
  transform: translate(-50%, -50%);
  color: white;
}

.img-fluid {
  
	text-align:center;
}

</style>
<style>
.wrapper {
	padding: 5px;
	//width: 95%;
	//margin: 20px auto;
	color:white;
	background-color:#002F3F;
	margin-top:-59px;
	
}

.columns {
	display: flex;
	flex-flow: row wrap;
	justify-content: center;
	margin: 5px 0;
	margin-left:30px;
}

.column {
	flex: 1;
	margin: 2px;
	padding: 10px;
	&:first-child { margin-left: 0; }
	&:last-child { margin-right: 0; }
	
}

@media screen and (max-width: 980px) {
  .columns .column {
		margin-bottom: 5px;
    flex-basis: 40%;
		&:nth-last-child(2) {
			margin-right: 0;
		}
		&:last-child {
			flex-basis: 100%;
			margin: 0;
		}
	}
}

@media screen and (max-width: 680px) {
	.columns .column {
		flex-basis: 100%;
		margin: 0 0 5px 0;
	}
}
</style>
<style>
.first-column {
    color: white;
    font-size:15px;
    align-items: center;
	position: relative;
     right:30px;

}
.second-column {
 font-size:15px;
}
</style>
   <body>
      <!-- header start -->
      <?php include('includes/header.php');?>
	  <br><br>
	  <br>
      <!-- header end -->
	   <section>
      <div class="hero-image">
		<div class="hero-text">
			<div class="row">
			<div class="col-md-5">
                  <div class="logo-image">
                     <img align="center"src="assets/images/image2/image-8.png" class="img-fluid">
                  </div>
				  <br>
				  <h4 class="text-left" style="font-color:white;
           text-align: center !important;">FIGURE 4 PRO-BLK 10</h4>
               </div>
			   <br>
			   <div class="col-md-7">
                  <h4 class="text-left" style="font-color:white;">OVER VIEW</h4>
                  <P class="text-left">Production-grade additive manufacturing material with game-changing
					thermoplastic-like mechanical properties and long-term environmental
					stability.</P>
					 <div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">WHY FIGURE 4 ?</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">KEY FEATURES</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">SPECIFICATIONS</a></div>
					 <div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">APPLICATIONS</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">INDUSTRY</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">SUPPORTED MATERIALS</a>
                  </div>
               </div>
            </div>
		 </div>
			</div>

</section>

		   <div class="wrapper">

	<header>
		<a href="#" class="btn pre-btn my-2 text-uppercase">BOOK A DEMO</a>
                <a href="#" class="btn pre-btn my-2 text-uppercase">GET A QUOTE</a>
	</header>
		
		   <section class="columns">
	
	<div class="column">
		 <h5 class="text-left pb-3">APPLICATIONS</h5>
			<P class="text-left" style="font-size:15px;">. Tool-less, same day production</P>
			<p class="text-left" style="font-size:15px;">. CDirect production of small black plastic parts;
			examples include: motor housings, connectors,
			snap-fits, automotive interior and other
			general-use parts</p>
			<p class="text-left" style="font-size:15px;">. Digital production to replace injection
			molding or soft tooling processes</p>
			</div>
	<div class="column">
		<h5 class="text-left pb-3">BENEFITS</h5>
                  <P class="text-left" style="font-size:15px;">. Improved environmental stability of
					mechanical and performance properties over
					time</P>
				<P class="text-left" style="font-size:15px;">. Fast throughput for part-in-hand with no
					secondary thermal cure required</P>
                  <p class="text-left" style="font-size:15px;">. Simple, single solvent cleaning</p>
                  <p class="text-left" style="font-size:15px;">. Excellent surface quality and repeatability</p>
				  <p class="text-left" style="font-size:15px;">. Accurate, low distortion material for fast first</p>
	</div>
  <div class="column">
		<h5 class="text-left pb-3">FEATURES</h5>
                  <P class="text-left" style="font-size:15px;">. Fast print speed up to 62 mm/hr at 50 micron
					layer thickness
					</P>
				  <P class="text-left" style="font-size:15px;">. 70 °C heat deflection temperature, 12% elongation
					at break</P>
                  <p class="text-left" style="font-size:15px;">. 
					Durability and strength</p>
					<P class="text-left" style="font-size:15px;">. UL94 HB flammability</P>
                  <p class="text-left" style="font-size:15px;">. 
					Biocompatible capable per ISO10993-5 and
					ISO10993-10</p>
				<p class="text-left" style="font-size:15px;">. 
									Exhibits thermoplastic behavior in necking at
				tensile break point</p>
	</div>
</section>	
	</div>
     <!--<div class="container">
  <div class="row">
    <div class="col-sm-6 first-column">
	 <h5 class="text-left pb-3">MATERIAL PROPERTIES</h5>
      <p>The full suite of mechanical properties are given per ASTM and ISO
		standards where applicable. All parts are conditioned per ASTM
		recommended standards for a minimum of 40 hours at 23 °C, 50% RH.
		Material properties include physical and mechanical properties, as
		well as thermal, UL flammability, and electrical (dielectric strength,
		dielectric constant, dissipation factor, and volume resistivity).</p>
    </div>
    <div class="col-sm-6 second-column">
	 <h5 class="text-left pb-3">ISOTROPIC PROPERTIES</h5>
      <p>
        Figure 4 technology prints parts that are isotropic in mechanical
		properties meaning the parts printed along either the XYZ axis will
		give similar results. Parts do not need to be oriented to get the
		highest mechanical properties, further improving the degree of
		freedom for part orientation for mechanical properties.
      </p>
    </div> 
  </div>
  <div class="row">
    
  </div>
</div>-->
<br>
<br>
<div class="wrapper">
		   <section class="columns">
	
	<div class="column">
		 <h4 class="text-left pb-3">MATERIAL PROPERTIES</h4>
				  <p style="font-size:15px;">The full suite of mechanical properties are given per ASTM and ISO
						standards where applicable. All parts are conditioned per ASTM
						recommended standards for a minimum of 40 hours at 23 °C, 50% RH.
						Material properties include physical and mechanical properties, as
						well as thermal, UL flammability, and electrical (dielectric strength,
						dielectric constant, dissipation factor, and volume resistivity).</p>
						</div>
	<div class="column">
		 <h4 class="text-left pb-3">ISOTROPIC PROPERTIES</h4>
			  <p style="font-size:15px;">
						Figure 4 technology prints parts that are isotropic in mechanical
						properties meaning the parts printed along either the XYZ axis will
						give similar results. Parts do not need to be oriented to get the
						highest mechanical properties, further improving the degree of
						freedom for part orientation for mechanical properties.
			  </p>
	</div>
</section>	
	</div>
<br>
<br>
	<div class="wrapper">
		   <section class="columns">
	<div class="column">
		 <h4 class="text-left pb-3">TECHNICAL SPECIFICATIONS</h4>
                  <h5 class="text-left pb-3">KEY MECHANICAL PROPERTIES</h5>
				  <P class="text-left" style="font-size:15px;">. Fast print speed up to 62 mm/hr at 50 micron layer thickness</P>
                  <p class="text-left" style="font-size:15px;">. 70 °C heat deflection temperature, 12% elongation at break</p>
				  <p class="text-white" style="font-size:15px;">. UL94 HB flammability</p>
			      <p class="text-white" style="font-size:15px;">. Biocompatible capable per ISO10993-5 and ISO10993-10</p>
				  <p class="text-white" style="font-size:15px;">. Exhibits thermoplastic behavior in necking at tensile break point</p>
				  <p class="text-white" style="font-size:15px;">. Long-term indoor and outdoor environmental stability</p>
	</div>
</section>	
	</div>
      <!-- section end-->
        <hr class="separator">
      <!-- footer start -->
      <?php include('includes/footer.php');?>
      <!-- footer end -->
      
   </body>
</html>