<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="3D SCANNING SERVICE">
      <!--bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <link rel="stylesheet" href="assets/css/scanning-service.css">
      <link rel="stylesheet" href="assets/css/styles.css">
      <title>Figure-4-Landing-Page</title>
   </head>
 <style>

.hero-image {
  background-image: url("assets/images/image1/Figure_Banner.jpg");
  background-color: #cccccc;
  height:600px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
  top: -60px;
}

.hero-text {
  position: relative;
  left:40%;
  top: 298px;
  margin-left:100px;
  transform: translate(-50%, -50%);
  color: white;
}

.img-fluid {
  
	text-align:center;
}

</style>
<style>
.wrapper {
	padding: 5px;
	//width: 95%;
	//margin: 20px auto;
	color:white;
	background-color:#002F3F;
	margin-top:-59px;
	
}

.columns {
	display: flex;
	flex-flow: row wrap;
	justify-content: center;
	margin: 5px 0;
	margin-left:30px;
}

.column {
	flex: 1;
	margin: 2px;
	padding: 10px;
	&:first-child { margin-left: 0; }
	&:last-child { margin-right: 0; }
	
}

@media screen and (max-width: 980px) {
  .columns .column {
		margin-bottom: 5px;
    flex-basis: 40%;
		&:nth-last-child(2) {
			margin-right: 0;
		}
		&:last-child {
			flex-basis: 100%;
			margin: 0;
		}
	}
}

@media screen and (max-width: 680px) {
	.columns .column {
		flex-basis: 100%;
		margin: 0 0 5px 0;
	}
}
</style>
<style>
.first-column {
    color: white;
    font-size:15px;
    align-items: center;
	position: relative;
     right:30px;

}
.second-column {
 font-size:15px;
}
</style>

   <body>
      <!-- header start -->
      <?php include('includes/header.php');?>
	  <br><br>
	  <br>
      <!-- header end -->
	   <section>
      <div class="hero-image">
		<div class="hero-text">
			<div class="row">
			<div class="col-md-5">
                  <div class="logo-image">
                     <img align="center"src="assets/images/image2/image-1.png" class="img-fluid">
                  </div>
				  <br>
	     <h4 class="text-left" style="font-color:white;
    text-align: center !important;
">FIGURE 4 RIGID WHITE</h4>
               </div>
			   <br>
			   <div class="col-md-7">
                  <h4 class="text-left" style="font-color:white;">OVER VIEW</h4>
				<P class="text-left">Opaque rigid white production-grade plastic for same-day parts. This
            biocompatible-capable material provides a smooth surface finish, long-
			term environmental stability, and long-lasting, clean white color.</P>
					<div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">WHY FIGURE 4 ?</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">KEY FEATURES</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">SPECIFICATIONS</a></div>
					 <div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">APPLICATIONS</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">INDUSTRY</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">SUPPORTED MATERIALS</a>
                  </div>
               </div>
            </div>
		 </div>
			</div>

</section>

		   <div class="wrapper">

	<header>
		<a href="#" class="btn pre-btn my-2 text-uppercase">BOOK A DEMO</a>
                <a href="#" class="btn pre-btn my-2 text-uppercase">GET A QUOTE</a>
	</header>
		
		   <section class="columns">
	
	<div class="column">
			<h5 class="text-left pb-3">APPLICATIONS</h5>
			<P class="text-left" style="font-size:15px;">. Handles and fixtures for medical applications
				  that require biocompatibility</P>
			<P class="text-left" style="font-size:15px;">. Electronics enclosures and small components
			or parts for devices</P>
			<p class="text-left" style="font-size:15px;">. Motor housings, covers, guards, snap-fit parts,
			jigs, fixtures, and other functional prototyping
			and low volume production parts</p>
			</div>
			
	<div class="column">
		<h5 class="text-left pb-3">BENEFITS</h5>
                  <P class="text-left" style="font-size:15px;">. Good long-term environmental stability
					measured out to 8 years indoor and 2 years
					outdoor</P>
				  <P class="text-left" style="font-size:15px;">. Clean, long-lasting, opaque white color</P>
                  <p class="text-left" style="font-size:15px;">. Fast throughput to finished part; no secondary
				  ermal cure required</p>
                  <p class="text-left" style="font-size:15px;">. Excellent surface quality, accuracy, and</p>
	</div>
	
  <div class="column">
		<h5 class="text-left pb-3">FEATURES</h5>
                  <P class="text-left" style="font-size:15px;">. Thermoplastic behavior with necking at break</P>
				  <P class="text-left" style="font-size:15px;">. 65°C heat deflection temperature</P>
                  <p class="text-left" style="font-size:15px;">. 20% elongation at break</p>
                  <p class="text-left" style="font-size:15px;">. Flexural modulus of 2200MPa</p>
				  <P class="text-left" style="font-size:15px;">. Biocompatible-capable per ISO10993-5 and
					ISO10993-10</P>
				  <P class="text-left" style="font-size:15px;">. UL94 HB flammability</P>
                  <p class="text-left" style="font-size:15px;">. Fast throughput to finished part; no secondary
				  ermal cure required</p>
                  <p class="text-left" style="font-size:15px;">. Print speeds up to 47 mm/hr at 50-micron layer thickness</p>
	</div>
</section>	
	</div>
	<br>
	<br>
<div class="wrapper">
		   <section class="columns">
	
	<div class="column">
		<h5 class="text-left pb-3">MATERIAL PROPERTIES</h5>
                  <P class="text-left" style="font-size:15px;">The full suite of mechanical properties is given per ASTM and ISO standards where applicable. All parts are conditioned per ASTM recommended standards for a minimum of 40 hours at 23 °C, 50% RH.Material properties include physical and mechanical properties, as well as thermal, UL flammability, and electrical (dielectric strength,
				   dielectric constant, dissipation factor, and volume resistivity)</P>
						</div>
	<div class="column">
		  <h5 class="text-left pb-3">ISOTROPIC PROPERTIES</h5>
                  <P class="text-left" style="font-size:15px;">Figure 4 technology prints parts that are isotropic in mechanical properties meaning the parts printed along either the XYZ axis will give similar results. Parts do not need to be oriented to get the highest mechanical properties, improving the degree of freedom for part orientation for mechanical properties.</P>
			  </p>
	</div>
</section>	
	</div>
	<br>
	<br>
	<div class="wrapper">
		   <section class="columns">
	<div class="column">
		  <h4 class="text-left pb-3">TECHNICAL SPECIFICATIONS</h4>
                  <h5 class="text-left pb-3">KEY PROPERTIES</h5>
                  <P class="text-left" style="font-size:15px;">. Long-term indoor and outdoor environmental (UV and humidity) stability</P>
				  <P class="text-left" style="font-size:15px;">. Thermoplastic behavior with necking at break</P>
                  <p class="text-left" style="font-size:15px;">. 65 °C heat deflection temperature</p>
				  <p class="text-white" style="font-size:15px;">. 20% elongation at break</p>
			     <p class="text-white" style="font-size:15px;">. Flexural modulus of 2200 MPa</p>
			     <p class="text-white" style="font-size:15px;">. Isotropic properties</p>
			    <p class="text-white" style="font-size:15px;">. UL94 HB flammability</p>
				<p class="text-white" style="font-size:15px;">. Biocompatible-capable per ISO10993-5 and ISO10993-10</p>
			    <p class="text-white" style="font-size:15px;">. Print speeds up to 47 mm/hr at 50 micron layer thicknes</p>
	</div>
	
</section>	
	</div>
      <!-- section end-->
        <hr class="separator">
      <!-- footer start -->
      <?php include('includes/footer.php');?>
      <!-- footer end -->
      
   </body>
</html>
