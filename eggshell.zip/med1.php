<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="3D SCANNING SERVICE">
      <!--bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <link rel="stylesheet" href="assets/css/scanning-service.css">
      <link rel="stylesheet" href="assets/css/styles.css">
      <title>Figure-4-Landing-Page</title>
   </head>
 <style>

.hero-image {
  background-image: url("assets/images/image1/Figure_Banner.jpg");
  background-color: #cccccc;
  height:600px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
  top: -60px;
}

.hero-text {
  position: relative;
  left:40%;
  top: 298px;
  margin-left:100px;
  transform: translate(-50%, -50%);
  color: white;
}

.img-fluid {
  
	text-align:center;
}

</style>
<style>
.wrapper {
	padding: 5px;
	//width: 95%;
	//margin: 20px auto;
	color:white;
	background-color:#002F3F;
	margin-top:-59px;
	
}

.columns {
	display: flex;
	flex-flow: row wrap;
	justify-content: center;
	margin: 5px 0;
	margin-left:30px;
}

.column {
	flex: 1;
	margin: 2px;
	padding: 10px;
	&:first-child { margin-left: 0; }
	&:last-child { margin-right: 0; }
	
}

@media screen and (max-width: 980px) {
  .columns .column {
		margin-bottom: 5px;
    flex-basis: 40%;
		&:nth-last-child(2) {
			margin-right: 0;
		}
		&:last-child {
			flex-basis: 100%;
			margin: 0;
		}
	}
}

@media screen and (max-width: 680px) {
	.columns .column {
		flex-basis: 100%;
		margin: 0 0 5px 0;
	}
}
</style>
<style>
.first-column {
    color: white;
    font-size:15px;
    align-items: center;
	position: relative;
     right:30px;

}
.second-column {
 font-size:15px;
}
</style>

   <body>
      <!-- header start -->
      <?php include('includes/header.php');?>
	  <br><br>
	  <br>
      <!-- header end -->
	   <section>
      <div class="hero-image">
		<div class="hero-text">
			<div class="row">
			<div class="col-md-5">
                  <div class="logo-image">
                     <img align="center"src="assets/images/image2/image-10.jpg" class="img-fluid">
                  </div>
				  <br>
				  <h4 class="text-left" style="font-color:white;
           text-align: center !important;">FIGURE 4 MED-WHT 10</h4>
               </div>
			   <br>
			   <div class="col-md-7">
                  <h4 class="text-left" style="font-color:white;">OVER VIEW</h4>
				<P class="text-left">A rigid white material for applications requiring biocompatibility and/or
					thermal resistance. It provides beautiful parts that can be sterilized and
					tested at high temperature, over 100 °C.</P>
					<div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">WHY FIGURE 4 ?</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">KEY FEATURES</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">SPECIFICATIONS</a></div>
					 <div class="">
                     <a href="#" class="btn pre-btn my-2 text-uppercase">APPLICATIONS</a>
					 <a href="#" class="btn pre-btn my-2 text-uppercase">INDUSTRY</a>
                     <a href="#" class="btn pre-btn my-2 text-uppercase">SUPPORTED MATERIALS</a>
                  </div>
               </div>
            </div>
		 </div>
			</div>

</section>

		   <div class="wrapper">

	<header>
		<a href="#" class="btn pre-btn my-2 text-uppercase">BOOK A DEMO</a>
                <a href="#" class="btn pre-btn my-2 text-uppercase">GET A QUOTE</a>
	</header>
		
		   <section class="columns">
	
	<div class="column">
		 <h5 class="text-left pb-3">APPLICATIONS</h5>
			<p class="text-left" style="font-size:15px;">. General medical applications requiring
			biocompatibility, sterilization and/or thermal
			resistance</p>
			<p class="text-left" style="font-size:15px;">. Surgical drill guides, splints
			Bone models</p><br>
			<p class="text-left" style="font-size:15px;">. Parts requiring rigidity with high temperature
			and/or water resistance</p>
            <p class="text-left" style="font-size:15px;">. Parts with high definition details</p>
			</div>
	<div class="column">
		<h5 class="text-left pb-3">BENEFITS</h5>
                  <P class="text-left" style="font-size:15px;">. Capable of meeting ISO 10993-5 and -10
					standards for biocompatibility (cytotoxicity,
					sensitization and irritation)</P>
				<P class="text-left" style="font-size:15px;">. Smooth surfaces for beautiful display models
					and prototypes</P>
                  <p class="text-left" style="font-size:15px;">. High temperature testing</p>
                  <p class="text-left" style="font-size:15px;">. True-to-CAD accuracy and crisp feature detail</p>
	</div>
  <div class="column">
		<h5 class="text-left pb-3">FEATURES</h5>
                  <P class="text-left" style="font-size:15px;">. Biocompatible*</P>
				  <P class="text-left" style="font-size:15px;">. Sterilizable by autoclave</P>
                  <p class="text-left" style="font-size:15px;">. Thermal resistance over 100 °C</p>
				   <P class="text-left" style="font-size:15px;">. Excellent humidity/moisture resistance</P>
				  <P class="text-left" style="font-size:15px;">. Rigid and white</P>
	</div>
</section>	
	</div>
     <!--<div class="container">
  <div class="row">
    <div class="col-sm-6 first-column">
	 <h5 class="text-left pb-3">MATERIAL PROPERTIES</h5>
      <p>The full suite of mechanical properties are given per ASTM and ISO
		standards where applicable. All parts are conditioned per ASTM
		recommended standards for a minimum of 40 hours at 23 °C, 50% RH.
		Material properties include physical and mechanical properties, as
		well as thermal, UL flammability, and electrical (dielectric strength,
		dielectric constant, dissipation factor, and volume resistivity).</p>
    </div>
    <div class="col-sm-6 second-column">
	 <h5 class="text-left pb-3">ISOTROPIC PROPERTIES</h5>
      <p>
        Figure 4 technology prints parts that are isotropic in mechanical
		properties meaning the parts printed along either the XYZ axis will
		give similar results. Parts do not need to be oriented to get the
		highest mechanical properties, further improving the degree of
		freedom for part orientation for mechanical properties.
      </p>
    </div> 
  </div>
  <div class="row">
    
  </div>
</div>-->
<br>
<br>
<div class="wrapper">
		   <section class="columns">
	
	<div class="column">
		 <h4 class="text-left pb-3">MATERIAL PROPERTIES</h4>
				  <p style="font-size:15px;">The full suite of mechanical properties are given per ASTM and ISO
					standards where applicable. All parts are conditioned per ASTM
					recommended standards for a minimum of 40 hours at 23 °C, 50% RH.
					Material properties include physical and mechanical properties, as
					well as thermal.</p>
						</div>
	<div class="column">
		 <h4 class="text-left pb-3">ISOTROPIC PROPERTIES</h4>
			  <p style="font-size:15px;">
				Figure 4 technology prints parts that are isotropic in mechanical
				properties meaning the parts printed along either the XYZ axis will
				give similar results. Parts do not need to be oriented to get the
				highest mechanical properties, further improving the degree of
				freedom for part orientation for mechanical properties.
			  </p>
	</div>
</section>	
	</div>
	<br>
<br>
	<div class="wrapper">
		   <section class="columns">
	<div class="column">
		 <h4 class="text-left pb-3">TECHNICAL SPECIFICATIONS</h4>
                  <h5 class="text-left pb-3">KEY PROPERTIES</h5>
				  <P class="text-left" style="font-size:15px;">. Tensile strength, Ultimate: 60 MPa</P>
                  <p class="text-left" style="font-size:15px;">. Elongation at break: 3%</p>
				  <p class="text-white" style="font-size:15px;">. Flexural modulus: 3290 MPa</p>
			      <p class="text-white" style="font-size:15px;">. Impact strength (notched Izod): 17 J/m</p>
				  <p class="text-white" style="font-size:15px;">. Heat Deflection Temperature @ 0.45 MPa: 102 °C</p>
				  <p class="text-white" style="font-size:15px;">. Water absorption (24 hour): 0.25%</p>
	</div>
</section>	
	</div>
      <!-- section end-->
        <hr class="separator">
      <!-- footer start -->
      <?php include('includes/footer.php');?>
      <!-- footer end -->
      
   </body>
</html>
