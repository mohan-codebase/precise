<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="3D Scanning and 3D Printing events in India">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- font awesome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- custom css-->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/events_land.css">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">

    <title>Events India</title>
    <script src="assets/js/jquery-3.6.0.min.js"></script>
</head>

<body>
    <!-- header start -->
    <?php include('includes/header.php'); ?>
    <!-- header end -->

    <!--about us banner section start-->
    <section id="events_banner" class="pt-4">
        <div class="container">
            <div class="h-300 hero-height-event">
            </div>
        </div>
        <div class="heading m-320">
            <div class="container">
                <div class="row ">
                    <div class="col-md-6 aboutus-herohead pl-0">
                        <h3>Our Events
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about us banner section end-->
    <section id="events_section_one">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="upcme-event">
                        <a href="#" class="mr-3">Past Events</a>
                        <a href="#">Upcoming Events</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row cont-step-row1 mx-0">
                        <div class="col-md-4 event-webinar pl-0">
                            <button class="btn">WEBINAR</button>
                            <div>
                                <!--<img src="assets/images/events_images/dx.png" alt="dx" class="img-fluid">-->
                            </div>
                        </div>
                        <div class="col-md-8">
                            <!--<img src="assets/images/events_images/events_webinarphoto.png" alt="" class="img-fluid">-->
                            <img src="assets/images/events_images/events_scanning.png" alt="" class="img-fluid mb-4">
                        </div>
                    </div>
                    <div class="row cont-step-row2 mx-0">
                        <div class="col-md-12 event-webinarcont2">
                            <h4>3D Scanning for wood carving, art, and sculpture, with Einscan 3D scanner and
Geomagic wrap</h4>
                            <!--<p>Geomagic Design X is the Industry-leading software dedicated to Digital Reverse-->
                            <!--    Engineering applications. Its comprehensive features enable CAD designers and-->
                            <!--    3D experts to use the 3D Scan a foundation to create history-based design intent-->
                            <!--    and accurate as-built CAD and NURBS surfaces.</p>-->
                            <p>Register for an online demonstration of 3D Scanning the Freeform  object using Einscan Pro 2X  2020 3D Scanner & Witness the magic of quick CAD reconstruction in Geomagic Wrap software  that produce cad file directly that takes many hours in CAD Software. </p>
                        </div>
                        <div class="col-md-12 event-webinarcont3">
                            <i class="far fa-calendar-alt"></i>
                            <p>Thursday 19th, August 2021</p>
                            <a href="online_3d_scanning_webinar_2021.php" class="btn float-right">REGISTER NOW</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row cont-step-row1 mx-0">
                        <div class="col-md-4 event-webinar pl-0">
                            <button class="btn">WEBINAR</button>
                            <div>
                                <!--<img src="assets/images/events_images/dx.png" alt="dx" class="img-fluid">-->
                            </div>
                        </div>
                        <div class="col-md-12 eve-de-img-landing">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/handheld-3d-laser-scanner-india-einscan-pro-2x.php" class=""><img src="assets/images/events_images/einscanpro-img.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/3d-software-Geomagic-Design-X.php"><img src="assets/images/events_images/designx.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/3d-inspection-software-Geomagic-Control-X.php" class=""><img src="assets/images/events_images/control-x.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/3d-printer-figure-4.php"><img src="assets/images/events_images/standalone.png" alt="" class="img-fluid"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row cont-step-row2 mx-0">
                        <div class="col-md-12 event-webinarcont2">
                            <h4>Webinar and live demo on ‘’Digital Manufacturing lab for Engineering and Technical Education.</h4>
                            
                            <p>We offer a free webinar and live demonstration on digital manufacturing for exclusively educational institutions, faculty members, HOD'S, and CAD centre owners. This webinar will include a live demonstration of the complete workflow from 3D scan to 3D print and 3D inspection of final products.</p>
                        </div>
                        <div class="col-md-12 event-webinarcont3">
                            <i class="far fa-calendar-alt"></i>
                            <p>Friday 20th, August 2021</p>
                            <a href="online_webinar_on_digital_manufacturing_lab.php" class="btn float-right">REGISTER NOW</a>
                        </div>
                    </div>
                </div>
                
                <!--third-->
                <div class="col-md-6">
                    <div class="row cont-step-row1 mx-0">
                        <div class="col-md-4 event-webinar pl-0">
                            <button class="btn">WEBINAR</button>
                            <div>
                                <!--<img src="assets/images/events_images/dx.png" alt="dx" class="img-fluid">-->
                            </div>
                        </div>
                        <div class="col-md-12 eve-de-img-landing">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/handheld-3d-laser-scanner-india-einscan-pro-2x.php" class=""><img src="assets/images/events_images/einscanpro-img.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/3d-software-Geomagic-Design-X.php"><img src="assets/images/events_images/designx.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/3d-inspection-software-Geomagic-Control-X.php" class=""><img src="assets/images/events_images/control-x.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="https://www.precise3dm.com/3d-printer-figure-4.php"><img src="assets/images/events_images/standalone.png" alt="" class="img-fluid"></a>
                                </div>
                            </div>
                        </div>

                    </div>
                    
                    <div class="row cont-step-row2 mx-0">
                        <div class="col-md-12 event-webinarcont2">
                            <h4>Open House Event for Digital manufacturing lab for education</h4>
                            
                            <p>We are excited to announce our first Digital Manufacturing lab- an open house Event/Expo in Mumbai, India. We invite Educational Institutions, faculty members, HOD'S, and CAD center, owners. This event will include a live demonstration of the complete workflow from 3D scan to 3D print and 3D inspection of final products.</p>
                        </div>
                        <div class="col-md-12 event-webinarcont3">
                            <i class="far fa-calendar-alt"></i>
                            <p>Saturday 21st, August 2021</p>
                            <a href="3D_scanning_and_3D_Printing_open_house_event_2021.php" class="btn float-right">REGISTER NOW</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row cont-step-row1 mx-0">
                        <div class="col-md-4 event-webinar pl-0">
                            <button class="btn">WEBINAR</button>
                            <div>
                                <!--<img src="assets/images/events_images/dx.png" alt="dx" class="img-fluid">-->
                            </div>
                        </div>
                        <div class="col-md-12 eve-de-img-landing">
                            <div class="row">
                            <div class="col-md-4">
                                    <a href="https://www.precise3dm.com/handheld-industrial-3D-scanner-freescan-series.php" class=""><img src="assets/images/solutionix c500/left menu/freescanUE7.png" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-4">
                                    <a href="optical-3d-scanner-in-india.php"><img src="assets/images/solutionix c500/left menu/solutionix.png" alt="" class="img-fluid"></a>
                                    <div>
                                        
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <a href="https://www.precise3dm.com/3d-inspection-software-Geomagic-Control-X.php" class=""><img src="assets/images/solutionix c500/left menu/control x.png" alt="" class="img-fluid"></a>
                                </div>
                                
                            </div>
                        </div>

                    </div>
                    
                    <div class="row cont-step-row2 mx-0">
                        <div class="col-md-12 event-webinarcont2">
                            <h4>Open house event for optical & handheld 3D metrology solutions </h4>
                            
                            <p>With the leading global providers of 3d scanners and inspection software, Precise3DM will present optical and handheld metrology workflow. 



Attendees will be taken through both 3d scanning techniques and their strengths and advantages. Post 3d scanning we will also demo the automated 3D inspection of mass volume parts using Digital Inspection Software Geomagic Control X. 

</p>
                        </div>
                        <div class="col-md-12 event-webinarcont3">
                            <i class="far fa-calendar-alt"></i>
                            <p>Tuesday 5 th, January  2022</p>
                            <a href="Open-house-event-for-optical-scanner.php" class="btn float-right">REGISTER NOW</a>
                        </div>
                    </div>
                </div>
                <!--five-->
                <div class="col-md-6">
                    <div class="row cont-step-row1 mx-0">
                        <div class="col-md-4 event-webinar pl-0">
                            <button class="btn">WEBINAR</button>
                            <div>
                                <!--<img src="assets/images/events_images/dx.png" alt="dx" class="img-fluid">-->
                            </div>
                        </div>
                        <div class="col-md-12 eve-de-img-landing">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="einscan-pro-hd-3d-scanner-in-india.php" class=""><img src="assets/images/products/chapter3-png-1.png" alt="" class="img-fluid"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;">  EINSCAN PRO HD</h6>
                                </div>
                                <div class="col-md-3">
                                    <a href="optical-blue-light-3d-scanning-service-in-india.php"><img src="assets/images/products/optical-blue-light_3d-scanning.png" style="height: 100px;margin-top: 37px;" alt="" class="img-fluid"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: 10px;">  GOM ATOS COMPACT SCAN</h6>

                                </div>
                                <div class="col-md-3">
                                    <a href="freescan-ue-series-3d-scanner-in-india.php" class=""><img src="assets/images/products/chapter4-Image-5.png" alt="" class="img-fluid"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;">    Freescan Ue7</h6>

                                </div>
                                <div class="col-md-3">
                                    <a href="einscan-pro-2x-2020-3d-scanner-in-india.php"><img src="assets/images/products/chapter3-png-2.png" alt="" class="img-fluid"></a>
                                    <h5 style="text-align: center;font-size: 16px;position: relative;top: -20px;">  EINSCAN PRO2X 2020</h6>

                                </div>
                            </div>
                        </div>

                    </div>
                    
                    <div class="row cont-step-row2 mx-0">
                        <div class="col-md-12 event-webinarcont2">
                            <h4>Free Live 3D Scanning & Reverse Engineering event in Coimbatore. </h4>
                            
                            <p>We, Precise3DM India's largest 3d scanning service and solution provider, would like to invite Manufacturing and product development companies to witness the applications of 3D Reverse engineering and 3D Inspection using 3D scanning technology right in the centre of the city Ganapathy, Coimbatore.</p>
                        </div>
                        <div class="col-md-12 event-webinarcont3">
                            <i class="far fa-calendar-alt"></i>
                            <p>Friday 6th, May 2022</p>
                            <a href="free-3d-scanning-event.php" class="btn float-right">REGISTER NOW</a>
                        </div>
                    </div>
                </div>
                <!--five-->
            </div>
        </div>
    </section>

    <hr class="term-seperator">
    <?php include('includes/footer.php'); ?>

</body>

</html>