<?php
session_start();
ini_set('upload_max_filesize', '40000M');
ini_set('post_max_size', '40000M');
ini_set('max_input_time', 300000);
ini_set('max_execution_time', '-1');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name text-white="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Figure 4 standalone material price | 3d sysems | DLP 3d printer</title>
    <meta name="description" content="Figure 4 stanalone 3d printer resin material price and specifications, Additive manufacturing solution provider in india, explore 3d printer materials">
    <meta name="keywords" content="resin 3D printer,dlp 3D printer,tough ABS 3D printing,jewellery 3D printer,automotive 3D printing in india, 3D printer material price ">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow" />
    <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
    <meta name="revisit-after" content="7 days" />
    <meta name="twitter:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/Frame 7-min.jpg" />
    <meta name="twitter:card" content="Precise3dm" />
    <meta name="twitter:site" content="@precise3d_m" />
    <meta name="twitter:title" content="Precise3dm" />
    <meta name="twitter:description" content="Figure 4 stanalone 3d printer resin material price and specifications, Additive manufacturing solution provider in india, explore 3d printer materials" />
    <meta property="og:type" content="3D Printer" />
    <meta property="og:title" content="Figure 4 Standalone 3D printer materials" />
    <meta property="og:url" content="https://www.precise3dm.com/figure-4-standalone-3d-printer-material.php" />
    <meta property="og:image" content="https://www.precise3dm.com/assets/images/FreeCan UE7/FreeCan UE7/broucheue7/Frame 7-min.jpg" />
    <meta property="og:description" content="Figure 4 stanalone 3d printer resin material price and specifications, Additive manufacturing solution provider in india, explore 3d printer materials" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-01.png">
    <!--bootstrap css-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <!-- custom css-->
    
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/figure4.css">
    <link rel="stylesheet" href="assets/css/scanner-styles.css">
    <link rel="stylesheet" type="text/css" href="assets/css/new.css" >
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">


   <script src="assets/js/jquery-3.6.0.min.js"></script>



    <script type="text/javascript">
        $('input[type="text"]').on('blur',function(){
                var val = $(this).val();
                $(this).val($.trim(val));
        });
    
        function disablebutton()
        {
            $('#loader').show();
            //$('#submit').attr('disabled',true);
        }
        $(document).ready(function() {
        var owl = $('.owl-carousel');
        owl.owlCarousel({
            loop: true,
            nav: true,
            autoplay: false,
            autoplayTimeout: 3000,
            margin: 40,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                960: {
                    items: 3
                },
                1200: {
                    items: 3
                }
            }
        });
    })
        
    </script>
    <script type="text/javascript" src="https://static.sketchfab.com/api/sketchfab-viewer-1.10.4.js"></script>
        
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=2283548&fmt=gif" />
</noscript>


</head>

<body>
    <!-- header start -->   
    <?php include('includes/header.php');?>
      <!-- header end -->
    
    <hr class="separator">
    <section id="figurematerialban-banner" class="pt-4 pb-5">
        <div class="container">
            <div class="row h-300">
            </div>
        </div>
        <div class="container-fluid heading m-320">
            <div class="row ">
                <div class="col-md-12 text-md-left text-center px-2">
                    <div class="container-fluid">
                        <div class="row">
                        <div class="col-md-1"></div>

                            <div class="col-md-5 mt-5">
                            <h1 class="    mt-5" style="color: #fff; font-sixe:45px">FIGURE 4 STANDALONE<br> MATERIALS</h1>
                <p class=" text-uppercase mt-3" style="color: #FFF2D4;font-weight:bolder;">FOR PRODUCTION , INDIRECT PRODUCTION AND PROTOTYPE.</p>
                
                                <!--<a class="btn pre-btn mt-4" href="https://forms.zohopublic.com/virtualoffice20215/form/Bookademoonlineonsite/formperma/v-Zrwhh8zM330ig-4CD_W6rJsqgkKQ7nBEXF2nOr39M" target=_blank> MATERIALS </a>-->
                                <a class="btn btn-info btn-lg  mt-4" data-toggle="modal" data-target="#myModal">GET A QUOTE NOW</a>

                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-5 mt-4">
                                <img src="assets/images/figure4/Materials.png" class="img-fluid" height="500"  alt="3d-printer-figure4-standalone">
                            </div>
                        </div>
</div>
                </div>
            </div>
        </div>
    </section>
    
    
       <div class="container-fluid">
           <div class="row coverpage">
               <!--<div class="col-md-4 mt-5 pl-200px covercon  ">
                   
                   <div class="col-md-12 d-flex justify-content-center coverdep">
                   <div class="row ">
                           <div class="col-md-12">
                           <ul class="thumbnails">
                    
                    <li> <a href="#slide2"><img src="assets/images/solutionix c500/slidepicnew/img3.webp" width="100px" height="100px" class="img-fluid" /></a> </li>
                    <li> <a href="#slide1"><img src="assets/images/solutionix c500/slidepic/img1.webp" width="100px" height="100px" class="img-fluid"/></a> </li>
                    <li> <a href="#slide3"><img src="assets/images/solutionix c500/slidepicnew/img2.webp" width="100px" height="100px" class="img-fluid" /></a> </li>
                    <li> <a href="#slide4"><img src="assets/images/solutionix c500/slidepicnew/img1.webp" width="100px" height="100px"  class="img-fluid" /></a> </li>
                    <li> <a href="#slide5"><img src="assets/images/solutionix c500/slidepicnew/img4.webp" width="100px" height="100px"  class="img-fluid" /></a> </li>
                  </ul>

                           </div>
                       
                       </div>
                   </div>
               </div>
               <div class="col-md-4 d-flex justify-content-center mt-5 poslide ">
                 <ul class="slides mt-5">
                    
                    <li id="slide2"><img src="assets/images/solutionix c500/slidepicnew/img7.webp"  width="80%"   alt="Industrial 3D scanner"  class="img-fluid "></li>
                    <li id="slide1"><img src="assets/images/solutionix c500/slidemain/img4.webp" width="80%"  alt="Industrial 3D scanner"   class="img-fluid"></li>
                    <li id="slide3"><img src="assets/images/solutionix c500/slidepicnew/img10.webp"  width="80%"  alt="Industrial 3D scanner"   class="img-fluid"></li>
                    <li id="slide4"><img src="assets/images/solutionix c500/slidemain/img2.webp" width="80%"  alt="Industrial 3D scanner"   class="img-fluid	"></li>
                    <li id="slide5"><img src="assets/images/solutionix c500/slidepicnew/img12.webp" width="80%"  alt="Industrial 3D scanner"   class="img-fluid	"></li>
                    
                    
                  </ul>

               </div>


               <div class="col-md-4 mt-5 lastsec">
                <h1 class=" title   mt-5" style="color: #FFF2D4;">Structured light 3d Scanner <br> Solutionix C500</h1>
                <p class=" text-uppercase" style="color: #FFF2D4;">Simple High Precision Structure light Scanner</p>
                <div class= "col-8 covercont">
                    <p class="text-uppercase " style="color:#FFF2D4 ;">
                        HIGH PRECISION <br>
                        STABLE REPEATABILITY
                    </p>
                    
                </div>
                <div class="col-12 but" >
                    <!--<a class="btn pre-btn my-2" href="" target="_blank">BOOK A DEMO </a>-->
<!-- Calendly badge widget begin -->
<link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
<script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" async></script>
<script type="text/javascript">window.onload = function() { Calendly.initBadgeWidget({ url: 'https://calendly.com/precise3dm?primary_color=fd8c1e', text: 'Book a Demo', color: '#fd8c1e', textColor: '#ffffff', branding: false }); }</script>
<!-- Calendly badge widget end -->
                <!--</div>

                <div class="col-12 but" style="margin-top:20px;">
                <div style="margin-bottom:15px;">
                <i class="fas fa-phone-square-alt " style="font-size:20px;color: #FFF2D4;"></i>
                <a style="color: #FFF2D4; padding-left:5px; font-size: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; "> Call us at 1800 202 0036 </a>
                </div>
                
                    
                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">GET A QUOTE NOW</button>
                </div>
                
               </div>-->


               <div class="container-fluid  topsecsticky "  >
               <div class="container ">
               <div class="row" >
                   <div class="col-md-1 mt-2 mb-2 posstick7">
                   <a href="#overview" class="" style="color: #FE8D1D;">OVERVIEW</a>
                   </div>
                   <!--<div class="col-md-2 mt-2 mb-2 posstick">
                   <a href="figure-4-standalone-3d-printer.php#keyfeature" class="" style="color: #FE8D1D;">KEY FEATURES</a>
</div>  
<div class="col-md-2 mt-2 mb-2">
                   <a href="figure-4-standalone-3d-printer.php#Specification" class="" style="color: #FE8D1D;">SPECIFICATIONS</a>
                   </div>-->
                   <div class="col-md-2 mt-2 mb-2 posstick8 ">
                   <a href="#application" class="" style="color: #FE8D1D;">Applications</a>
                   </div>
                   <div class="col-md-2 mt-2 mb-2 posstick9">
                   <a href="https://www.precise3dm.com/figure-4-standalone-3d-printer.php#INDUSTRY" class="" style="color: #FE8D1D;">Industry</a>
                   </div>
                   <div class="col-md-2 mt-2 mb-2 posstick10 ">
                   <a href="figure-4-standalone-3d-printer.php" class="" style="color: #FE8D1D;">  3D Printer</a>
                   </div>
                   <div class="col-md-2 mt-2 mb-2 posstick11">
                   <a href="https://www.precise3dm.com/3d-printing-service-in-india.php" class="" style="color: #FE8D1D;"> 3D Printing services</a>
                   </div>
                   <!--<div class="col-md-1 mt-2 mb-2 posstick4">
                   <a href="#blog" class="" style="color: #FE8D1D;">BLOG</a>
                   </div>
                   <div class="col-md-1 mt-2 mb-2 posstick5">
                   <a href="#faq" class="" style="color: #FE8D1D;">FAQ</a>
                   </div>-->
               
               </div>
               

                   </div> 

                   <script>
$(document).ready(function(){
    $('input:checkbox').click(function() {
        $('input:checkbox').not(this).prop('checked', false);
    });
});
</script>
               
                   
               

               </div>
               <div class="col-md-3 mt-5" style="padding:28px" >
                   <div style="padding-left:33px; padding-top:1px;border:1px solid #FFF">
                   <aside>
	 <h6 style="color:#FFF2D4;padding-top:12px;">MATERIALS FOR THIS PRINTER</h6>
	 
    <div>
    <div><input type="checkbox" name="nbaTeam" value="bos1" id="bos1">	
      <label for="bos1"><p style="color:#FFF2D4;font-size:15px;">Plastic</p></label>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;&emsp;<a style="color:#FFF2D4">16</a></div>
      <div><input type="checkbox" name="nbaTeam" value="bos" id="bos" style="color:#FFF2D4;"><label for="bos"><p style="color:#FFF2D4;position:relative;left:5px;">Biocompatible Capable</p></label>&emsp;&emsp;&emsp;&emsp;<a style="color:#FFF2D4">06</a></div>
      <div><input type="checkbox" name="nbaTeam" value="cle" id="cle"><label for="cle"><p style="color:#FFF2D4;position:relative;left:5px;">General Purpose</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&emsp;&emsp;<a style="color:#FFF2D4">04</a></div>
      <div><input type="checkbox" name="nbaTeam" value="cha" id="cha"><label for="cha"><p style="color:#FFF2D4;position:relative;left:5px;">High Temperature</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;&emsp;<a style="color:#FFF2D4">04</a></div>
      <div><input type="checkbox" name="nbaTeam" value="det" id="det"><label for="det"><p style="color:#FFF2D4;position:relative;left:5px;">Elastomer/Rubber-Like</p></label>&emsp;&emsp;&emsp;&emsp;<a style="color:#FFF2D4">03</a></div>
      <div><input type="checkbox" name="nbaTeam" value="gsw" id="gsw"><label for="gsw"><p style="color:#FFF2D4;position:relative;left:5px;">Tough_ABS_Like</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&emsp;&emsp;&nbsp;<a style="color:#FFF2D4">03</a></div>
      <div><input type="checkbox" name="nbaTeam" value="hou" id="hou"><label for="hou"><p style="color:#FFF2D4;position:relative;left:5px;">Castable Plastics</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&emsp;&emsp;<a style="color:#FFF2D4">02</a></div>
      <div><input type="checkbox" name="nbaTeam" value="ind" id="ind"><label for="ind"><p style="color:#FFF2D4;position:relative;left:5px;">Durable-Polypropylene-like</p></label>
	  <label for="ind">&emsp;&ensp;&nbsp;<a style="color:#FFF2D4">02</a></label></div>
      <div><input type="checkbox" name="nbaTeam" value="mia" id="mia"><label for="mia"><p style="color:#FFF2D4;position:relative;left:5px;">JewelryCasting</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&emsp;&emsp;<a style="color:#FFF2D4">02</a></div>
      <div><input type="checkbox" name="nbaTeam" value="min" id="min"><label for="min"><p style="color:#FFF2D4;position:relative;left:5px;">Master Pattern</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&emsp;&emsp;<a style="color:#FFF2D4">01</a></div>
      <div><input type="checkbox" name="nbaTeam" value="nop" id="nop"><label for="nop"><p style="color:#FFF2D4;position:relative;left:5px;">Transparent/Translucent</p></label>&emsp;&nbsp;&emsp;&emsp;<a style="color:#FFF2D4"> 01</a></div>
      <div ><input type="checkbox" name="nbaTeam" value="mil" id="mil"><label for="mil"><p style="color:#FFF2D4;position:relative;left:5px;">Rigid–Polycarbonate-like,</p></label>
	  <label for="mil">&emsp;&ensp;<p style="color:#FFF2D4;position:relative;bottom:30px;" >Urethane-like</p></label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&ensp;&emsp;&emsp;<a style="color:#FFF2D4;position:relative;bottom:62px;position:relative;right:-12px;">02</a></div>

    </div>
  </aside>



                </div>


               </div>
               <div class="col-md-8" >
                   <div class="row">
                   <div class="col-md-12  mt-5 " id="overview" >
                <h3 class=" " style="color: #FFF;padding-top:36px;">OVERVIEW</h3>

                
            </div>
            <div class="col-md-8">
                <h6 style="color:#FFF2D4;font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;font-weight:500;font-size:17px;line-height:31px;">AFFORDABLE AND VERSATILE FOR LOW-VOLUME PRODUCTION AND FAST PROTOTYPING, OFFERING QUALITY AND ACCURACY WITH INDUSTRIAL-GRADE DURABILITY, SERVICE, AND SUPPORT.</h6>
            </div>
            <div class="col-md-12"></div>
            <div class="col-md-12 mt-5 pb-5">
                <div class="row" id="application">
                <div class="col-md-4 player bos mil bos1 injured starting lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                        <img src="assets/images/figure4/support material/image-1.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 Rigid White</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Opaque rigid white production-grade plastic</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-rigid-white.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard bos bos1 det starting lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class=" appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-4.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 RUBBER-BLK 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Durable, hard rubber-like material</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-rubber-blk10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard hou nop bos1 reserves lebron  mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-7.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 EGGSHELL-AMB 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Process-optimized material for sacrificial tooling to cast silicone</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-eggshell-amb10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player forward bos cha bos1 reserves lebron mt-5 " id="support materials"  >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-10.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 MED-WHT 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Rigid white material that can be sterilized and tested at high temperature</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-med-wht10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>
            </div>
            <div class="col-md-4 player forward hou mia injured bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-13.webp" style="border-radius:13px;" width=200px height="150px" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 JCAST-GRN 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Jewelry castable material for high-resolution patterns</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-jcast-grn10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>

            <div class="col-md-4 player guard cle gsw bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-16.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 TOUGH-GRY 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">High speed, production rigid dark gray material</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-tough-gry10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            
                
                <div class="col-md-4 player min cha mia bos1 starting lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-2.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 JEWEL MASTER GRY</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Jewelry master patterns and prototypes</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-jewel-master-gry.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard forward ind east bos1 starting lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-5.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 FLEX-BLK 20</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">High stability, durable and flexible plastic</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-flex-blk20.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard bos mil bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-8.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 PRO-BLK 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Production-grade, rigid material for production parts</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-pro-blk10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player forward center bos cha injured bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-11.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 MED-AMB 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Rigid, translucent material that can be sterilized and tested at high temperature</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-med-amb10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard det east bos1 reserves lebron mt-5 " >
                    <div class="row">

            <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/group 306.jpg" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 RIGID GRAY</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Rubber-like, design elastomeric material</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-rigid-gray.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player forward bos det bos1 starting lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-3.webp" width=200px height="150px" style="border-radius:13px;" alt=""  class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 RUBBER-65A BLK</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Mid tear strength production-grade rubber</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-rubber-65a-blk.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4  player forward cha west bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-6.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 HI TEMP 300-AMB</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">High temperature resistant translucent plastic with HDT over 300</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-hi-temp-300-amb.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player center cle gsw bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-17.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 TOUGH-BLK 20</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Strong material with long-term environmental stability</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-tough-blk20.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard cle ind bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-12.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 FLEX-BLK 10</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Durable, hard rubber-like material</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-flex-blk10.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>
            <div class="col-md-4 player guard cle gsw injured bos1 reserves lebron mt-5 " >
                    <div class="row">
                    <div class="col-md-10  keyapponee mt-5" >
                    
                    <div class="appnewone  d-flex justify-content-center" >
                    <img src="assets/images/figure4/support material/image-15.webp" width=200px height="150px" style="border-radius:13px;" alt="" class="img-fluid">

                    </div>
                    <h6 class=" " style="color: #FFF2D4;text-align:center; padding-bottom:10px ;">Figure 4 TOUGH-GRY 15</h6>
                    <h6 class=" " style="color: #FFF2D4;text-align:center ;">Economical, production rigid gray material</h6>
                    <div class="text-center mt-3">
                        <a class="btn pre-btn my-2" href="figure-4-tough-gry15.php" target="_blank">LEARN MORE</a>
                        </div>



                </div>
                </div>


            </div>






























                
            <!-- section 1-->
            <!--section-2 ends-->

























                <!--</div>
                

            </div>-->
            <!-- Section 3 ends-->
            <!-- Section4 ends-->
            <!-- section5 ends-->





 



































                   </div>
               </div>


















               
               




              <!-- <div class="col-md-1"></div>
            <div class="col-md-11  mt-5 " id="overview" >
                <h3 class=" " style="color: #FE8D1D;">OVERVIEW</h3>

                
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-6  mt-3 " id="overview" >
            <h3 style="color: #FFF2D4;  font-size: 18px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; "> 
            Figure 4 Standalone is an industrial-grade 3D Printer appropriate for low-volume plastic parts production and prototyping. Figure 4 3D prints plastic, biocompatible, and rubber parts directly without injection machine molds. Figure 4 3D printing is the latest method of producing industrial plastic parts at a lower cost with a fast turnaround time than the traditional manufacturing method of manufacturing a hand mold for injection machine molding production.
            </h3>
            <div class="col-md-12 mt-4">
                        
                        <img src="assets/images/figure4/Grouptriangle.webp" width="20px" height="20px" alt="Handheld Industrial 3D scanner">
                        <div style="margin-left:38px; position: relative;bottom: 22px;">
                        <a style="color: #FFF2D4; font-size: 17px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; "> 
                        Economical solution for functional prototype and low volume production                    </a>
                    
    
                        </div>
            </div>
            <div class="col-md-12 ">
                        
                        <img src="assets/images/figure4/Grouptriangle.webp" width="20px" height="20px" alt="Handheld Industrial 3D scanner">
                        <div style="margin-left:38px; position: relative;bottom: 22px;">
                        <a style="color: #FFF2D4; font-size: 17px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; "> 
                        High-speed production 3D printing                    </a>
                    
    
                        </div>
            </div>
            <div class="col-md-12 ">
                        
                        <img src="assets/images/figure4/Grouptriangle.webp" width="20px" height="20px" alt="Handheld Industrial 3D scanner">
                        <div style="margin-left:38px; position: relative;bottom: 22px;">
                        <a style="color: #FFF2D4; font-size: 17px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; "> 
                        High-quality industrial-grade 3D printing                    </a>
                    
    
                        </div>
            </div>
            <div class="col-md-12 ">
                        
                        <img src="assets/images/figure4/Grouptriangle.webp" width="20px" height="20px" alt="Handheld Industrial 3D scanner">
                        <div style="margin-left:38px; position: relative;bottom: 22px;">
                        <a style="color: #FFF2D4; font-size: 17px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; "> 
                        Print up to 250 parts a day                </a>
                    
    
                        </div>
            </div>
                </div>

                

                <div class="col-md-4 mt-5">
                <iframe width="100%" height="250" src="https://www.youtube.com/embed/6_gySmOfKLw" allow="autoplay">
               </iframe>
                </div>
                <div class="col-md-1"></div>-->




            
            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
            
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    
                  </div>
                  <div class="modal-body">
                    <?php
                if (isset($_SESSION['status'])) {
                    if ($_SESSION['status'] == "success") {
                        echo "<div class='row status-div'>
                              
                                <div style='width: 100%'>Thanks for submitting the form.. We ll get back to you shortly!</div>
                               
                        </div>";
                    } else {
                        echo "<div class='row status-div'>
                                <p class='status-message'>Oops...Something went wrong, please try again
                            </p><div style='width: 100%'><a href='javascript:void(0);'><button class='step-form-btn'>Back</button></a></div></div>";
                    }
                    unset($_SESSION['status']);
                } else { ?>
                    <form method="POST" action="freescanue7form.php" id="regForm" enctype="multipart/form-data" onsubmit="disablebutton();">

                        <div class="tab-step-form" data-form-type="contact">
                              
                           
                            <h5 style="margin-bottom:10px" >Contact Information</h5>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="name" name="name" placeholder="Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control required" id="email" name="email" placeholder="Email Address *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="contactnumber" name="contactnumber" placeholder="Mobile Number *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyname" name="companyname" placeholder="Company Name *" required />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control required" id="companyaddress" name="companyaddress" placeholder="Company Address *" required />
                            </div>
                            <!--<span>Do you also need GST no included in the quote?</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="homeavailable" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="homeavailable" value="No"> No</label>
                            </div>-->
                             <!--<div class="form-group">
                                <input type="text" class="form-control required" id="gstnumber" name="gstnumber" placeholder="GST Number*" required />
                            </div>
                            <span>Scanner series</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="needdemo" value="Solutionix C500"> Solutionix C500</label>
                                <label><input type="radio" class="technical-checkbox" name="needdemo" value="Solutionix D700"> Solutionix D700</label>
                            </div>-->
                            <!--<span>Do you also need a quote for Geomagic software?</span>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="home" name="needquote" value="Yes"> Yes</label>
                                <label><input type="radio" class="technical-checkbox" name="needquote" value="No"> No</label>
                            </div>
                            <div class="radiobox">
                                <label><input type="radio" class="technical-checkbox" id="geomagicdesignx" name="geomagic" value="geomagicdesignx"> Reverse engineering software - Geomagic Design X</label>
                                <label><input type="radio" class="technical-checkbox" name="geomagic" value="geomagiccontrolx">  3d inspection software - Geomagic Control x</label>
                            </div>-->
                            
                        </div>
                        <button type="submit" class="btn btn-success" id="submit" style="margin-top:10px;">Submit <img src="loader2.gif" id="loader" width="25" style="display: none;" /></button>
                       

                    </form>
                <?php } ?>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
                </div>
            
              </div>
            </div>




        <div class="col-md-12"></div>
        <!--<div class="col-md-1"></div>

        <div class="col-md-10 mt-5"id=faq>
        <h3 class=" " style="color: #FE8D1D;">
                FAQs

             </h3>

        </div>
        <div class="col-md-1"></div>
        <div class="container mt-5 mb-3 " >
                <div class="col-md-11 text-left px-lg-0 faqsectionforscroll  ">
            <section id="backfs" class="backfs ">


                    
                    
                  <h5 class="pre-colorfs " style="color: #ff931e;">How much do 3dsystesm Figures four 3D Printers cost in India? </h5>
                  <div class="left-border">
                    <p class="text-white " >Please contact PRECISE3DM sales representative or fill up the get quote option from our website to know the latest offer for Figure 4 3D printers. </p>
                  </div>
                  <h5 class="pre-colorfs " style="color: #ff931e;">What is the Figure 4 standalone 3D printer?</h5>
                    <div class="left-border">
                        <p class="text-white " >Figure standalone is a next-generation 3D printer used for plastic parts production applications. Unlike other printers, it can be used for making End parts without core cavity and molds.</p>
                    </div>
                    
                    <h5 class="pre-colorfs " style="color: #ff931e;">How does 3D Systems Figure 4 Work? </h5>
                    <div class="left-border">
                        <p class="text-white " >Figure 4 uses the DLP (Digital Light Projection)3D printing technology.</p>
                    </div>
                    <h5 class="pre-colorfs " style="color: #ff931e;">Where can I buy Figure 4 resin in India?</h5>
                    <div class="left-border">
                        <p class="text-white " >PRECISE3DM Is an authorized reseller of Figure 4 standalone 3D printers in India. We provide pre-sales and post-sales support for Figure 4 3D printers in India. We also resell Figure 4 3D printers resins in India. </p>
                    </div>
                    <h5 class="pre-colorfs " style="color: #ff931e;">Where can I buy a figure 4 3D printer in India?</h5>
                    <div class="left-border">
                        <p class="text-white " >PRECISE3DM Is an authorized reseller of Figure 4 standalone 3D printers in India. We provide pre-sales and post-sales support for Figure 4 3D printers in India.</p>
                    </div>
                    <h5 class="pre-colorfs " style="color: #ff931e;">Per day how many parts can Figure 4 can print?</h5>
                    <div class="left-border">
                        <p class="text-white " >Figure 4 has high print speeds that make it possible to print multiple parts in a realistic time frame. Based on the size and volume of the part, it can print even per day 200 parts</p>
                    </div>




                    


           </section>

                </div>
            </div>-->
                     
<!--  <aside>
	 <h6>MATERIALS FOR THIS PRINTER</h6>
	 <br>
    <div>
	  <div><input type="checkbox" name="nbaTeam" value="bos1" id="bos1">	
      <label for="bos1">Plastic</label>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;&emsp;16</div>
      <div><input type="checkbox" name="nbaTeam" value="bos" id="bos"><label for="bos">Biocompatible Capable</label>&emsp;&emsp;&emsp;&emsp;06</div>
      <div><input type="checkbox" name="nbaTeam" value="cle" id="cle"><label for="cle">General Purpose</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&emsp;&emsp;04</div>
      <div><input type="checkbox" name="nbaTeam" value="cha" id="cha"><label for="cha">High Temperature</label>&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;&emsp;04</div>
      <div><input type="checkbox" name="nbaTeam" value="det" id="det"><label for="det">Elastomer/Rubber-Like</label>&emsp;&emsp;&emsp;&emsp;03</div>
      <div><input type="checkbox" name="nbaTeam" value="gsw" id="gsw"><label for="gsw">Tough_ABS_Like</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&emsp;&emsp;&nbsp;03</div>
      <div><input type="checkbox" name="nbaTeam" value="hou" id="hou"><label for="hou">Castable Plastics</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&emsp;&emsp;02</div>
      <div><input type="checkbox" name="nbaTeam" value="ind" id="ind"><label for="ind">Durable-Polypropylene-like</label>
	  <label for="ind">&emsp;&ensp;&nbsp;02</label></div>
      <div><input type="checkbox" name="nbaTeam" value="mia" id="mia"><label for="mia">JewelryCasting</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&emsp;&emsp;02</div>
     <div><input type="checkbox" name="nbaTeam" value="mil" id="mil"><label for="mil">Rigid–Polycarbonate-like,</label>
	  <label for="mil">&emsp;&ensp;Urethane-like</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&ensp;&emsp;&emsp;02</div>
      <div><input type="checkbox" name="nbaTeam" value="min" id="min"><label for="min">Master Pattern</label>&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;&ensp;&ensp;&emsp;&emsp;01</div>
      <div><input type="checkbox" name="nbaTeam" value="nop" id="nop"><label for="nop">Transparent/Translucent</label>&emsp;&nbsp;&emsp;&emsp; 01</div>
    </div>
  </aside>-->

            










        


















             

         

             


















             
             

    
                

                
    
               
                

               

             
             


            




  </div>
  </div>
  </div>


       
       </div>
       <script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-157cd5b220a5c80d4ff8e0e70ac069bffd87a61252088146915e8726e5d9f147.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.min.js'></script>
      <script id="rendered-js" >
// not exactly vanilla as there is one lodash function

var allCheckboxes = document.querySelectorAll('input[type=checkbox]');
var allPlayers = Array.from(document.querySelectorAll('.player'));
var checked = {};

getChecked('startingReserves');
getChecked('injured');
getChecked('position');
getChecked('nbaTeam');
getChecked('conference');

Array.prototype.forEach.call(allCheckboxes, function (el) {
  el.addEventListener('change', toggleCheckbox);
});

function toggleCheckbox(e) {
  getChecked(e.target.name);
  setVisibility();
}

function getChecked(name) {
  checked[name] = Array.from(document.querySelectorAll('input[name=' + name + ']:checked')).map(function (el) {
    return el.value;
  });
}

function setVisibility() {
  allPlayers.map(function (el) {
    var startingReserves = checked.startingReserves.length ? _.intersection(Array.from(el.classList), checked.startingReserves).length : true;
    var injured = checked.injured.length ? _.intersection(Array.from(el.classList), checked.injured).length : true;
    var position = checked.position.length ? _.intersection(Array.from(el.classList), checked.position).length : true;
    var nbaTeam = checked.nbaTeam.length ? _.intersection(Array.from(el.classList), checked.nbaTeam).length : true;
    var conference = checked.conference.length ? _.intersection(Array.from(el.classList), checked.conference).length : true;
    if (startingReserves && injured && position && nbaTeam && conference) {
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  });
}
//# sourceURL=pen.js
    </script>

              <!-- footer start -->
      <?php include('includes/footer.php');?>
      <!-- footer end -->

       
       
    
               
    <script type="text/javascript" src="https://static.sketchfab.com/api/sketchfab-viewer-1.10.4.js"></script>
    <!-- Initialize the viewer -->
    <script type="text/javascript">
    var iframe = document.getElementById( 'api-frame' );
    var uid = '7w7pAfrCfjovwykkEeRFLGw5SXS';

    // By default, the latest version of the viewer API will be used.
    var client = new Sketchfab( iframe );

    // Alternatively, you can request a specific version.
    // var client = new Sketchfab( '1.10.4', iframe );

    client.init( uid, {
        success: function onSuccess( api ){
            api.start();
            api.addEventListener( 'viewerready', function() {

                // API is ready to use
                // Insert your code here
                console.log( 'Viewer is ready' );

            } );
        },
        error: function onError() {
            console.log( 'Viewer error' );
        }
    } );
    </script>
   
    <script src="assets/js/counter.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
<script type="text/javascript">
// 	$('input[type="text"]').on('blur',function(){
// 			var val = $(this).val();
// 			$(this).val($.trim(val));
// 	});

	function disablebutton()
	{
		$('#loader').show();
		
		//$('#submit').attr('disabled',true);
	}
</script>
<script>
	function manage(txt) {
        var bt = document.getElementById('submit');
        if (txt.value != '') {
            bt.disabled = false;
        }
        else {
            bt.disabled = true;
        }
    }    
</script>
<script>
var fileInput = document.querySelector('input[type=file]');
var filenameContainer = document.querySelector('.custom-file-upload');
fileInput.addEventListener('change', function() {
    filenameContainer.innerText = fileInput.value.split('\\').pop();
});

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab-step-form");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  // fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab-step-form");
  var currentTabValue = $(".tab-step-form").eq(currentTab).attr("data-form-type");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm(currentTabValue)) return false;
  if (currentTab < x.length-1){
  // Hide the current tab:
  x[currentTab].style.display = "none";
    }
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    $('#loader').show();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm(form) {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;

  console.log(form);

  if(form == 'contact')
  {
    console.log("in");
    var input_fields = ['name','email','companyname','contactnumber'];
    var inputs;
    var emailpattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
    $.each(input_fields,function(index,value){
        inputs = $('input[name="'+value+'"]');

        if($.trim(inputs.val()) == "")
        {
            inputs.addClass(' invalid');
            valid = false;
        }else{
            inputs.removeClass(' invalid');
            console.log(value+" invalid removed");
        }

        if(value == 'email')
        {
            if(!emailpattern.test(inputs.val()))
            {
                inputs.addClass(' invalid');
                valid = false;
            }
        }
    });
    
  }else if(form == 'technical')
  {
    console.log("in-technical");
    var checkbox = $(".technical-checkbox");
    if (checkbox.filter(':checked').length == 0) {
        console.log("no-selected");
                $(".technical-checkbox-error").show();
                    valid = false;
        }else{
            console.log("selected any");
             $(".technical-checkbox-error").hide();
        }

  }else if(form == 'deliverables')
  {
        /*no validation*/
  }else if(form == '' || form == undefined)
  {
    console.log("out");
      x = document.getElementsByClassName("tab-step-form");
      y = x[currentTab].getElementsByTagName("input");
      // A loop that checks every input field in the current tab:
      for (i = 0; i < y.length; i++) {
        // If a field is empty...
        if (y[i].value == "") {
          // add an "invalid" class to the field:
          y[i].className += " invalid";
          // and set the current valid status to false
          valid = false;
        }
      }
  }
  
  return valid; // return the valid status
}

</script>
<script>
    // vars
'use strict'
var	testim = document.getElementById("testim"),
		testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 4500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
		touchStartPos,
		touchEndPos,
		touchPosDiff,
		ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
		
		testim.addEventListener("touchstart", function(e) {
				touchStartPos = e.changedTouches[0].clientX;
		})
	
		testim.addEventListener("touchend", function(e) {
				touchEndPos = e.changedTouches[0].clientX;
			
				touchPosDiff = touchStartPos - touchEndPos;
			
				console.log(touchPosDiff);
				console.log(touchStartPos);	
				console.log(touchEndPos);	

			
				if (touchPosDiff > 0 + ignoreTouch) {
						testimLeftArrow.click();
				} else if (touchPosDiff < 0 - ignoreTouch) {
						testimRightArrow.click();
				} else {
					return;
				}
			
		})
}
</script>
 <script>
	function validate() {
		
		var valid = true;
		valid = checkEmpty($("#name"));
		valid = valid && checkEmail($("#email"));
		
		$("#btn-submit").attr("disabled",true);
		if(valid) {
			$("#btn-submit").attr("disabled",false);
		}	
	}
	function checkEmpty(obj) {
		var name = $(obj).attr("name");
		$("."+name+"-validation").html("");	
		$(obj).css("border","");
		if($(obj).val() == "") {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Required");
			return false;
		}
		
		return true;	
	}
	function checkEmail(obj) {
		var result = true;
		
		var name = $(obj).attr("name");
		$("."+name+"-validation").html("");	
		$(obj).css("border","");
		
		result = checkEmpty(obj);
		
		if(!result) {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Required");
			return false;
		}
		
		var email_regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,3})+$/;
		result = email_regex.test($(obj).val());
		
		if(!result) {
			$(obj).css("border","#FF0000 1px solid");
			$("."+name+"-validation").html("Invalid");
			return false;
		}
		
		return result;	
	}
</script>

</html>